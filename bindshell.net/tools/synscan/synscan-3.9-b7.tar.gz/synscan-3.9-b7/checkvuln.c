/* 
Crappy forking tool (C)2005 MaxImpact
*/

#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/sockios.h>
#include <time.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <signal.h>

int maxforq = 1;

char outfilename[64];

int
checkvuln (unsigned long dest, int port, FILE * output)
{
  char param[4096];
  int sck;
  struct in_addr ami;

  memset (param, 0x0, sizeof (param));
  if (port == 111 || port == 80 || port == 23)
    {
      ami.s_addr = dest;
      fprintf (output, "%s(%s):%d :\n", inet_ntoa (ami), rlookup (dest),
               port);
      sck = tcpconnect (dest, INADDR_ANY, 80, 10, port, outfilename, output);
      if (sck != -1)
        close (sck);
    }
  else
    {
      sck = tcpconnect (dest, INADDR_ANY, 80, 10, port, param, output);
      if (sck != -1)
        {
          close (sck);
          ami.s_addr = dest;
          fprintf (output, "%s(%s):%d :%s\n", inet_ntoa (ami), rlookup (dest),
                   port, param);
        }
    }
  fflush (output);
  return 0;
}

int
main (int argc, char **argv)
{
  int pid, k, j, frk, i, mforks, tf=0, port;
  char *pt;
  char cmdbuf[1024], sv[3];
  FILE *inp, *outp;

  mforks = 64;			/* default */
  if (argv[1] == NULL)
    {
      printf ("Usage: %s <command list> <forks> <output> <port>\n", argv[0]);
      exit (0);
    }
  if (argv[2] != NULL)
    {
      mforks = atoi (argv[2]);
    }
  if((outp=fopen(argv[3],"a"))==NULL) {
printf("error opening output file\n");
}
snprintf(outfilename, "%s", argv[3]);
port=atoi(argv[4]);

  if((inp=fopen(argv[1],"r"))!=NULL)
  {
      while(fgets(cmdbuf,sizeof(cmdbuf),inp))
      {
                  frk = fork ();
                  if (frk == 0)
                    {
		      printf("Forking job # %d\n", tf);
          sscanf (cmdbuf, "%s\n", cmdbuf);
          checkvuln (inet_addr (cmdbuf), port, outp);
                      exit (0);
                    }
                  else
                    {           /* frk = 0 */
		      tf++;
                      maxforq++;
                      if (maxforq > mforks)
                        {
                          wait (NULL);  // waiting until the child died
                          maxforq--;
                        }

                    }

      }
      fclose(inp);
      exit(0);
  }

}
