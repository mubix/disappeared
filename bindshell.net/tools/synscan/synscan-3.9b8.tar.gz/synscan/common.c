/*
 *   This file is part of synscan and licensed under the GPL
 *   (C) 2006 john@ev6.net
 */

#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <signal.h>

#include "synscan.h"

char nhostname[16];

/* non resolving lookup, ip to normal notation */

char *
rlookup (u_long ip)
{
  static char hostname[256];
  struct hostent *host;
  struct in_addr ami;
  struct sockaddr_in addr;
  char scheisse[100];

  addr.sin_addr.s_addr = ip;
  host =
    gethostbyaddr ((char *) &addr.sin_addr, sizeof (addr.sin_addr), AF_INET);

  if (host == NULL)
    {
      ami.s_addr = ip;
      strcpy (scheisse, (char *) inet_ntoa (ami));
      snprintf (hostname, 256, "%s", scheisse);
    }
  else
    {
      snprintf (hostname, sizeof (hostname), "%s", host->h_name);
    }
  return hostname;
}

char *
nlookup (u_long ip)
{
  struct in_addr ami;

  ami.s_addr = ip;
  strcpy (nhostname, inet_ntoa (ami));

  return nhostname;
}

unsigned long int
lookup (char *hostname)
{
  struct hostent *name;
  unsigned long int address;

  if ((address = inet_addr (hostname)) != -1)
    return address;
  if ((name = gethostbyname (hostname)) == NULL)
    return -1;

  memcpy (&address, name->h_addr, name->h_length);
  return address;
}

