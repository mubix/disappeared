
/* define the number of child processes synscand will use */
#define MAXFORK 256

/* wether to enable support for X11 checking, disable on hosts without X libs installed */
/* #define X11CHECK 1 */
#undef X11CHECK

/* makes the status line be updated quicker, slows the scanning down but looks prettier */
//#define FAST_STATUS

/* number of usecs to sleep for each time a delay is called */
/* usually 10 on a machine with a 1000hz timer, and 1 on a machine with 100hz */
#define SLEEPTIME 10

/* DO NOT MODIFY BELOW HERE!! */
/* Current version.. do not edit this! */
#define SYNSCAN_VERSION "3.9b8"
#define SPEC "IPv6 test version - http://www.bindshell.net/tools/synscan"

/* function prototypes */
//char *nlookup (u_long sip);
//char *nlookup6 (struct sockaddr_in6 *sin6);
//int lookup6 (char *addr);
char *ino (u_long sip);
int Connect (int fd, char *ip, unsigned int port, unsigned int time_out);
int write_timer (int fd, unsigned int time_out);
int read_timer (int fd, unsigned int time_out);
int is_samba (char *ip, unsigned long time_out, FILE * output);
char *rlookup (u_long sip);
char *nlookup (u_long sip);
unsigned long int lookup (char *hostname);

/* defines */
#define ifc_buf ifc_ifcu.ifcu_buf
#define ifc_req ifc_ifcu.ifcu_req

/*
* IPv6 header
* Internet Protocol, version 6
* Static header size: 40 bytes
*/
struct ipv6_hdr
{
u_int8_t ip_flags[4]; /* version, traffic class, flow label */
u_int16_t ip_len; /* total length */
u_int8_t ip_nh; /* next header */
u_int8_t ip_hl; /* hop limit */
struct in6_addr ip_src, ip_dst; /* source and dest address */

};


