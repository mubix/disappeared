<?

// Copyright (c) 2006-2009, Wade Alcorn 
// All Rights Reserved
// wade@bindshell.net - http://www.bindshell.net

require_once ("../../../include/common.inc.php"); // included for get_b64_file()
DEFINE('JS_FILE', './template.js');
?>

<script>
	var rtnval = "This shouldn't be returned'";

	function get_b64_code_request() {
		// javascript is loaded from a file - it could be hard coded
		var b64code = '<? echo get_b64_file(JS_FILE); ?>';

		return b64code;
	}

	Element.Methods.set_autorun = function() {
		ar.enable('browser dos fun', get_b64_code_request());
	}

	Element.Methods.send_now = function() {
		do_send(get_b64_code_request());
	}

	// add construct code to DOM
	Element.addMethods();
</script>

<!-- PAGE CONTENT -->
<div id="module_header">Browser DoS Fun</div>
	  This will DoS with many browsers (including Firefox 3.x and Safari on the iPhone) <br><br>
<div id="module_subsection">
	<form name="myform">
		<input class="button" type="button" value=" set autorun " onClick="javascript:set_autorun()"/>
		<input class="button" type="button" value=" send now " onClick="javascript:send_now()"/>
	</form>
</div>

