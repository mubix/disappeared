<?
	// Copyright (c) 2006-2009, Wade Alcorn 
	// All Rights Reserved
	// wade@bindshell.net - http://www.bindshell.net

	require_once("../../../include/common.inc.php"); // included for get_b64_file()
	DEFINE('JS_FILE', './template.js');
?>

<script>
	Element.Methods.construct_code = function() {

		// javascript is loaded from a file - it could be hard coded
		var b64code = '<? echo get_b64_file(JS_FILE); ?>';

		// send the code to the zombies
		do_send(b64code);
	}

	// add construct code to DOM
	Element.addMethods();
</script>

<!-- PAGE CONTENT -->
<div id="module_header">Detect Unsafe ActiveX</div>
This module will check if IE has been insecurely configured. It will test if the option "Initialize and script ActiveX controls not marked as safe for scripting" is enabled.<br /><br />
The setting can be found in:<br/>
Tools Menu -> Internet Options -> Security -> Custom level -> "Initialize and script ActiveX controls not marked as safe for scripting"
<div id="module_subsection">
	<form name="myform">
		<input class="button" type="button" value="send" onClick="javascript:construct_code()"/>
	</form>
</div>

