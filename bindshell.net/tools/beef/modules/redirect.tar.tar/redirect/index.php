<?
	// Copyright (c) 2006-2009, Wade Alcorn 
	// All Rights Reserved
	// wade@bindshell.net - http://www.bindshell.net

	require_once("../../../include/common.inc.php"); // included for get_b64_file()
	DEFINE('JS_FILE', './template.js');
?>

<script>

	get_b64_code_redirect = function () {
		// javascript is loaded from a file - it could be hard coded
		var b64code = '<? echo get_b64_file(JS_FILE); ?>';

		// replace sections of the code with user input
		b64code = b64replace(b64code, "REDIRECTURL", document.myform.url_str.value);
		
		return b64code;
	}

	Element.Methods.set_autorun = function() {
		ar.enable('redirect', get_b64_code_redirect());
	}
	
	Element.Methods.send_now = function() {
		do_send(get_b64_code_redirect());
	}

	// add construct code to DOM
	Element.addMethods();
</script>

<!-- PAGE CONTENT -->
<div id="module_header">Redirect</div><br>
<div id="module_subsection">
	<form name="myform">
		<div id="module_subsection_header">Redirect Page</div>
		<input type="text" width="90%" name="url_str" value="http://www.bindshell.net/"/>
		<input class="button" type="button" value=" set autorun " onClick="javascript:set_autorun()"/>
		<input class="button" type="button" value=" send now " onClick="javascript:send_now()"/>
	</form>
</div>
