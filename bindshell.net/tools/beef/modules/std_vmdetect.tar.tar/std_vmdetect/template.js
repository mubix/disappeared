function vmDetect(){ 
	var isVM = false;
    
    try{ var o = new ActiveXObject("WbemScripting.SWbemLocator"); }         
    catch(ex){
    	return_result(result_id, "VMDetect: Browser is configured for unsafe ActiveX");
    	return;
    } 
    
    var s = o.ConnectServer(strServer = ".");
    var a = s.ExecQuery("SELECT * FROM Win32_NetworkAdapterConfiguration");
    var e = new Enumerator(a);
    var mac = [];
    var regex1 = /(00:50:56).*/; //OUI of VMware's MAC address.
    var regex2 = /(00:0C:29).*/; //OUI of VMware's MAC address.
    var regex3 = /(00-05-69).*/; //OUI of VMware's MAC address.
    var regex4 = /(00-50-56).*/; //OUI of VMware's MAC address.
    

    for (;!e.atEnd();e.moveNext()){ //Loop over Adapter properties.
        var x = e.item();
        if(x.MACAddress){
            mac[mac.length] = x.MACAddress; 
        }
    }
    
    for (var i=0; i<mac.length; i++) {
        if (mac[i].match(regex1) || mac[i].match(regex2) || mac[i].match(regex3) || mac[i].match(regex4)) {
            isVM = true;
            break;
        }
    }
    
    if(isVM) { 
    	return_result(result_id, "Browser is in a VM");
    } else { 
    	return_result(result_id, "Browser is NOT in a VM"); 
    }
}

vmDetect();
