#ifndef RYAN_INCLUDE
#define RYAN_INCLUDE

int mpi_p, mpi_id;

char *id2string();

#endif
