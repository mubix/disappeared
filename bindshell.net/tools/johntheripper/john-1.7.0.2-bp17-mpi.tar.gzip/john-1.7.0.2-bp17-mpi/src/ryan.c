#include "mpi.h"
#include "ryan.h"
#include <stdio.h>
#include <string.h>

char *id2string() {
	char *temp_name = (char*) malloc(sizeof(char)*10);
	sprintf(temp_name, "%d", mpi_id);
	return temp_name;
}
