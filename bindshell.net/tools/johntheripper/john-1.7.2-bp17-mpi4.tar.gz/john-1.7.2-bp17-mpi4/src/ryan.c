#include "mpi.h"
//#include "ryan.h"
#include <stdio.h>
#include <string.h>

int mpi_p, mpi_id;

char *id2string() {
	char *temp_name = (char*) malloc(sizeof(char)*10);
	sprintf(temp_name, "%d", mpi_id);
	return temp_name;
}
