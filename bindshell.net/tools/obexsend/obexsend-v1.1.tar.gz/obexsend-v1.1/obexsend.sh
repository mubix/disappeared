#!/bin/sh

# Copyright (c) 2005-2009, Wade Alcorn
# Released under the GPL license
# http://www.gnu.org/copyleft/gpl.html

# To find channel use the following comand:
# sdptool search FTRN

usage() 
{
        printf "\n$0 is a basic command line wrapper for obex_test. It \n"
        printf "will push a file to a bluetooth device from the command line\n"
        printf "usage: $0 <MAC> <Channel> <Filename>\n"
        exit
}

ot=`which obex_test`

if [ ! -x "$ot" ]
then
        printf "Error: obex_test not installed, in path or not executable\n"
        usage
fi

if [ $# -ne 3 ] 
then
        usage
fi

if [ ! -r "$3" ]
then
        printf "Error: can't read file $3\n"
        usage
fi


function myFGetFullPath() {
   if [[ -f "$1" ]];then
    echo $(cd $(dirname "$1") && pwd)/$(basename "$1")
   else
    echo "File not found" >&2
   fi
} 

fname=`basename "$3" | sed -e 's/\s/_/g'`
fullpath=`myFGetFullPath "$3"`
tmppath=`mktemp`

ln -s -f "$fullpath" "$tmppath" || exit 3
ls -la "$tmppath"

printf "c\np\n${tmppath} ${fname}\nq\n" | obex_test -b $1 $2

rm "$tmppath"

