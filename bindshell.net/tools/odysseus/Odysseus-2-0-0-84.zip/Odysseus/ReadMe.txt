Odysseus 2.0 - Build 84

- Fixed possible termination issue with IPC thread

- New system tray and XP manifest code.

- Added balloon hint on first run.

Odysseus 2.0 - Build 83

- Cleaned up help system.

- Fixed Listen on loopback only.

- Generated new certificate.  New certificate does not require a passphrase

- Server certificate location defaults to full path of Odysseus executable.

- Changed configuration validation so it is possible to cancel out of the
  dialog even when invalid settings are present.

- Configuration dialog now has it's icon back.

- Changed font on all dialogs to Tahoma.

- Click the close window icon (x) on the intercaptor dialog is now the same
  as clicking Cancel

- Headers are no longer URL decoded since that corrupted cookies containing
  certain characters (notably +)

- Changed default system log name to "Odysseus.log" to better support
  Odysseus and Telemachus running from the same directory.

- Upgraded OpenSSL to libraries 0.9.7f

- Moved upstream proxy name resolution after Winsock initialisation.  This
  means the call stands a chance of succeeding, and the upstream proxy
  enabled flag won't automagically be cleared at startup.
  
- Minor interface changes to SSL options dialog.

Odysseus 2.0 - Build 82

- Fixed interception of replies.

- Fixed processing of HEAD requests

Odysseus 2.0 - Build 80

- Fixed long lived connections
  NTLM authentication will now work again, although you will need to
  configure the Rewriter to add a
  "Proxy-Support: Session-Based-Authentication" header when using Internet
  Explorer.  This is now included in the default Rewriter configuration,
  but needs to be manually enabled.

- Added a missing call to CRYPTO_set_locking_callback().

- Rewriter configuration is now saved to the registry.

- XP Themes Support

Odysseus 2.0 - Build 78

- Implemented Read/Write timeouts on server connection;

- Fixed problem with interception of HTTPS requests. (Interceptor was
  clearing "secure" flag)

- Fixed issue with failed assertion during reply interception.

- Fixed issue with smart interception and reply interception always being
  triggered by request interception reglardless of the presence of a
  Set-Cookie: header.

- Interceptor should no longer intercept transactions to/from filtered sites.

- Fixed issue with headers/variables grids and scroll bars in Interceptor

- Fixed problem with reply intercepts failing.

Odysseus 2.0 - Build 75

* New Proxy Engine

  Hopefully it'll be more stable, although upstream proxy support and NTLM
  authentication have not been tested.

  I'm particularly interested in hearing about any site that fails to work
  with the new proxy engine.

* New Interceptor

  A "Raw" tab has been added.  Tabs should be updated in real-time as
  relevant content changes in other tabs.

  WARNING: Entering strange characters (e.g. %00) in the raw tab and then
  switching to a processed view (e.g. Variables) will cause strange
  behaviour.  If you want to insert icky stuff into a transaction simply
  click "Ok" without leaving the "Raw" tab.

  A "Request Summary" tab is available when intercepting replies.

  A single tab now contains both GET & POST variables allowing variables to
  be quickly changed between GET & POST and vice versa (right-click on the
  variables editor for options to bulk change between variable types).

  Handles requests other than URL Encoded & Multipart Form-data  (mainly by
  disabling variable processing)

  Uses the Content Text Filter to decide if the content should be displayed
  in the text editor.

  Syntax highlighted text editor (for the appropriate content types)

  Target (top left of Interceptor dialog) is now editable

  Double clicking on Secure indicator (top right of Interceptor dialog)
  switches between secure and insecure connection.

  It is now possible to Abort an interception.  The dialog buttons now work
  as follows: "Ok" applies the changes made within the Interceptor and
  continues with the HTTP transaction, "Cancel" ignores any changes made
  within the Interceptor and continues with the original transaction data
  and "Abort" causes everything to appear as if the original request was
  never made.

  I'd be very interested to see any examples of the Interceptor munging
  transactions...

* Rewriter

  Allows regular expression based header re-writing.

  Header lines are processed individually, so ".*" will match head header
  line rather than the entire header text.

  A header can be deleted by not specifying a replacement, and a header can
  be added by not specifying a regular expression.

  WARNING: The Rewriter is capable of much badness, use at your own risk...

* Removed System Log Window

  The system log window has been removed although system log messages are
  still written to the specified file.  Use "tail -f" if you're interested
  in this kind of stuff...

* Smart Interception

  Enabling "Smart Interception" overrides "Intercept Request", "Intercept
  Reply", "Intercept Null Extension" and Extension Filtering.

  Automatically intercepts any request with parameters (GET variables) or
  content (POST variables) and any reply with a Set-Cookie header.  Simply
  set and forget, the Interceptor will appear when something interesting is
  happening...
