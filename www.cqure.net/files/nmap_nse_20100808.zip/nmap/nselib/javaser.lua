module(... or "javaser", package.seeall)


Constants = {
	
	TC_REFERENCE = 0x71,
	TC_CLASSDESC = 0x72,
	TC_OBJECT = 0x73,
	TC_STRING = 0x74,
	TC_ENDBLOCKDATA = 0x78,
	TC_RESET = 0x79,
	TC_NULL = 0x70,
	
	Integer = 0x49,
	Object = 0x4c,
		
	Strings = {
		[0x71] = "Reference",
		[0x49] = "Integer",
		[0x4c] = "Object",
		[0x74] = "String",
	}
}



Socket =
{	
	new = function(self, socket)
		local o = {}
       	setmetatable(o, self)
        self.__index = self
		o.Socket = socket or nmap.new_socket()
		o.Buffer = nil
		return o
	end,
	

	--- Establishes a connection.
	--
	-- @param hostid Hostname or IP address.
	-- @param port Port number.
	-- @param protocol <code>"tcp"</code>, <code>"udp"</code>, or
	-- @return Status (true or false).
	-- @return Error code (if status is false).
	connect = function( self, hostid, port, protocol )
		local status = self.Socket:set_timeout(5000)
		return self.Socket:connect( hostid, port, protocol )
	end,
	
	--- Closes an open connection.
	--
	-- @return Status (true or false).
	-- @return Error code (if status is false).
	close = function( self )
		return self.Socket:close()
	end,
	
	--- Opposed to the <code>socket:receive_bytes</code> function, that returns
	-- at least x bytes, this function returns the amount of bytes requested.
	--
	-- @param count of bytes to read
	-- @return true on success, false on failure
	-- @return data containing bytes read from the socket
	-- 		   err containing error message if status is false
	recv = function( self, count )
		local status, data
	
		self.Buffer = self.Buffer or ""
	
		if ( #self.Buffer < count ) then
			status, data = self.Socket:receive_bytes( count - #self.Buffer )
			if ( not(status) ) then
				return false, data
			end
			self.Buffer = self.Buffer .. data
		end
			
		data = self.Buffer:sub( 1, count )
		self.Buffer = self.Buffer:sub( count + 1)
	
		return true, data	
	end,
	
	--- Sends data over the socket
	--
	-- @return Status (true or false).
	-- @return Error code (if status is false).
	send = function( self, data )
		return self.Socket:send( data )
	end,
}

JavaClass = {
		
	new = function(self)
		local o = {}
       	setmetatable(o, self)
        self.__index = self
		o.fields = {}
		o.isclass = true
		return o
	end,
	
	setName = function( self, name ) self.name = name end,
	setSerialID = function( self, serial ) self.serial = serial	end,
	setFlags = function( self, flags ) self.flags = flags end,
	addField = function( self, field ) 
		table.insert( self.fields, field ) 
		self[field.name] = field
	end,
	
	getName = function( self ) return self.name end,
	getSerialID = function( self ) return self.serial end,
	getFlags = function( self ) return self.flags end,
	getFields = function( self ) return self.fields end,
	getFieldByName = function( self, name )
		for i=1, #self.fields do
			if ( self.fields[i].name == name ) then
				return self.fields[i]
			end
		end
	end,
	
	__tostring = function( self )
		local data = ("%s ["):format(self.name)

		for i=1, #self.fields do
			if ( type(self.fields[i].value) == "table" ) then
				data = data .. ("%s: %s"):format(self.fields[i].name, tostring(self.fields[i].value))
			else
				data = data .. ("%s: %s"):format(self.fields[i].name, self.fields[i].value or "")
			end
			
			if ( i < #self.fields ) then
				data = data .. ";"
			else
				data = data .. "]"
			end

		end
		return data
	end,
}

JavaField = {

	new = function(self, name, typ )
		local o = {}
       	setmetatable(o, self)
        self.__index = self
		o.name = name
		o.type = typ
		return o
	end,

	setType = function( self, typ ) self.type = typ end,
	setSignature = function( self, sig ) self.signature = sig end,
	setName = function( self, name ) self.name = name end,
	setObjectType = function( self, ot ) self.object_type = ot end,
	setReference = function( self, ref ) self.ref = ref end,
	
	getType = function( self ) return self.type end,
	getSignature = function( self ) return self.signature end,
	getName  = function( self ) return self.name end,
	getObjectType = function( self ) return self.object_type end,
	getReference = function( self ) return self.ref end,
	getValue = function( self ) return self.value end,
	
	__tostring = function( self ) return self.value end
}


TypeDecoders =
{
	
	[Constants.Integer] = function( stream )
		local typ = Constants.Integer
		local status, data, len
		local name
	
		status, data = stream:read(2)
		if ( not(status) ) then
			return false, "ERROR: Decoder failed to read 2 bytes"
		end
		
		len = select(2, bin.unpack(">S", data))
		status, data = stream:read(len)
		if ( not(status) ) then
			return false, ("ERROR: Decoder failed to read %d bytes"):format(len)
		end

		name = select(2, bin.unpack("A" .. len, data ) )
		
		return true, JavaField:new( name, typ )
	end,

	[Constants.Object] = function( stream )
		local status, field = TypeDecoders[Constants.Integer]( stream )
		local data, typ, name
		local j_field = JavaField:new()

		if ( not(status) ) then
			return false
		end
		
		status, data = stream:read( 1 )
		if ( not(status) ) then
			return false
		end

		typ = select(2, bin.unpack("C", data) )
		if ( not( TypeDecoders[typ] ) ) then
			return false, ("No decoder for type %d"):format( typ )
		end
		
		name = field:getName()
		status, j_field = TypeDecoders[typ](stream)
				
		field:setName( field:getName() )
		field:setType( Constants.Object )
		field:setSignature( j_field:getName() )
		field:setObjectType( j_field:getType() )
		field:setReference( j_field:getReference() )
				
		return status, field
	end,
	
	[Constants.TC_STRING] = function( stream )
		local status, field = TypeDecoders[Constants.Integer]( stream )

		if ( status ) then
			field:setType( Constants.TC_STRING )
		end
		return status, field
	end,

	[Constants.TC_REFERENCE] = function( stream )
		local status, data = stream:read(4)
		local ref
		local j_field = JavaField:new()
		
		if ( not(status) ) then
			return false, "ERROR: Failed to read 4 bytes of reference"
		end
		
		ref = select(2, bin.unpack(">I", data ) )
		j_field:setType( Constants.TC_REFERENCE )
		j_field:setReference( ref - 0x7E0000 )
		return true, j_field
	end,
	
	[Constants.TC_OBJECT] = function( stream )
		local status, data = stream:read(1)
		local tc = select(2, bin.unpack("C", data))
	
		if ( tc ~= 0x72 ) then
			return false, "ERROR"
		end
		
		return TypeDecoders[Constants.TC_CLASSDESC](stream)
	end,
	
	[Constants.TC_ENDBLOCKDATA] = function( stream )
		return true
	end,

	[Constants.TC_RESET] = function( stream )
		return true
	end,
	
	[Constants.TC_NULL] = function( stream )
		return true
	end,
	
	[Constants.TC_CLASSDESC] = function( stream )
		local status, data, len
		local flags, typ, field, field_count
		local fields = {}
		local j_class = JavaClass:new()
		
		status, data = stream:read(2)
		if( not(status) ) then
			return false, "Failed to decode class"
		end
		len = select(2, bin.unpack(">S", data))		
		
		status, data = stream:read(len)
		if( not(status) ) then
			return false, "Failed to decode class"
		end
		data = select(2, bin.unpack("A" .. len, data))
		j_class:setName( data )

		status, data = stream:read(8)
		if( not(status) ) then
			return false, "Failed to decode class"
		end
		data = select(2, bin.unpack("H8", data))
		j_class:setSerialID(data)
		
		status, data = stream:read(1)
		if( not(status) ) then
			return false, "Failed to decode class"
		end
		flags = select(2, bin.unpack("C", data))
		j_class:setFlags(flags)
		
		status, data = stream:read(2)
		if( not(status) ) then
			return false, "Failed to decode class"
		end
		
		field_count = select(2, bin.unpack(">S", data))

		for i=1, field_count do
			status, data = stream:read(1)
			if( not(status) ) then
				return false, "Failed to decode class"
			end
			typ = select(2, bin.unpack("C", data))

			if ( TypeDecoders[typ] ) then
				status, field = TypeDecoders[typ](stream)
			else
				print("ellol")
				return
			end
						
			if ( field:getType() == Constants.Object and field:getObjectType() == Constants.TC_REFERENCE ) then
				local counter = field:getReference()
				fields = j_class:getFields()
				
				for i=1, #fields do
					if ( fields[i]:getType() == Constants.Object ) then
						counter = counter - 1
					end
					if ( counter == 0 ) then
						field.object_type = fields[i].object_type
						field.signature   = fields[i].signature
					end
				end
				
			end
			
			j_class:addField( field )
		end
		
	
		status, data = stream:read(1)
		if( not(status) ) then
			return false, "Failed to decode class"
		end
		typ = select(2, bin.unpack("C", data))


		if ( Constants.TC_ENDBLOCKDATA ~= typ ) then
			local msg = "Expected a TC_ENDBLOCKDATA, recieved 0x%x"
			stndse.print_debug( msg, typ )
			return false, msg:format(typ)
		end

		return true, j_class
	end,
		
}

ValueDecoders = {
	
	[Constants.Integer] = function( stream )
		local status, value = stream:read(4)
		if( not(status) ) then
			return false, ("Failed to read 4 bytes, when decoding value")
		end
		return true, select(2, bin.unpack(">I", value) )
	end,
	
	[Constants.TC_STRING] = function( stream )
	
		local status, data = stream:read(2)
		local len = select(2, bin.unpack(">S", data))
	
		local status, data = stream:read(len)
				
		return true, select(2, bin.unpack("A" .. len, data ))
	end,

}

SocketInputStream = {

	new = function(self, socket)
		local o = {}
       	setmetatable(o, self)
        self.__index = self
		self.socket = javaser.Socket:new( socket )
		return o
	end,
	
	read = function( self, bytes )
		local status, data = self.socket:recv( bytes )
--		print( select(2, bin.unpack("H"..#data, data)), data)
		
		return status, data
	end,
			
}

FileInputStream = {
	
}

StringInputStream = {
	
	offset = 1,
	
	new = function(self, string)
		local o = {}
       	setmetatable(o, self)
        self.__index = self
		o.string = string
		return o
	end,
	
	read = function( self, bytes )
		local tmp
		
		if ( self.offset > #self.string ) then
			return false, "EOF"
		end
		
		tmp = self.string:sub( self.offset, self.offset + ( bytes - 1 ) )
		self.offset = self.offset + bytes
		
		--print( select(2, bin.unpack("H" .. #tmp, tmp)))
		
		return true, tmp
	end,
	
}

JavaObject = {
	
	new = function(self, stream)
		local o = {}
       	setmetatable(o, self)
        self.__index = self
		o.stream = stream
		return o
	end,
	
	decodeObject = function( self )

		local status, data, typ, class, parent
		local objects = {}
		
		status, class = TypeDecoders[Constants.TC_OBJECT]( self.stream )
		table.insert(objects, class)

		while( true ) do
			-- Next we can have either a field description or a parent object
			status, data = self.stream:read(1)
			if( not(status) ) then
				return false, "Failed to read from socket stream"
			end
			typ = select(2, bin.unpack("C", data))
				
			if ( typ == Constants.TC_CLASSDESC ) then
				local parent
				status, parent = TypeDecoders[typ]( self.stream )
				table.insert( objects, 1, parent )
				-- Begin decoding data?
			elseif ( typ == Constants.TC_NULL ) then
				break
			else
				return false, "error"
			end
		end
		return true, objects		
	end,
	
	decodeValues = function( self, object )
	
		local status, value, data
		local fields 
		
		fields = object:getFields()
		
		for j=1, #fields do
			local typ = fields[j]:getType()
			local ot = fields[j]:getObjectType()
			
			if ( ot and typ == Constants.Object ) then				
				status, data = self.stream:read(1)
				if( not(status) ) then
					return false, "Error failed to read from stream"
				end
				typ = select(2, bin.unpack("C", data))
				
				if ( Constants.TC_OBJECT == typ ) then
					status, value = self:decodeObject()
					value = value[1]
					status = self:decodeValues(value)
					if( not(status) ) then
						return false, "Error failed to decode value"
					end
				elseif( ValueDecoders[typ] ) then
					status, value = ValueDecoders[typ]( self.stream )
				end
			else
				status, value = ValueDecoders[typ]( self.stream )
			end
			
			if ( status ) then
				fields[j].value = value
			end
		end
		return true
	end,
	
	decodeStream = function( self )
	
		local status, data, class, typ
		local objects = {}
	
		if ( not(self.magic) ) then
			status, self.magic = self.stream:read(2)
			if ( not(status) ) then	return false, "decodeStream failed to read from stream"	end
			if ( self.magic ~= string.char(0xAC, 0xED) ) then return false, "Bad Java Magic" end

			status, data = self.stream:read(2)
			if ( not(status) ) then	return false, "decodeStream failed to read from stream"	end
			self.version = select(2, bin.unpack(">S", data))
		end
		
		if ( self.version ~= 5 ) then return false, "Unsupported Java Serialization Version" end
		
		status, data = self.stream:read(1)
		if( not(status) ) then	return false, "decodeStream failed to read from stream"	end
		typ = select(2, bin.unpack("C", data))
		
		if ( Constants.TC_OBJECT == typ ) then
			status, objects = self:decodeObject()
		
			for i=1, #objects do
				local fields = objects[i]:getFields()
				status = self:decodeValues( objects[i] )
				if( not(status) ) then	return false, "Failed to decodeValue"	end
			end
		elseif ( Constants.TC_STRING == typ ) then
			return ValueDecoders[typ]( self.stream )
		elseif ( Constants.TC_ENDBLOCKDATA == typ ) then
			return true
		elseif ( Constants.TC_RESET == typ ) then
			return true
		end

		return true, objects
	end,
}









