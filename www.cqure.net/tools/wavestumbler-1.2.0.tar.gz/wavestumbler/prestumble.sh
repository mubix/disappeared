#    $id$
#!/bin/bash

IFACE=eth1

/sbin/ifconfig $IFACE down
/usr/local/sbin/iwconfig $IFACE enc off
/usr/local/sbin/iwconfig $IFACE essid off
/sbin/ifconfig $IFACE up
