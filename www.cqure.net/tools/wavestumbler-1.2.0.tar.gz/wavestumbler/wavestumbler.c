/* 
   WaveStumbler
   Copyright (C) Patrik Karlsson 2002 - http://www.cqure.net/
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
$Id: wavestumbler.c,v 1.14 2002/02/14 11:52:24 cvs Exp $
$Revision: 1.14 $
*/

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <linux/types.h>
#include <unistd.h>
#include <asm/types.h>
#include <linux/netlink.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <getopt.h>
#include <string.h>
#include <time.h>
#include "config.h"

#ifdef HAVE_NCURSES_H
#include <ncurses.h>
#endif
/*
 * Define some stuff
 */
#define WAVESTUMBLER_VERSION "v1.2.0"
#define TRUE 1
#define FALSE 0
#define ETH_ALEN  6

typedef unsigned short u16;
typedef unsigned char u8;

/* modified by patrik@cqure.net */
/* Grabbed from wlan-ng - Thanks Mark... - Jean II
 * This is the result of a scan inquiry command */
/* Structure describing info about an Access Point */
struct hermes_scan_apinfo {
	u16 channel;		/* Channel where the AP sits */
  	u16 level;		/* Signal level */
  	u16 noise;		/* Noise level */
	u8 bssid[ETH_ALEN];	/* MAC address of the Access Point */
        u16 beacon_interv;      /* Beacon Interval ? */
	u16 capabilities;	/* Capabilities */
        u16 essidlen;           /* ESSID length */
	u8 essid[32];		/* ESSID of the network */
} __attribute__ ((packed));

/*
 * Linkedlist containing information on found APs
 */
typedef struct net_info {
  int channel; /* channel where the AP sits */
  int noise; /* Noise level should be - value */
  int signal; /* Signal level should be - value db */
  unsigned char MAC[ETH_ALEN]; /* MAC address of AP */
  int capabilities; /* capabilities bit-4 = WEP */
  unsigned char essid[32]; /* essid should not be more than 32 bytes */
  int essidlen; /* length of netname */
  time_t t_first; /* timestamp when net is first seen */
  time_t t_last; /* timestamp when net was last seen */
  time_t t_maxsignal; /* timestamp when signal was at maximum */
  struct net_info *next;
} NETINFO;


#define MCAST_GRP_APSCAN 0x00000002
static char stop_scanning = 0; /* when set to one stop scanning */
static char refresh_screen = 0; /* should the screen be refreshed */
static char bShowAll = 1; /* show all information */
static char bDebug = 0; /* should we run in debug mode */

/*
 * Parameters for scanning
 */
struct scan_params {
  char *pProcLoc;
  int ScanDelay;
  int nlfd;
  FILE *ReportFile;
};

/*
 * Did someone press CTRL-break ?
 */
void stop_signal () {
  stop_scanning = 1;
}

/*
 * Output everything on one line
 */
void outputAPInfoLineMode(FILE *fd, NETINFO *pInfo) {
  
  int i;
  struct tm *t;

  t = localtime(&pInfo->t_first);

  fprintf(fd, "%02d:%02d:%02d  ", t->tm_hour, t->tm_min, t->tm_sec );

  if ( bShowAll ) {
    t = localtime(&pInfo->t_maxsignal);
    fprintf(fd, "%02d:%02d:%02d  ", t->tm_hour, t->tm_min, t->tm_sec );

    t = localtime(&pInfo->t_last);
    fprintf(fd, "%02d:%02d:%02d ", t->tm_hour, t->tm_min, t->tm_sec );
  }

  fprintf(fd, "%-4d", pInfo->channel);
  fprintf(fd, "-%-4d", pInfo->noise);
  fprintf(fd, "-%-4d ", pInfo->signal);
  
  for ( i=0; i<sizeof(pInfo->MAC); i++ ) {
    fprintf(fd, "%02X", pInfo->MAC[i]);
    if ( i<ETH_ALEN-1 )
      fprintf(fd, ":");
  }
  fprintf(fd, "  ");

  /* bit0: ess, bit1: ibss, bit4: wep */
  if ( pInfo->capabilities & 16 ) {
    fprintf(fd, "Y");
  }
  else {
    fprintf(fd, "N");
  }
  
  fprintf(fd, "   %s", pInfo->essid);
  
  fprintf(fd, "\n");


}

#ifdef HAVE_NCURSES_H
/*
 * Output everything on one line using curses
 */
void outputAPInfoLineCursesMode(NETINFO *pInfo) {
  
  int i;
  struct tm *t;

  t = localtime(&pInfo->t_first);
  printw("%02d:%02d:%02d  ", t->tm_hour, t->tm_min, t->tm_sec );

  if ( bShowAll ) {
    t = localtime(&pInfo->t_maxsignal);
    printw("%02d:%02d:%02d  ", t->tm_hour, t->tm_min, t->tm_sec );

    t = localtime(&pInfo->t_last);
    printw("%02d:%02d:%02d ", t->tm_hour, t->tm_min, t->tm_sec );
  }

  printw("%-4d", pInfo->channel);
  printw("-%-4d", pInfo->noise);
  printw("-%-4d ", pInfo->signal);
  
  for ( i=0; i<sizeof(pInfo->MAC); i++ ) {
    printw("%02X", pInfo->MAC[i]);
    if ( i<ETH_ALEN-1 )
      printw(":");
  }
  printw("   ");

  /* bit0: ess, bit1: ibss, bit4: wep */
  if ( pInfo->capabilities & 16 ) {
    printw("Y");
  }
  else {
    printw("N");
  }
  
  printw("   %s", pInfo->essid);
  printw("\n");

}
#endif

/*
 * Go through linked list and print networks
 * This is called once a new network is detected with the new net as param
 * Which means that only the new net will be outputed
 */
void outputDiscoveredNetworks( FILE *fd, NETINFO *pNetworks ) {

  NETINFO *pInfo = pNetworks;

  while( pInfo ) {
#ifndef HAVE_NCURSES_H
    outputAPInfoLineMode(fd, pInfo);
#else
    if ( fd != stdout )
      outputAPInfoLineMode(fd, pInfo);

    outputAPInfoLineCursesMode(pInfo);
#endif
    pInfo = pInfo->next;
  }

}

/*
 * Delete all networks in linkedlist
 */
void deleteNetworks( NETINFO *pNetWorks ) {
   
  NETINFO *curr, *del;
  
  curr = pNetWorks;
  
  while ( curr ) {
    del = curr;
    curr = curr->next;
    free(del);
  }
  
}

/*
 * Compare if two ESSIDs are the same
 */
int cmpESSID( unsigned char *ESSID1, unsigned char *ESSID2) {

  int i;

  for ( i=0; i<32; i++ ) {
    if ( ESSID1[i] != ESSID2[i] )
      return FALSE;
  }

  return TRUE;

}

/*
 * Compare if two MAC adresses are the same
 */
int cmpMAC(unsigned char *MAC1, unsigned char *MAC2) {

  int i;

  for ( i=0; i<6; i++ ) {
    if ( MAC1[i] != MAC2[i] )
      return FALSE;
  }

  return TRUE;

}

/*
 * Updates signal levels on previusly detected networks
 */
void updateNet(NETINFO *pOldNet, NETINFO *pNewNet) {

  if ( pOldNet->signal < pNewNet->signal ) {
    pOldNet->signal      = pNewNet->signal;
    pOldNet->t_maxsignal = time(NULL);
    /* refresh_screen = 1; */
  }

  pOldNet->t_last = time(NULL);

}

/*
 * Add a network to the linked list
 */
NETINFO *addNet(NETINFO *pNets, NETINFO *pNewNet) {

  NETINFO *net;

  net = pNets;

  while ( net ) {

    /* do we have a net with this name ? */
    if ( cmpESSID( net->essid, pNewNet->essid ) ) {
      /* does the AP have the same MAC */
      if ( cmpMAC( net->MAC, pNewNet->MAC ) ) {
	/* is it on the same channel ? */
	if ( net->channel == pNewNet->channel ) {
	  if ( net->capabilities == pNewNet->capabilities ) {
	    /* return pNets; */
	    updateNet( net, pNewNet );
	    return pNets;
	  } /* end capabilities */

	} /* end cmp channel */

      } /* end cmpMAC */

    } /* end strcmp essid */

    net = net->next;

  }

  /* does the AP sit on channel 0, if so something wrong, dont add it */
  if ( pNewNet->channel == 0 )
    return pNets;

  /* is the essidlen bigger than 32, somethings wrong, dont add it */
  if ( pNewNet->essidlen > 32 )
    return pNets;

  /* seems to be a new net */
  pNewNet->t_first = time(NULL);
  net = ( NETINFO * ) malloc ( sizeof ( NETINFO ) );
  memcpy(net, pNewNet, sizeof( NETINFO ) );
  net->next = pNets;
  refresh_screen = 1;

  return net;

}

/*
 * Output header
 */
void outputAPInfoHeader(FILE *fd) {
  if ( bShowAll ) {
    fprintf(fd, "FrstSeen  MAXSign.  LastSeen CH   NSE  SGN  MAC               WEP  ESSID\n");
    fprintf(fd, "------------------------------------------------------------------------\n");
  }
  else {
    fprintf(fd, "Time      CH   NSE  SGN  MAC               WEP  ESSID\n");
    fprintf(fd, "-----------------------------------------------------\n");
  }
}

#ifdef HAVE_NCURSES_H
/*
 * Output header cursor
 */
void outputAPInfoCursesHeader(FILE *fd) {
  if ( bShowAll ) {
    printw("FrstSeen  MaxSign.  LastSeen CH   NSE  SGN  MAC                WEP  ESSID\n");
    printw("-------------------------------------------------------------------------\n");
  }
  else {
    printw("Time      CH   NSE  SGN  MAC               WEP  ESSID\n");
    printw("-----------------------------------------------------\n");
  }
}
#endif

/*
 * Output footer
 */
void outputAPInfoFooter(FILE *fd) {
  fprintf(fd, "-- WaveStumbler http://www.cqure.net/wavestumbler --\n");
}

/*
 * Dump the HEX packet as debuginfo
 */
void dumpBufAsHex(unsigned char *pBuf, int nLen) {
  
  int i;

  for ( i=0; i<nLen; i ++ ) {
    fprintf(stderr, "%02X ", pBuf[i]);
  }

  fprintf(stderr, "\n");

}

/*
 * Process and go through APInfo
 */
void processNetInfoData(NETINFO *pNetInfo, unsigned char *pBuf, int nLen) {

  int i;
  
  pNetInfo->t_last      = time(NULL);
  pNetInfo->t_maxsignal = time(NULL);

  pNetInfo->channel = pBuf[1]*256+pBuf[0];
  pNetInfo->signal = pBuf[3]*256+pBuf[2];
  pNetInfo->noise = pBuf[5]*256+pBuf[4];
  
  for ( i=0; i<ETH_ALEN; i++ )
    pNetInfo->MAC[i] = pBuf[6+i];
  
  pNetInfo->capabilities=pBuf[9+ETH_ALEN]*256+pBuf[8+ETH_ALEN];
  pNetInfo->essidlen = pBuf[11+ETH_ALEN]*256+pBuf[10+ETH_ALEN];
  
  memset(pNetInfo->essid, 0, sizeof(pNetInfo->essid));

  /* Something seems to be fucked up */
  if ( pNetInfo->essidlen > 32 )
    return;

  for ( i=0; i<pNetInfo->essidlen; i++ ) {
    pNetInfo->essid[i] = pBuf[i+12+ETH_ALEN];
  }


}

/*
 * Scanner sends "apstumble" to /proc filesystem
 */
void scanner(struct scan_params *sp) {
  
  FILE *fd;

  if ( ( fd = fopen(sp->pProcLoc, "w") ) == NULL ) {
    fprintf(stderr, "ERROR: Could not write to %s\n", sp->pProcLoc);
    stop_scanning = 1;
    return;
  }

  fprintf(fd, "apscan");
  fclose(fd);

}

/*
 * Read info from the netlinksocket until CTRL-C is pressed
 */
void doScan(struct scan_params *scanparams) {

  fd_set rfds;
  struct timeval tv;
  int retval;
  unsigned char buf[sizeof(struct hermes_scan_apinfo)];
  int recvlen;
  NETINFO netinfo, *networks = NULL, *lastnet = NULL;
  time_t last_refresh;

  netinfo.next = NULL;
  last_refresh = time(NULL);

  while ( !stop_scanning ) {

    memset(buf, 0, sizeof(buf));
    
    FD_ZERO(&rfds);
    FD_SET(scanparams->nlfd, &rfds);
    /* Wait up to five seconds. */
    tv.tv_sec = 0; /* scanparams->ScanDelay; */
    tv.tv_usec = 1000 * scanparams->ScanDelay;

    if ( ( time(NULL) - last_refresh ) == 10 ) {
      last_refresh = time(NULL);
      refresh_screen = 1;
    }

    /* wait ScanDelay seconds for data to be available */
    retval = select(scanparams->nlfd+1, &rfds, NULL, NULL, &tv);
  
    /* is data available ?!*/
    if ( retval && !stop_scanning) {

      /* clear the buffer before reading to it */
      memset(buf, 0, sizeof(buf));

      if ((recvlen = recv (scanparams->nlfd, buf, sizeof(buf), 0)) < 0) {
	fprintf (stderr,"Error in recvfrom (%d)", recvlen);
	perror ("");
	exit (0);
      }
      
      else {
	if ( bDebug ) {
	  fprintf(stderr, "Read %d of bytes\n", recvlen);
	  dumpBufAsHex(buf, recvlen);
	}

	processNetInfoData(&netinfo, buf, recvlen);
	lastnet = networks;
	networks = addNet(networks, &netinfo); 

	if ( lastnet != networks || refresh_screen ) {

#ifdef HAVE_NCURSES_H
	  clear();
	  /* printw ("-- WaveStumbler %s (C) 2002 patrik@cqure.net --\n", WAVESTUMBLER_VERSION); */
	  outputAPInfoCursesHeader(stdout);
	  outputDiscoveredNetworks(stdout, networks);
	  refresh();
#else
	  fprintf(stdout, "\033[2J"); /* should do the trick on most terminals */
	  fprintf(stdout, "-- WaveStumbler %s (C) 2002 patrik@cqure.net --\n", WAVESTUMBLER_VERSION);
	  outputAPInfoHeader(stdout);
	  outputDiscoveredNetworks(stdout, networks);
#endif
	  /* OK we have refreshed the screen */
	  refresh_screen = 0;

	} /* end lastnet refresh */

      }

    } /* end retval */
    /* no data available, send scanrequest */
    else {
      scanner(scanparams);
    }

  } /* end while loop */

  /* Log all found Networks to reportfile */
  if ( scanparams->ReportFile != NULL ) {
    outputDiscoveredNetworks(scanparams->ReportFile, networks);
  }


  deleteNetworks(networks);

}

/*
 * Someone seems to be in trouble
 */
void usage(char **argv) {

  fprintf(stdout, "\n\tWaveStumbler %s by Patrik Karlsson <patrik@cqure.net>\n", WAVESTUMBLER_VERSION);
  fprintf(stdout, "\t---------------------------------------------------------\n");
  fprintf(stdout, "\tusage: %s [options]\n\n", argv[0]);
  fprintf(stdout, "\t\t-i*\t<interface>\n");
  fprintf(stdout, "\t\t-d*\t<delay in ms> (should be greater than 100)\n");
  fprintf(stdout, "\t\t-r\t<reportfile>\n");
  fprintf(stdout, "\t\t-m\treduce shown information to minimum\n");
  fprintf(stdout, "\t\t-v\tbe verbose (show debug info)\n");
  fprintf(stdout, "\n\n");

}

/*
 * The main part
 */
int main (int argc, char **argv) {

  struct sockaddr_nl nl_sk_addr;
  char proc_loc[128];
  struct scan_params scanparams;
  int c;
  char iface[10]; /* 3 should be enough, but hey I'm flexible */

  scanparams.pProcLoc = proc_loc;
  scanparams.ScanDelay = 0;
  scanparams.ReportFile = NULL;

  memset(iface, 0, sizeof(iface));
  
  while (1) {

    c = getopt(argc, argv, "i:d:r:hvm");

    if ( c == -1 ) 
      break;

    switch (c) {
      
    case 'm':
      bShowAll = 0; /* don't show all neat stuff */
      break;

    case 'i':
      if ( strlen(optarg) > 10 ) {
	fprintf(stderr, "ERROR: Interface arg. to long !\n");
	exit(1);
      }
      strncpy(iface, optarg, strlen(optarg));
      break;

    case 'd':
      scanparams.ScanDelay = atoi(optarg);
      if ( scanparams.ScanDelay < 100 ) {
	usage(argv);
	exit(1);
      }
      break;

    case 'h':
      usage(argv);
      exit(1);

    case 'v':
      bDebug = TRUE;
      break;

    case 'r':
      scanparams.ReportFile = fopen(optarg, "a");
      if ( scanparams.ReportFile == NULL ) {
	fprintf(stderr, "ERROR: Creating report file\n");
	exit(1);
      }
      break;
      
    default:
      usage(argv);
      exit(1);
    }
  } /* end getopt */

  /* Do we have an interface and a TimeOut */
  if ( strlen(iface) == 0 || scanparams.ScanDelay == 0 ) {
    usage(argv);
    exit(1);
  }

  /* construct path to procfile */
  memset(proc_loc, 0, sizeof(proc_loc));
  sprintf(proc_loc, "/proc/hermes/%s/cmds", iface);
  fprintf (stdout, "-- WaveStumbler %s (C) 2002 patrik@cqure.net --\n", WAVESTUMBLER_VERSION);

  /* register signal handler for CTRL-break */
  signal (SIGINT, stop_signal);

  /* Create a netlink socket to communicate with kernel driver */
  if ((scanparams.nlfd = socket (PF_NETLINK, SOCK_RAW, MCAST_GRP_APSCAN)) < 0) {
    perror ("Could not create socket");
  }

  /* setup netlink socket to read info from driver */
  memset (&nl_sk_addr, 0, sizeof (struct sockaddr_nl));
  nl_sk_addr.nl_family = (sa_family_t) PF_NETLINK;
  nl_sk_addr.nl_pid = (unsigned int) getpid ();
  nl_sk_addr.nl_groups = MCAST_GRP_APSCAN;

  /* bind the socket */
  if (bind(scanparams.nlfd, (struct sockaddr *) &nl_sk_addr, sizeof (struct sockaddr_nl)) < 0) {
    perror ("Call to bind failed");
    return 1;
  }

  /* should we write the header to a report file ? */
  if ( scanparams.ReportFile != NULL )
    outputAPInfoHeader(scanparams.ReportFile);

  /* output header to stdout */
#ifndef HAVE_NCURSES_H
  outputAPInfoHeader(stdout);
#else
  initscr();
#endif

  /* enter the scanning loop */
  doScan(&scanparams);

#ifdef HAVE_NCURSES_H
  endwin();
#endif
  
  /* should we write the footer to a report file */
  if ( scanparams.ReportFile != NULL ) {
      outputAPInfoFooter(scanparams.ReportFile);
      fclose(scanparams.ReportFile);
  }
  
  /* write the footer to screen */
  outputAPInfoFooter(stdout);

  /* Hey I'm outa here */
  return 0;

}
