--- Library methods for handling LDAP. 
--
-- @author Patrik Karlsson
-- @copyright Same as Nmap--See http://nmap.org/book/man-legal.html
--
-- Credit goes out to Martin Swende who provided me with the initial code that got me started writing this.
--
-- Version 0.1
-- Created 01/12/2010 - v0.1 - created by Patrik Karlsson <patrik@cqure.net>

module("ldap", package.seeall)
require 'asn1'

local ldapMessageId = 1

ERROR_MSG = {}
ERROR_MSG[1]  = "Intialization of LDAP library failed."
ERROR_MSG[4]  = "Size limit exceeded."
ERROR_MSG[49] = "The supplied credential is invalid."

ERRORS = {
	LDAP_SUCCESS = 0,
	LDAP_SIZELIMIT_EXCEEDED = 4
}

APPNO = {
	BindRequest = 0,
	BindResponse = 1,
	UnbindRequest = 2,
	SearchRequest = 3,
	SearchResponse = 4,
	SearchResDone = 5	
}

FILTER = {
	_and = 0,
	_or = 1,
	_not = 2,
	equalityMatch = 3,
	substrings = 4,
	greaterOrEqual = 5,
	lessOrEqual = 6,
	present = 7,
	approxMatch = 8,
	extensibleMatch = 9
}

SCOPE = {
	base=0, 
	one=1, 
	sub= 2, 
	children=3, 
	default = 0
}

DEREFPOLICY = {
	never=0,
	searching=1,
	finding = 2,
	always=3,
	default = 0
}


---
-- Decodes a sequence according to ASN.1 basic encoding rules.
-- @param encStr Encoded string.
-- @param len Length of sequence in bytes.
-- @param pos Current position in the string.
-- @return The position after decoding.
-- @return The decoded sequence as a table.
local function decodeSeq(encStr, len, pos)
	--print("decoding seq")
	local seq = {}
	local sPos = 1
	local i = 1
	local sStr
	--print("len,pos,encStr",len,pos,encStr)
	pos, sStr = bin.unpack("A" .. len, encStr, pos)
	--print("sStr,pos",sStr,pos)
	if(sStr==nil) then 
		return pos,seq
	end
	while (sPos < len) do
		local newSeq
		sPos, newSeq = asn1.decode(sStr, sPos)
		table.insert(seq, newSeq)
		i = i + 1
	end
	return pos, seq
end

-- Encodes an LDAP Application operation and its data as a sequence
--
-- @param appno LDAP application number @see <code>APPNO</code>
-- @param isConstructed boolean true if constructed, false if primitive
-- @param data string containing the LDAP operation content
-- @return string containing the encoded LDAP operation
function encodeLDAPOp( appno, isConstructed, data )
	
	local encoded_str = ""
		
	local asn1_type = asn1.BERtoInt( asn1.BERCLASS.Application, isConstructed, appno )
	encoded_str = asn1.encode( { _ldaptype = bin.pack("A", string.format("%X", asn1_type)), data } )
	
	return encoded_str
	
end

--- Performs an LDAP Search request
--
-- This function has a concept of softerrors which populates the return tables error information
-- while returning a true status. The reason for this is that LDAP may return a number of records
-- and then finnish of with an error like SIZE LIMIT EXCEEDED. We still want to return the records
-- that were received prior to the error. In order to achieve this and not terminating the script
-- by returning a false status a true status is returned together with a table containing all searchentries.
-- This table has the <code>errorMessage</code> and <code>resultCode</code> entries set with the error information.
-- As a <code>try</code> won't catch this error it's up to the script to do so. @see ldap-search.nse for an example.
--
-- @param socket socket already connected to the ldap server
-- @param params table containing at least <code>scope</code>, <code>derefPolicy</code> and <code>baseObject</code>
-- @return success true or false. 
-- @return err string containing error message
function searchRequest( socket, params )

	local searchResEntries = { errorMessage="", resultCode = 0}

	local catch = function()
		socket:close()
		stdnse.print_debug(string.format("SearchRequest failed"))
	end
	
	local try = nmap.new_try(catch)

	local attributes = params.attributes

	local request = asn1.encode(params.baseObject)
	request = request .. asn1.encode( { _ldap='0A', params.scope } )--scope
	request = request .. asn1.encode( { _ldap='0A', params.derefPolicy } )--derefpolicy
	request = request .. asn1.encode( params.sizeLimit or 0)--sizelimit
	request = request .. asn1.encode( params.timeLimit or 0)--timelimit
	request = request .. asn1.encode( params.typesOnly or false)--TypesOnly
	
	if params.filter then
		request = request .. createFilter( params.filter )
	else
		request = request .. asn1.encode( { _ldaptype='87', "objectclass" } )-- filter : string, presence
	end
	
	local attrSeq = ''
	if  attributes~= nil then
		for _,attr in ipairs(attributes) do 
			attrSeq = attrSeq .. asn1.encode(attr)
		end 
	end

	request = request .. asn1.encodeSeq(attrSeq)
	
	local requestData = encodeLDAPOp(APPNO.SearchRequest, true, request)
	
	local messageSeq = asn1.encode(ldapMessageId) 
	ldapMessageId = ldapMessageId +1
	
	messageSeq = messageSeq .. requestData
	 
	local data = asn1.encodeSeq(messageSeq)
	try( socket:send( data ) )

	local data = ""

	while true do
		local len = 0
		local tmp = ""
		local pos = 2
		local messageId = -1
		local _
		local objectName
		local attributes
		
		if data:len() > 6 then
			pos, len = asn1.decodeLength( data, pos )
		else
			data = data .. try( socket:receive() )
			pos, len = asn1.decodeLength( data, pos )
		end

		-- pos should be at the right position regardless if length is specified in 1 or 2 bytes
		while ( len + pos - 1 > data:len() ) do
			data = data .. try( socket:receive() )
		end
		
		pos, messageId = asn1.decode( data, pos )
		pos, tmp = bin.unpack("C", data, pos)
		pos, len = asn1.decodeLength( data, pos )
		local ldapOp = asn1.intToBER( tmp )
		local searchResEntry = {}
		
		if ldapOp.number == APPNO.SearchResDone then
			pos, searchResEntry.resultCode = asn1.decode( data, pos )
			-- print(string.format( "%d", searchResEntry.resultCode ))

			-- errors may occur after a large amount of data has been received (eg. size limit exceeded)
			-- we want to be able to return the data received prior to this error to the user
			-- however, we also need to alert the user of the error. This is achieved through "softerrors"
			-- softerrors populate the error fields of the table while returning a true status
			-- this allows for the caller to output data while still being able to catch the error
			if ( searchResEntry.resultCode ~= 0 ) then
				pos, searchResEntry.matchedDN = asn1.decode( data, pos )
				pos, searchResEntry.errorMessage = asn1.decode( data, pos )

				local error_msg = ERROR_MSG[searchResEntry.resultCode] 
				
				-- if the table is empty return a hard error
				if #searchResEntries == 0 then
					return false, string.format("Error: %s\nDetails: %s", error_msg or "", searchResEntry.errorMessage or "" )
				else
					searchResEntries.errorMessage = string.format("Error: %s; Details: %s", error_msg or "", searchResEntry.errorMessage or "" )
					searchResEntries.resultCode = searchResEntry.resultCode
					return true, searchResEntries
				end
				
			end
			
			break
		end

		pos, searchResEntry.objectName = asn1.decode( data, pos )
		
		if ldapOp.number == APPNO.SearchResponse then
			pos, searchResEntry.attributes = asn1.decode( data, pos )
					
			table.insert( searchResEntries, searchResEntry )
		end
		
		if data:len() > pos then
			data = data:sub(pos)
		else
			data = ""
		end
		
	end
	
	return true, searchResEntries
	
end


--- Attempts to bind to the server using the credentials given
--
-- @param socket socket already connected to the ldap server
-- @param params table containing <code>version</code>, <code>username</code> and <code>password</code>
-- @return success true or false
-- @return err string containing error message
function bindRequest( socket, params )

	local catch = function()
		socket:close()
		stdnse.print_debug(string.format("bindRequest failed"))
	end
	
	local try = nmap.new_try(catch)
	
	local ldapAuth = asn1.encode( { _ldaptype = 80, params.password } )
	local bindReq = asn1.encode( params.version ) .. asn1.encode( params.username ) .. ldapAuth
	local ldapMsg = asn1.encode(ldapMessageId) .. encodeLDAPOp( APPNO.BindRequest, true, bindReq )
	
	local packet = asn1.encodeSeq( ldapMsg )
	
	ldapMessageId = ldapMessageId +1
	try( socket:send( packet ) )
	packet = try( socket:receive() )
	
	local pos, packet_len, ldapMessageId, resultCode, tmp, len, _
	local response = {}
	
	pos, packet_len = asn1.decodeLength( packet, 2 )
	pos, response.messageID = asn1.decode( packet, pos )
	
	stdnse.print_debug( string.format("MessageId: %d", response.messageID ) )
	stdnse.print_debug( string.format("pos: %d; len: %d", pos, 11 ) )
	
	pos, tmp = bin.unpack("C", packet, pos)
	pos, len = asn1.decodeLength( packet, pos )
	response.protocolOp = asn1.intToBER( tmp )

	stdnse.print_debug( string.format("pos: %d; len: %d", pos, len ) )

	if response.protocolOp.number ~= APPNO.BindResponse then
		return false, string.format("Recieved incorrect Op in packet: %d, expected %d", response.protocolOp.number, APPNO.BindResponse)
	end

	stdnse.print_debug("ldapOp: %d", response.protocolOp.number)
	
	pos, response.resultCode = asn1.decode( packet, pos )

	stdnse.print_debug("resultCode: %d", response.resultCode)

	
	if ( response.resultCode ~= 0 ) then
		pos, response.matchedDN = asn1.decode( packet, pos )
		pos, response.errorMessage = asn1.decode( packet, pos )
		
		local error_msg = ERROR_MSG[response.resultCode] 
		
		return false, string.format("Error: %s\nDetails: %s", error_msg or "", response.errorMessage or "" )
	else
		return true, "Success"
	end
	
end

--- Performs an LDAP Unbind
--
-- @param socket socket already connected to the ldap server
-- @return success true or false
-- @return err string containing error message
function unbindRequest( socket )

	local catch = function()
		socket:close()
		stdnse.print_debug(string.format("bindRequest failed"))
	end
	
	local try = nmap.new_try(catch)

	ldapMessageId = ldapMessageId +1
	
	local ldapMsg = asn1.encode( ldapMessageId )
	

	ldapMsg = ldapMsg .. encodeLDAPOp( APPNO.UnbindRequest, false, nil)
	
	local packet = asn1.encodeSeq( ldapMsg )
	
	try( socket:send( packet ) )

	return true, ""
	
end


--- Creates an ASN1 structure from a filter table
--
-- @param filter table containing the filter to be created
-- @return string containing the ASN1 byte sequence
function createFilter( filter )
	
	local asn1_type = asn1.BERtoInt( asn1.BERCLASS.ContextSpecific, true, filter.op )
	local filter_str = ""

	if type(filter.val) == 'table' then
		for _, v in ipairs( filter.val ) do
			filter_str = filter_str .. createFilter( v )
		end
	else
		local obj = asn1.encode( filter.obj ) 
		local val = asn1.encode( filter.val )
		
		filter_str = filter_str .. obj .. val
		--filter_str = filter_str .. asn1.encode( { _ldaptype=bin.pack("A", string.format("%X", asn1_type)), obj .. val } )
	end
	
	return asn1.encode( { _ldaptype=bin.pack("A", string.format("%X", asn1_type)), filter_str } )
	
end

--- Converts a search result as received from searchRequest to a "result" table
--
-- Does some limited decoding of LDAP attributes
--
-- TODO: Add decoding of missing attributes
-- TODO: Add decoding of userParameters
-- TODO: Add decoding of loginHours
--
-- @param searchEntries table as returned from searchRequest
-- @return table suitable for <code>stdnse.format_output</code>
function searchResultToTable( searchEntries )

	local result = {}
		
	for _, v in ipairs( searchEntries ) do
		
		stdnse.print_debug("dn: %s", v.objectName)
		local result_part = {}
	
		if v.objectName and v.objectName:len() > 0 then
			result_part.name = string.format("dn: %s", v.objectName) 
		else
			result_part.name = "<ROOT>"
		end
	
		
		local attribs = {}
		
		if ( v.attributes ~= nil ) then
			
			for _, attrib in ipairs( v.attributes ) do
		
				for i=2, #attrib do
								
					-- do some additional Windows decoding
					if ( attrib[1] == "objectSid" ) then
						table.insert( attribs, string.format( "%s: %d", attrib[1], asn1.decode( attrib[i] ) ) )
					elseif ( attrib[1] == "objectGUID") then
						local _, o1, o2, o3, o4, o5, o6, o7, o8, o9, oa, ob, oc, od, oe, of = bin.unpack("C16", attrib[i] )
						table.insert( attribs, string.format( "%s: %x%x%x%x-%x%x-%x%x-%x%x-%x%x%x%x%x", attrib[1], o4, o3, o2, o1, o5, o6, o7, o8, o9, oa, ob, oc, od, oe, of ) )
					else
						table.insert( attribs, string.format( "%s: %s", attrib[1], attrib[i] ) )
					end

				end
			
			end
									
			table.insert( result_part, attribs )
		
		end		
		
		
		table.insert( result, result_part )
	
	end

	return result
	
end


--- Extract naming context from a search response
--
-- @param searchEntries table containing searchEntries from a searchResponse
-- @param attributeName string containing the attribute to extract
-- @return table containing namingcontexts
function extractAttribute( searchEntries, attributeName )

	local attributeTbl = {}

	for _, v in ipairs( searchEntries ) do

		if ( v.attributes ~= nil ) then
			
			for _, attrib in ipairs( v.attributes ) do

				local attribType = attrib[1]
		
				for i=2, #attrib do								

					if attribType == attributeName then
						table.insert( attributeTbl, attrib[i])
					end

				end
			
			end
		end
	end
	
	return attributeTbl
	
end