#!/bin/sh
#
# Wrapper for OracleSamDump by patrik.karlsson@ixsecurity.com
#

JAVA=java
JDBC=classes111.zip
$JAVA -cp .:$JDBC:ork.jar ork.OracleSamDump $*