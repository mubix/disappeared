#!/bin/sh
#
# Wrapper for OracleQuery by patrik@cqure.net
#

JAVA=java
JDBC=classes111.zip
$JAVA -cp .:$JDBC:ork.jar ork.OracleQuery $*
