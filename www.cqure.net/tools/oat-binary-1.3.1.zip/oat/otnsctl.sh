#!/bin/sh
#
# Wrapper for OracleTNSCtrl by patrik.karlsson@ixsecurity.com
#

JAVA=java
JDBC=classes111.zip
$JAVA -cp .:$JDBC:ork.jar ork.OracleTNSCtrl $*