/*
   VNC Password Dumper
   Copyright (c) 2006 Patrik Karlsson

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
	CHANGES:
			2003-02-24 Rewrote entire code in this file

*/

#include <windows.h>
#include <tlhelp32.h>
#include <winnt.h>
#include <stdio.h>
#include <stdlib.h>

DWORD32 GetPidByName( char *pProc ) {

	HANDLE hSnap;
	PROCESSENTRY32 pe32;

	hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	pe32.dwSize = sizeof( PROCESSENTRY32 );
	Process32First( hSnap, &pe32 );
	
	while ( 1 ) {
		if ( !stricmp( pProc, pe32.szExeFile ) )
			return pe32.th32ProcessID;
		if ( !Process32Next( hSnap, &pe32 ) )
			break;
	}
	
	CloseHandle( hSnap );
	return 0;

}

DWORD32 ListPidsByUser( char *pUser ) {

	HANDLE hSnap, h, hToken;
	PROCESSENTRY32 pe32;
	TOKEN_USER *pTU;
	SID_NAME_USE snuse;
	char szOwner[1024];
	char szDomain[1024];
	DWORD dwOwnLen;
	DWORD dwDomLen;
	DWORD dwUserLen = 512;
	DWORD dwLen;

	hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	pe32.dwSize = sizeof( PROCESSENTRY32 );
	Process32First( hSnap, &pe32 );
	
	while ( ( Process32Next( hSnap, &pe32 ) ) ) {

		h = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pe32.th32ProcessID );

		hToken = NULL;

		if ( h )
			OpenProcessToken(h, TOKEN_QUERY, &hToken );
		
		pTU = (TOKEN_USER *) malloc( dwUserLen );
			
		if ( !pUser ) {
			fprintf(stderr, "ERROR: failed to malloc %d bytes of mem\n", dwUserLen );
			exit(1);
		}
			
		if ( hToken && !GetTokenInformation( hToken, TokenUser, pTU, dwUserLen, &dwLen ) ) {
			fprintf(stderr, "ERROR: GetTokenInformation()\n");
			exit(1);
		}

		dwDomLen = sizeof( szDomain );
		dwOwnLen = sizeof( szOwner );
		LookupAccountSid( NULL, pTU->User.Sid, (char *)&szOwner, &dwOwnLen, 
							(char *)&szDomain, &dwDomLen, &snuse );

		free( pTU );

		if ( hToken )
			CloseHandle( hToken );
			
		if ( h )
			CloseHandle( h );
			
		if ( stricmp( szOwner, pUser) == 0 ) {
			fprintf(stdout, "%d,%s\n", pe32.th32ProcessID, pe32.szExeFile );
		}			

	}
	
	CloseHandle( hSnap );
	return FALSE;

}