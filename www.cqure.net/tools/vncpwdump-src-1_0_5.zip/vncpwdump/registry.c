#include <windows.h>
#include <winnt.h>
#include "vncpwdump.h"

VOID FreeList( struct keylist *p ) {

	struct keylist *pCur = p, *pRmv;

	while ( pCur ) {
		pRmv = pCur;
		pCur = pCur->next;
		free( pRmv->pKeyValue );
		free( pRmv );
	}

}

struct keylist *AddListItem( struct keylist *pK, CONST CHAR *pKeyValue ) {

	struct keylist *pNewKey;
	int nKeyLen = strlen( pKeyValue ) + 1;

	pNewKey = (struct keylist *)malloc( sizeof( struct keylist ) );
	pNewKey->pKeyValue = (CHAR *)malloc( nKeyLen );
	ZeroMemory( pNewKey->pKeyValue, nKeyLen );
	strcpy( pNewKey->pKeyValue, pKeyValue );
	pNewKey->next = pK;
	pK = pNewKey;

	return pK;
}

CHAR *GetRegistryString( HKEY h, CHAR *pSubKey, CHAR *pValue ) {

	HKEY hVncKey;
	LONG lPwLen = 1024;
	CHAR *pEncPw;
	
	if ( RegOpenKey( h, pSubKey, &hVncKey ) != ERROR_SUCCESS ) {
		return NULL;
	}


	pEncPw = malloc( lPwLen );
	ZeroMemory( pEncPw, lPwLen );

	if ( RegQueryValueEx( hVncKey, pValue, NULL, NULL, 
						(CHAR *)pEncPw, &lPwLen ) != ERROR_SUCCESS ) {
		free( pEncPw );
		return NULL;
	}

	RegCloseKey( hVncKey );

	return pEncPw;
}

DWORD SetRegistryValue( HKEY h, CHAR *pSubKey, CHAR *pValueName, CHAR *pValue, int nLen ) {

	HKEY hKey;
	LONG lErr = ERROR_SUCCESS;

	if ( ERROR_SUCCESS != ( lErr = RegOpenKey( h, pSubKey, &hKey ) ) )
		return lErr;

	if ( ERROR_SUCCESS != ( lErr = RegSetValueEx( hKey, pValueName, 0, REG_BINARY, (BYTE *)pValue, nLen ) ) )
		return lErr;

	return lErr;
}