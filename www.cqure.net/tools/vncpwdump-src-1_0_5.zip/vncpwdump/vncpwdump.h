#ifndef VNCDUMP_H
#define VNCDUMP_H

#define DUMP_PIPE_SIZE 1024

typedef HINSTANCE (WINAPI *pLoadLib_t) (CHAR *);
typedef HINSTANCE (WINAPI *pGetProcAddr_t) (HINSTANCE, CHAR *);
typedef HINSTANCE (WINAPI *pFreeLib_t) (HINSTANCE);
typedef int (*pVNCDump_t) (CHAR *);

typedef struct _remote_info {
    pLoadLib_t      pLoadLibrary;
    pGetProcAddr_t pGetProcAddress;
    pFreeLib_t     pFreeLibrary;
    CHAR  szDllName[MAX_PATH+1];
    CHAR  szProcName[MAX_PATH+1];
    CHAR  szPipeName[MAX_PATH+1];
} REMOTE_INFO;

struct keylist {
	CHAR *pKeyValue;
	VOID *next;
};

static CONST CHAR *VNC3_REGPATH = "Software\\ORL\\Winvnc3\\";
static CONST CHAR *VNC4_REGPATH = "Software\\RealVNC\\WinVNC4\\";

static u_char ObfKey[8] = {23,82,107,6,35,78,88,7};

#endif
