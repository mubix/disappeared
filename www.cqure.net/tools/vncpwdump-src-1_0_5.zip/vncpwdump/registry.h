VOID FreeList( struct keylist *);
struct keylist *AddListItem( struct keylist *, CONST CHAR *);
CHAR *GetRegistryString( HKEY h, CHAR *pSubKey, CHAR *pValue );
DWORD SetRegistryValue( HKEY h, CHAR *pSubKey, CHAR *pValueName, CHAR *pValue, int nLen );