/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4;

import java.net.Socket;
import java.io.IOException;
import java.net.UnknownHostException;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.nio.ByteBuffer;

import net.cqure.bgp4.message.BGP4Header;
import net.cqure.bgp4.message.BGP4Message;
import net.cqure.bgp4.message.BGP4MessageKeepAlive;
import net.cqure.bgp4.message.BGP4MessageNotification;
import net.cqure.bgp4.message.BGP4MessageOpen;
import net.cqure.bgp4.message.BGP4MessageUpdate;


public class BGP4SocketHelper {
	
	private BufferedOutputStream m_oOut = null;
	private BufferedInputStream m_oIn = null;
	private Socket m_oSocket = null;
	
	public BGP4SocketHelper( String sPeer ) throws UnknownHostException, IOException {
		m_oSocket = new Socket( sPeer, 179 );
	}
	
	public BGP4SocketHelper( Socket oS ) { m_oSocket = oS; }
	
	public boolean isConnected() { return m_oSocket.isConnected(); }
	
	public int writeByteStream( byte []b ) throws IOException {
		
		if ( !m_oSocket.isConnected() ) {
				return -1;		
		}
		
		if ( null == m_oOut )
			m_oOut = new BufferedOutputStream( m_oSocket.getOutputStream() );
		
		m_oOut.write( b );
		m_oOut.flush();
		
		return b.length;
	}
	
	public int writeBGPMessage( BGP4Message oMsg ) throws IOException {
		return this.writeByteStream( oMsg.toByteArray() );
	}
	
	public byte[] readByteStream() throws IOException {
		
		byte b[];
		
		if ( !m_oSocket.isConnected() )
			return null;
		
		if ( null == m_oIn )
			m_oIn = new BufferedInputStream( m_oSocket.getInputStream() );
		
		b = new byte[ m_oIn.available() ];
		m_oIn.read( b );
		
		return b;
	}
	
	public BGP4Message readBGPMessage() throws IOException {
	
		ByteBuffer oBuf;
		BGP4Header oHdr;
		BGP4Message oMsg = null;
		byte bsHdr[] = new byte[ BGP4Header.BGP_HEADER_SIZE ];
		byte bsData[] = null;
		byte bsPacket[] = null;
		
		if ( !m_oSocket.isConnected() )
			return null;
		
		if ( null == m_oIn )
			m_oIn = new BufferedInputStream( m_oSocket.getInputStream() );
		
		m_oIn.read(bsHdr);
		oHdr = new BGP4Header( bsHdr );
		
		if ( m_oIn.available() < ( oHdr.getLength() - BGP4Header.BGP_HEADER_SIZE ) )
			return null;
		
		if ( 0 == oHdr.getLength() )
			return null;
		
		oBuf = ByteBuffer.allocate( oHdr.getLength() );
		bsData = new byte[ oHdr.getLength() - BGP4Header.BGP_HEADER_SIZE ];
		m_oIn.read( bsData );
		
		oBuf.put( bsHdr );
		oBuf.put( bsData );
		bsPacket = oBuf.array();
		
		switch ( oHdr.getType() ) {
		
			case BGP4Header.BGP_MSG_OPEN:
				oMsg = new BGP4MessageOpen( bsPacket );
				break;
			case BGP4Header.BGP_MSG_KEEPALIVE:
				oMsg = new BGP4MessageKeepAlive( bsPacket );
				break;
			case BGP4Header.BGP_MSG_UPDATE:
				oMsg = new BGP4MessageUpdate( bsPacket );
				break;
			case BGP4Header.BGP_MSG_NOTIFICATION:
				oMsg = new BGP4MessageNotification( bsPacket );
				break;
			default:
				System.err.println("!! UNSUPPORTED MESSAGE TYPE " + oHdr.getType() + "!!");
		
		}
		
		return oMsg;
	}
	
}
