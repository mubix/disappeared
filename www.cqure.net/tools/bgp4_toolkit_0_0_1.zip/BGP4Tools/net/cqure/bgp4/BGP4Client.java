/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4;


import java.io.IOException;
import java.net.InetAddress;
import java.nio.ByteBuffer;

import net.cqure.bgp4.message.BGP4Message;
import net.cqure.bgp4.message.BGP4MessageKeepAlive;
import net.cqure.bgp4.message.BGP4MessageOpen;
import net.cqure.bgp4.message.BGP4MessageUpdate;

import net.cqure.helper.ConsoleLogger;

import gnu.getopt.Getopt;

public class BGP4Client {

	private static final String PRG_VERSION = "v0.1";
	private static final String PRG_AUTHOR  = "patrik.karlsson@inspectit.se";
	
	public static void usage() {
		System.err.println("BGP4Client " + PRG_VERSION + " by " + PRG_AUTHOR );
		System.err.println("-----------------------------------------------");
		System.err.println("usage: BGP4Client -i <remote_ip> -I <my_id> -a <my_as> [-v]");
	}
	
	public static int ipToInt( String s ) {
		ByteBuffer oBuf;
		InetAddress oI = null;
		byte b[];
		
		if ( s.length() > 0 ) {
			try {
				oI = InetAddress.getByName( s );
			}
			catch ( Exception e ) {
				e.printStackTrace();
				return -1;
			}
		
			b = oI.getAddress();
		
			if ( 0 < b.length ) {
				oBuf = ByteBuffer.allocate( b.length );
				oBuf.put( b );
				oBuf.rewind();
				
				return oBuf.getInt();
			}
		}
	
		return -1;
	}
	
	
	public static void main(String[] args) {

		String sIP = null;
		int nID = -1;
		int nAS = -1;
		BGP4SocketHelper oCliConn = null;
		BGP4Message oMsg;
		Getopt oOpt = new Getopt( "BGP4Client", args, "i:I:a:v" );
		int c;
		
		while ((c = oOpt.getopt()) != -1) {

			switch (c) {

				case 'i':
					sIP = oOpt.getOptarg();
					break;
				case 'I':
					nID = ipToInt( oOpt.getOptarg() );
					break;
				case 'a':
					nAS = Integer.parseInt( oOpt.getOptarg() );
					break;
				case 'v':
					System.setProperty("debug", "true");
					break;
				default:
					usage();
					System.exit(-1);
			}
			
		}
		
		if ( null == sIP || -1 == nID || -1 == nAS ) {
			usage();
			System.exit(1);
		}
		
		try {
			oCliConn = new BGP4SocketHelper( sIP );
		}
		catch( Exception e ) {
			System.err.println( "ERROR: Failed to connect to router " + sIP );
			System.exit(-1);
		}
				
		try {
			oMsg = new BGP4MessageOpen( (short)nAS, nID );
			((BGP4MessageOpen)oMsg).addMessageOption( (byte)2, (byte)6, new byte[]{0x01, 0x04, 0x00, 0x01, 0x00, 0x01});
			((BGP4MessageOpen)oMsg).addMessageOption( (byte)2, (byte)2, new byte[]{(byte)0x80, 0x00});
			((BGP4MessageOpen)oMsg).addMessageOption( (byte)2, (byte)2, new byte[]{0x02, 0x00});
			oCliConn.writeBGPMessage( oMsg );
			
			while( oCliConn.isConnected() ) {
				oMsg = oCliConn.readBGPMessage();
				
				if ( null == oMsg ) {
					ConsoleLogger.log( "ERROR: Failed to retrieve packet");
					break;
				}
				else if ( oMsg instanceof BGP4MessageKeepAlive ) {
					oCliConn.writeBGPMessage( oMsg );
				} 
				else if ( oMsg instanceof BGP4MessageUpdate )
					System.out.println( oMsg.toString() );
							
			}
		}
		catch( IOException e ) {
			e.printStackTrace();
		}
		
	}

}
