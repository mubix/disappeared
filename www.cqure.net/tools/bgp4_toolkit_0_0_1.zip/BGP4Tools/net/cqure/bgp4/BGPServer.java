/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4;

import java.io.IOException;

import net.cqure.bgp4.message.*;

public class BGPServer {

	private static int nAS = 65100;
	private static int nID = 1234;
	
	public static void main(String[] args) {

		BGP4ServerSocket oSrvSocket;
		BGP4SocketHelper oConn;
		BGP4Message oMsg;
		BGP4MessageUpdate oMsgUpdate;
		BGP4ReachabilityInformation oReach;
		BGP4PathAttributeOrigin oPA;
		BGP4PathAttributeASPath oASPath;
		BGP4PathAttributeNextHop oNextHop;
		BGP4PathAttributeCommunities oC;
		BGP4PathAttributeLocalPref oL;
		
		try {
			oSrvSocket = new BGP4ServerSocket();
			
			while ( oSrvSocket.isBound() ) {
				oConn = new BGP4SocketHelper( oSrvSocket.accept() );
				System.err.println("INFO: Got TCP connection");
				
				while( oConn.isConnected() ) {
					
					if ( null == ( oMsg = oConn.readBGPMessage() ) )
						break;
					
					if ( oMsg instanceof BGP4MessageOpen ) {
						System.err.println("INFO: Replying to OPEN");
						oConn.writeBGPMessage( new BGP4MessageOpen( (short)nAS, nID ) );
					}
					else if ( oMsg instanceof BGP4MessageKeepAlive ){
						System.err.println("INFO: Replying to KEEPALIVE");
						oConn.writeBGPMessage( new BGP4MessageKeepAlive() );
						
						oMsgUpdate = new BGP4MessageUpdate();
						oReach = new BGP4ReachabilityInformation( (byte)23, "123.123.123" );
						oMsgUpdate.addReachabilityInformation( oReach );
						oReach = new BGP4ReachabilityInformation( (byte)22, "123.123.222" );
						oMsgUpdate.addReachabilityInformation( oReach );						
						oPA = new BGP4PathAttributeOrigin( );
						oPA.setOrigin( BGP4PathAttributeOrigin.ORIGIN_IGP );
						oMsgUpdate.addPathAttribute( oPA );
						
						oASPath = new BGP4PathAttributeASPath();
						oASPath.addAS( 65000 );
						oASPath.addAS( 45000 );
						oASPath.setSequenceType( BGP4PathAttributeASPath.TYPE_AS_SEQ );
						oMsgUpdate.addPathAttribute( oASPath );
						
						oNextHop = new BGP4PathAttributeNextHop();
						oNextHop.setNextHop( "1.2.3.4" );
						oMsgUpdate.addPathAttribute( oNextHop );
						
						oC = new BGP4PathAttributeCommunities();
						oC.addCommunity( 65100, 1234 );
						oMsgUpdate.addPathAttribute( oC );
						
						oL = new BGP4PathAttributeLocalPref();
						oL.setLocalPref(0);
						oMsgUpdate.addPathAttribute( oL );
						
						oConn.writeBGPMessage( oMsgUpdate );
						System.err.println("INFO: Wrote UPDATE message to wire");
					}
					else if ( oMsg instanceof BGP4MessageUpdate ) {
						System.err.println( oMsg.toString() );
					}
					else if ( oMsg instanceof BGP4MessageNotification ) {
						System.err.println( "ERROR: " + oMsg.toString() );
					}
					else {
						System.err.println("INFO: Got unsupported message");
					}
					
				}
				
			}
			
		
		} catch( IOException e ) {
			e.printStackTrace();
		}
		
	}

}
