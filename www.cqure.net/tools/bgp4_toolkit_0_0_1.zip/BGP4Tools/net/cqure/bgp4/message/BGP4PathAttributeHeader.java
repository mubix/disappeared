/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;

public class BGP4PathAttributeHeader {

	private BGP4PathAttributeFlags m_oFlags;
	private byte m_nType;
	private short m_nLength;
	
	public BGP4PathAttributeHeader( int nFlags, int nType, int nLength ) {
		m_oFlags = new BGP4PathAttributeFlags( (byte)nFlags );
		m_nType  = (byte)nType;
		m_nLength= (short)nLength;
	}
	
	public byte[] toByteArray() {
		
		ByteBuffer oBuf;
		
		if ( m_oFlags.isExtendedLength() ) {
			oBuf = ByteBuffer.allocate( 4 );
			oBuf.put( m_oFlags.toByte() );
			oBuf.put( m_nType );
			oBuf.putShort(m_nLength);
		}
		else {
			oBuf = ByteBuffer.allocate( 3 );
			oBuf.put( m_oFlags.toByte() );
			oBuf.put( m_nType );
			oBuf.put( (byte)m_nLength );
		}
		
		return oBuf.array();
	}
	
	public int size() {
		
		if ( m_oFlags.isExtendedLength() )
			return 1 + 1 + 2;
		
		/* Value length + flags + type + length */
		return 1 + 1 + 1;
	}
	
	public int length() {
		return size() + m_nLength;
	}
	
	public void setAttrLen( int n ) {
		m_nLength = (short)n;
	}
	
	public int getAttrLen() { return m_nLength; }
	
	public String getNameById( byte n ) {
		
		switch ( n ) {
			case BGP4PathAttribute.TYPE_ORIGIN:
				return "ORIGIN";
			case BGP4PathAttribute.TYPE_AS_PATH:
				return "AS_PATH";
			case BGP4PathAttribute.TYPE_NEXT_HOP:
				return "NEXT_HOP";
			case BGP4PathAttribute.TYPE_MULTI_EXIT_DISC:
				return "MULTI_EXIT_DISC";
			case BGP4PathAttribute.TYPE_LOCAL_PREF:
				return "LOCAL_PREF";
			case BGP4PathAttribute.TYPE_ATOMIC_AGGREGATE:
				return "ATOMIC_AGGREGATE";
			case BGP4PathAttribute.TYPE_AGGREGATOR:
				return "AGGREGATOR";
			case BGP4PathAttribute.TYPE_COMMUNITIES:
				return "COMMUNITIES";
			default:
				return "UNKNOWN";
		
		}
	}
	
	public String toString() {
		return "Flags: " + m_oFlags.toString() + ", Type: " + getNameById(m_nType) + ", Length: " + m_nLength;		
	}
	
}
