/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;

public class BGP4PathAttributeLocalPref implements BGP4PathAttributeIface {

	private int m_nLocalPref;
	private BGP4PathAttributeHeader m_oHeader;
	
	public BGP4PathAttributeLocalPref( byte nFlags, byte nType, short nLength, byte[] bsData ) {
		m_oHeader = new BGP4PathAttributeHeader( nFlags, nType, nLength );
		parseAttribute( bsData );
	}
	
	public BGP4PathAttributeLocalPref() {
		BGP4PathAttributeFlags oFlags = new BGP4PathAttributeFlags();
		oFlags.setTransitive(true);
		
		m_oHeader = new BGP4PathAttributeHeader( oFlags.toByte(), 
													BGP4PathAttribute.TYPE_LOCAL_PREF,
													4 );

	}
	
	public void setLocalPref( int n ) {
			m_nLocalPref = n;		
	}
	
	public byte[] toByteArray() {
		ByteBuffer oB = ByteBuffer.allocate( m_oHeader.length() );
		
		oB.put( m_oHeader.toByteArray() );
		oB.putInt( m_nLocalPref );
		
		return oB.array();
	}
	
	
	public void parseAttribute( byte[] bsData ) {
		ByteBuffer oBuf;
		
		if ( bsData.length == 4 ) {
			oBuf = ByteBuffer.allocate(4);
			oBuf.put( bsData );
			oBuf.rewind();
			m_nLocalPref = oBuf.getInt();
			oBuf = null;
		}
			
	}
	
	public String toString() {
		return m_oHeader.toString() + " Local Preference: " + m_nLocalPref;		
	}

	public int length() { 
		if ( null != m_oHeader )
			return m_oHeader.length();

		return 0;
	}

	
}
