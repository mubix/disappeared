/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;
import java.util.Vector;

public class BGP4PathAttributeASPath implements BGP4PathAttributeIface {

	public static final int TYPE_AS_SET = 1;
	public static final int TYPE_AS_SEQ = 2;
	
	private byte m_nSegType;
	private byte m_nSegLen;
	private Vector m_oAS = new Vector();
	
	private BGP4PathAttributeHeader m_oHeader;
	
	public BGP4PathAttributeASPath( byte nFlags, byte nType, short nLength, byte[] bsData ) {
		m_oHeader = new BGP4PathAttributeHeader( nFlags, nType, nLength );
		parseAttribute( bsData );
	}
	
	public BGP4PathAttributeASPath() {
		BGP4PathAttributeFlags oFlags = new BGP4PathAttributeFlags();
		oFlags.setTransitive(true);
		
		m_oHeader = new BGP4PathAttributeHeader( oFlags.toByte(), 
													BGP4PathAttribute.TYPE_AS_PATH,
													2 );

		m_nSegType = -1;
		m_nSegLen  = 0;
	}

	public void setSequenceType( int n ) {		
		
		if ( n > TYPE_AS_SEQ )
			System.err.println("WARNING: Setting unsupported sequence type");
		
		m_nSegType = (byte)n;
	}
	
	public void addAS( int nAS ) {
		m_oAS.add( new Short( (short)nAS ) );
		m_nSegLen ++;
		
		m_oHeader.setAttrLen( m_oHeader.getAttrLen() + 2 );
	}
	
	public byte[] toByteArray() {
		ByteBuffer oB = ByteBuffer.allocate( m_oHeader.length() );
		
		oB.put( m_oHeader.toByteArray() );
		oB.put( m_nSegType );
		oB.put( m_nSegLen );
		
		for( int i=0; i<m_oAS.size(); i++ )
			oB.putShort( ((Short)m_oAS.get(i)).shortValue() );
		
		return oB.array();
	}
	
	public void parseAttribute( byte[] bsData ) {		
		ByteBuffer oBuf;
		int i;
				
		/* Check for minimum data length */
		if ( bsData.length > 4 ) {
			oBuf = ByteBuffer.allocate( bsData.length );
			oBuf.put( bsData );
			oBuf.rewind();
			
			m_nSegType = oBuf.get();
			m_nSegLen = oBuf.get();
					
			for ( i=0; i < m_nSegLen; i ++ ) {
				if ( oBuf.hasRemaining() )
					m_oAS.add( new Short(oBuf.getShort()) );
				else
					break;
			}
		}
	}
	
	public String toString() {

		String s = m_oHeader.toString();
		int i;
		
		switch ( m_nSegType ) {
			case TYPE_AS_SET:
				s += ", Type: AS_SET";
				break;
			case TYPE_AS_SEQ:
				s += ", Type: AS_SEQUENCE";
				break;
			default:
				s += ", Type: UNKNOWN";
		}
		
		s += ", Length: " + m_nSegLen;
		s += ", AS path: ";
		
		if ( null != m_oAS ) {

			for ( i = 0; i < m_oAS.size(); i++ ) {
				s += " " + m_oAS.get(i).toString();
			}
		
		}

		return s;
	}
	
	public int length() { 
		if ( null != m_oHeader )
			return m_oHeader.length();

		return 0;
	}
	
}
