/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;

public class BGP4PathAttributeOrigin implements BGP4PathAttributeIface {
	
	static public final byte ORIGIN_IGP = 0;
	static public final byte ORIGIN_EGP = 1;
	static public final byte ORIGIN_INCOMPLETE = 2;
	
	private BGP4PathAttributeHeader m_oHeader;
	private byte m_nOrigin = -1;
	
	public BGP4PathAttributeOrigin( byte nFlags, byte nType, short nLength, byte[] bsData ) {
	
		m_oHeader = new BGP4PathAttributeHeader( nFlags, nType, nLength );
		
		if ( null != bsData && bsData.length == 1 )
			m_nOrigin = bsData[0];
	}
	
	public BGP4PathAttributeOrigin( byte nOrigin ) {
		
		BGP4PathAttributeFlags oFlags = new BGP4PathAttributeFlags();
		oFlags.setTransitive(true);
		
		m_oHeader = new BGP4PathAttributeHeader( oFlags.toByte(), 
													BGP4PathAttribute.TYPE_ORIGIN,
													1 );
		
		m_nOrigin = nOrigin;
	}
	
	
	public byte[] toByteArray() {
		ByteBuffer oB = ByteBuffer.allocate( m_oHeader.length() );
		
		oB.put( m_oHeader.toByteArray() );
		oB.put( m_nOrigin );
		
		return oB.array();
	}
	
	public BGP4PathAttributeOrigin( ) {
		this((byte)-1);
	}
	
	
	
	public void setOrigin( byte b ) {
		m_nOrigin = b;
	}
	
	public void parseAttribute() {		
		return;
	}
	
	public String toString() {
		
		String sOrig = "";
		String sAttrib = m_oHeader.toString();
				
		if ( m_nOrigin == ORIGIN_IGP )
			sOrig = "IGP";
		else if ( m_nOrigin == ORIGIN_EGP )
			sOrig = "EGP";
		else if ( m_nOrigin == ORIGIN_INCOMPLETE )
			sOrig = "INCOMPLETE";
		
		return sAttrib + ", Origin: " + sOrig;
	}

	public int length() { 
		if ( null != m_oHeader )
			return m_oHeader.length();

		return 0;
	}
}
