/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;
import java.net.InetAddress;

public class BGP4PathAttributeNextHop implements BGP4PathAttributeIface {

	private int m_nNextHop;
	private BGP4PathAttributeHeader m_oHeader;
	
	public BGP4PathAttributeNextHop( byte nFlags, byte nType, short nLength, byte[] bsData ) {
		m_oHeader = new BGP4PathAttributeHeader( nFlags, nType, nLength );
		parseAttribute( bsData );
	}
	
	public BGP4PathAttributeNextHop() {
		BGP4PathAttributeFlags oFlags = new BGP4PathAttributeFlags();
		oFlags.setTransitive(true);
		
		m_oHeader = new BGP4PathAttributeHeader( oFlags.toByte(), 
													BGP4PathAttribute.TYPE_NEXT_HOP,
													4 );

	}

	public void setNextHop( String sIP ) {
		InetAddress oIP = null;
		ByteBuffer oBuf = ByteBuffer.allocate(4);
		
		try {
			oIP = InetAddress.getByName( sIP );
			oBuf.put( oIP.getAddress() );
			oBuf.rewind();
			
			m_nNextHop = oBuf.getInt();
		}
		catch( Exception e ) {
			e.printStackTrace();
		}
		
	}
	
	public byte[] toByteArray() {
		ByteBuffer oB = ByteBuffer.allocate( m_oHeader.length() );
		
		oB.put( m_oHeader.toByteArray() );
		oB.putInt( m_nNextHop );
		
		return oB.array();
	}
	
	public void parseAttribute( byte[] bsData ) {
		ByteBuffer oBuf;
				
		if ( bsData.length == 4 ) {
			oBuf = ByteBuffer.allocate(4);
			oBuf.put( bsData );
			oBuf.rewind();
			
			m_nNextHop = oBuf.getInt();
			oBuf = null;
		}
			
	}
	
	public String toString() {
		
		ByteBuffer oBuf;
		String sNextHop = "<failed to convert>";
				
		oBuf = ByteBuffer.allocate(4);
		oBuf.putInt( m_nNextHop );
		oBuf.rewind();
		
		try {
			sNextHop = InetAddress.getByAddress( oBuf.array() ).getHostAddress();
		}
		catch( Exception e ) {
			e.printStackTrace();
		}
		
		return m_oHeader.toString() + ", Next hop: " + sNextHop;
		
	}
	
	public int length() { 
		if ( null != m_oHeader )
			return m_oHeader.length();

		return 0;
	}
	
}
