/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;
import java.nio.ByteBuffer;

public class BGP4Header {

	private byte[] m_sMarker;
	private short m_nLength;
	private byte m_nType;
	
	static public final int BGP_HEADER_SIZE = 19;
	
	static public final byte BGP_MSG_OPEN = 1;
	static public final byte BGP_MSG_UPDATE = 2;
	static public final byte BGP_MSG_NOTIFICATION = 3;
	static public final byte BGP_MSG_KEEPALIVE = 4;
	
	public BGP4Header() {
		m_sMarker = new byte[16];
		m_nLength = BGP_HEADER_SIZE;
		m_nType   = -1;
		
		for( int i=0; i<m_sMarker.length; i++ )
			m_sMarker[i] = (byte) 0xFF;
	}

	public BGP4Header( byte[] b ) {
		ByteBuffer oBuf;
		
		if ( BGP_HEADER_SIZE > b.length )
			return;
		
		oBuf = ByteBuffer.allocate( b.length );
		oBuf.put( b );
		oBuf.rewind();
		
		m_sMarker = new byte[16];
		oBuf.get( m_sMarker );
		m_nLength = oBuf.getShort();
		m_nType = oBuf.get();
	}
	
	public byte[] toByteArray() {
		return this.toByteBuffer().array();
	}
	
	public ByteBuffer toByteBuffer() {
		ByteBuffer oBuf = ByteBuffer.allocate( BGP_HEADER_SIZE );
		
		oBuf.put( m_sMarker );
		oBuf.putShort( m_nLength );
		oBuf.put( m_nType );
		
		return oBuf;
	}
	
	public void setType( byte nType ) {
		m_nType = nType;
	}

	public void setLength( int nLen ) {
		m_nLength = (short)nLen;
	}
	
	public short getLength() { return m_nLength; }
	public byte getType() { return m_nType; }
}
