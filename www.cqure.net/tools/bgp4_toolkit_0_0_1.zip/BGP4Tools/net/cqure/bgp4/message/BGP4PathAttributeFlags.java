/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsso <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

public class BGP4PathAttributeFlags {

	static public final byte EXTENDED_LENGTH_BIT = 1;	
	static public final byte PARTIAL_BIT = 2;
	static public final byte TRANSITIVE_BIT = 4;
	static public final byte OPTIONAL_BIT = 8;

	static public final int SIZE = 1;
	
	private byte m_bFlags = 0;
	
	public BGP4PathAttributeFlags( ) {

	}
	
	public BGP4PathAttributeFlags( byte b ) {
		m_bFlags = (byte)(b << 4);
	}
	
	public byte toByte() {
		return m_bFlags;
	}
	
	public boolean isExtendedLength() {
		if ( 0 != ( m_bFlags & EXTENDED_LENGTH_BIT ) )
			return true;
		
		return false;	
	}
	
	public void setExtendedLength( boolean b ) {
		if ( b )
			m_bFlags = (byte)( m_bFlags | EXTENDED_LENGTH_BIT );
		else
			m_bFlags = (byte)( m_bFlags ^ EXTENDED_LENGTH_BIT );
	}
	
	public void setPartial( boolean b ) {
		if ( b )
			m_bFlags = (byte)( m_bFlags | PARTIAL_BIT );
		else
			m_bFlags = (byte)( m_bFlags ^ PARTIAL_BIT );
	}
	
	public void setTransitive( boolean b ) {
		if ( b )
			m_bFlags = (byte)( m_bFlags | TRANSITIVE_BIT );
		else
			m_bFlags = (byte)( m_bFlags ^ TRANSITIVE_BIT );
	}
	
	public void setOptional( boolean b ) {
		if ( b )
			m_bFlags = (byte)( m_bFlags | OPTIONAL_BIT );
		else
			m_bFlags = (byte)( m_bFlags ^ OPTIONAL_BIT );
	}
	
	public String toString() {
		String sFlags = "";
		int nFlags = m_bFlags >> 4;

		if ( 1 == ( nFlags & OPTIONAL_BIT ) )
			sFlags += "optional";
		else
			sFlags += "well-known";
		
		if ( 1 == ( nFlags & TRANSITIVE_BIT ) )
			sFlags += ",transitive";
		else
			sFlags += ",not-transitive";
		
		if ( 1 == ( nFlags & PARTIAL_BIT ))
			sFlags += ",partial";
		else
			sFlags += ",complete";
		
		if ( 1 == ( nFlags & EXTENDED_LENGTH_BIT ))
			sFlags += ", length (2 bytes)";
		else
			sFlags += ", length (1 byte)";
		
		return sFlags;
	}
	
}
