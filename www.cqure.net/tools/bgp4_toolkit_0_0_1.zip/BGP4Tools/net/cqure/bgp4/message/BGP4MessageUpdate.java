/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.util.Vector;
import java.nio.ByteBuffer;

public class BGP4MessageUpdate extends BGP4Message {

	private short m_nUnfRoutes;
	private short m_nTotAttribLen;
	
	private Vector m_oReachInfo = new Vector();
	private Vector m_oPathAttributes = new Vector();
	private Vector m_oUnfRoutes = new Vector();
	
	public BGP4MessageUpdate() {
		super();
		setType( BGP4Message.BGP_MSG_UPDATE );
		
		/* Add length of m_nUnfRoutes and m_nTotAttribLen */
		setLength( getLength() + 2 + 2 );
	}
	
	public short getUnfeasibleRoutes() { return m_nUnfRoutes; }
	public void setUnfeasibleRoutes( short n ) {  m_nUnfRoutes = n; }
	public short getAttributeLength() { return m_nTotAttribLen; }
	public void setAttributeLength( short n ) { m_nTotAttribLen = n; }
	
	public void addReachabilityInformation( BGP4ReachabilityInformation o ) {
		m_oReachInfo.add( o );
		setLength( getLength() + o.getLength() );
	}
	
	public void addUnfeasibleRoute( BGP4ReachabilityInformation o ) {
		m_oUnfRoutes.add( o );
		m_nUnfRoutes ++;
		setLength( getLength() + o.getLength() );
	}
	
	public void addPathAttribute( BGP4PathAttributeIface oPA ) {
		
		if ( null == m_oPathAttributes )
			m_oPathAttributes = new Vector();
		
		m_oPathAttributes.add( oPA );
		m_nTotAttribLen += oPA.length();
		setLength( getLength() + oPA.length() );
	}
	
	public BGP4MessageUpdate( byte b[] ) {	
	
		super( b );
		
		ByteBuffer oBuf;
		byte[] bsPathAttrib = null;
		byte[] bsNetworkReach = null;
		byte[] bsWithdrawn = null;
		
		if ( b.length > BGP4Header.BGP_HEADER_SIZE ) {
			oBuf = ByteBuffer.allocate( b.length - BGP4Header.BGP_HEADER_SIZE );
			
			oBuf.put( b, BGP4Header.BGP_HEADER_SIZE, b.length - BGP4Header.BGP_HEADER_SIZE );
			oBuf.rewind();
			
			m_nUnfRoutes = oBuf.getShort();
			
			if ( m_nUnfRoutes > 0 ) {
				bsWithdrawn = new byte[ m_nUnfRoutes ];
				oBuf.get(bsWithdrawn);
				
				parseUnfesibleRoutes( bsWithdrawn );
			}
			
			m_nTotAttribLen = oBuf.getShort();
			
			if ( m_nTotAttribLen > 0 ) {
				bsPathAttrib = new byte[ m_nTotAttribLen ];
				oBuf.get( bsPathAttrib );
			}
			
			bsNetworkReach = new byte[ this.getLength() - 23 - m_nUnfRoutes -  m_nTotAttribLen ];
			oBuf.get( bsNetworkReach );
			
			parsePathAttributes( bsPathAttrib );
			parseNetworkReach( bsNetworkReach );
			
			if ( null != System.getProperty("debug") ) {
				System.err.println("INFO: Finnished processing UPDATE message");
				System.err.println("INFO: Total path attribute length: " + m_nTotAttribLen );
			}
			
		}
		
		
	}
	
	public String toString( ) {
		
		int i;
		String s = "";
		
		s = "Message: BGP UPDATE\n";
		
		if ( null != m_oPathAttributes ) {
			for( i=0; i<m_oPathAttributes.size(); i++ )
				s += "\t" + (((BGP4PathAttributeIface)m_oPathAttributes.get(i)).toString()) + "\n";
		}
		
		if ( 0 < m_nUnfRoutes ) {
			s += "\tUnfesible routes:\n";
			
			for( i=0; i<m_oUnfRoutes.size(); i++ )
				s += "\t\t" + m_oUnfRoutes.get(i).toString() + "\n";
		}
		
		s += "\tNetwork Reachability Information:\n";
		
		if ( null != m_oReachInfo ) {
			for( i=0; i<m_oReachInfo.size(); i++ )
				s += "\t\t" + m_oReachInfo.get(i).toString() + "\n";
		}
		
		return s;
	}
	
	private void parseNetworkReach( byte buf[] ) {

		ByteBuffer oBuf;
		byte nLength, nBytes;
		byte[] bsPrefix;
		
		if ( 0 < buf.length ) {
			oBuf = ByteBuffer.allocate( buf.length );
			oBuf.put( buf );
			oBuf.rewind();
			
			while( oBuf.hasRemaining() ) {
				nLength = oBuf.get();
				
				if ( 0 != nLength % 8 )
					nBytes = (byte)(nLength / 8 + 1);
				else
					nBytes = (byte)(nLength / 8);
				
				bsPrefix = new byte[ nBytes ];
				oBuf.get( bsPrefix );
				m_oReachInfo.add( new BGP4ReachabilityInformation( nLength, bsPrefix ) );
			}
		
		}

	}

	private void parseUnfesibleRoutes( byte buf[] ) {

		ByteBuffer oBuf;
		byte nLength, nBytes;
		byte[] bsPrefix;
		
		if ( 0 < buf.length ) {
			oBuf = ByteBuffer.allocate( buf.length );
			oBuf.put( buf );
			oBuf.rewind();
			
			while( oBuf.hasRemaining() ) {
				nLength = oBuf.get();
				
				if ( 0 != nLength % 8 )
					nBytes = (byte)(nLength / 8 + 1);
				else
					nBytes = (byte)(nLength / 8);
				
				bsPrefix = new byte[ nBytes ];
				oBuf.get( bsPrefix );
				m_oUnfRoutes.add( new BGP4ReachabilityInformation( nLength, bsPrefix ) );
			}
		
		}

	}

	
	private void parsePathAttributes( byte buf[] ) {
		
		ByteBuffer oBuf;
		BGP4PathAttributeFlags oFlags;
		int nLength, i=0;
		byte b;
		short l;
		
		if ( null == buf )
			return;
		
		nLength = buf.length;
		
		m_oPathAttributes = new Vector();
		
		/* The length field is 2 to 3 bytes from length indicator */
		while ( i<nLength - 3 ) {

			b = (byte)(buf[i] >> 4);
			l = 2;
			
			/* Check for extended length */
			oFlags = new BGP4PathAttributeFlags( b );
			if ( !oFlags.isExtendedLength() ) {
				l += 1;
				l += buf[i + 2];
			}
			else {
				l += 2;
				oBuf = ByteBuffer.allocate( 2 );
				oBuf.put( buf, i, 2);
				oBuf.rewind();
				l += oBuf.getShort();
				oBuf = null;
			}
				
			oBuf = ByteBuffer.allocate( l );
			oBuf.put( buf, i, (int)l );
			m_oPathAttributes.add( BGP4PathAttributeFactory.create( oBuf.array() ) );
			
			i += l;
		}
	
	}
	
	public byte[] toByteArray() {
		byte [] bsHeader = super.toByteArray();
		int i;
		
		ByteBuffer oBuffer = ByteBuffer.allocate( getLength() );
		oBuffer.put( bsHeader );
		oBuffer.putShort( m_nUnfRoutes );

		/* Unfeasible routes not implemented always do 0 */		
		for( i=0; i<m_oUnfRoutes.size(); i++ )
			oBuffer.put( ((BGP4ReachabilityInformation)m_oUnfRoutes.get(i)).toByteArray() );
		
		oBuffer.putShort( m_nTotAttribLen );
		
		for( i=0; i<m_oPathAttributes.size(); i++ )
			oBuffer.put( ((BGP4PathAttributeIface)m_oPathAttributes.get(i)).toByteArray() );
		
		for( i=0; i<m_oReachInfo.size(); i++ )
			oBuffer.put( ((BGP4ReachabilityInformation)m_oReachInfo.get(i)).toByteArray() );
		
		return oBuffer.array();
	}
	
}
