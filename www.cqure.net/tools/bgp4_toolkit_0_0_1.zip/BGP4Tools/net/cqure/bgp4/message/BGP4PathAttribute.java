/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

public class BGP4PathAttribute {
	
	
	static public final int TYPE_ORIGIN = 1;
	static public final int TYPE_AS_PATH = 2;
	static public final int TYPE_NEXT_HOP = 3;
	static public final int TYPE_MULTI_EXIT_DISC = 4;
	static public final int TYPE_LOCAL_PREF = 5;
	static public final int TYPE_ATOMIC_AGGREGATE= 6;
	static public final int TYPE_AGGREGATOR = 7;
	static public final int TYPE_COMMUNITIES = 8;
	
	public BGP4PathAttribute() {
		
	}
	
	public static String getNameById( byte n ) {
		
		switch ( n ) {
			case TYPE_ORIGIN:
				return "ORIGIN";
			case TYPE_AS_PATH:
				return "AS_PATH";
			case TYPE_NEXT_HOP:
				return "NEXT_HOP";
			case TYPE_MULTI_EXIT_DISC:
				return "MULTI_EXIT_DISC";
			case TYPE_LOCAL_PREF:
				return "LOCAL_PREF";
			case TYPE_ATOMIC_AGGREGATE:
				return "ATOMIC_AGGREGATE";
			case TYPE_AGGREGATOR:
				return "AGGREGATOR";
			case TYPE_COMMUNITIES:
				return "COMMUNITIES";
			default:
				return "UNKNOWN";
		
		}
	}
		


}
