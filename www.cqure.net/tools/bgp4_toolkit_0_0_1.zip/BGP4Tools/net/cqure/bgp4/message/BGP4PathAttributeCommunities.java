/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;
import java.util.Vector;

public class BGP4PathAttributeCommunities implements BGP4PathAttributeIface {
	
	public static class Community {
		
		private short m_nCommAS;
		private short m_nCommVal;
			
		public Community( short nCommAS, short nCommVal ) {
			m_nCommAS  = nCommAS;
			m_nCommVal = nCommVal;
		}
		
		public Community( int nAS, int nVal ) {
			this( (short) nAS, (short) nVal );
		}
		
		public short getCommunityAS( ) { return m_nCommAS; }
		public short getCommunityValue() { return m_nCommVal; }
		public void setCommunityAS( short n ) { m_nCommAS = n; }
		public void setCommunityValue( short n ) { m_nCommVal = n; }
		
		public byte[] toByteArray() {
			ByteBuffer oB = ByteBuffer.allocate( size() );
			
			oB.putShort( m_nCommAS );
			oB.putShort( m_nCommVal );
			
			return oB.array();
		}
		
		static public int size() {
			return 4;
		}
	
	}
	
	private Vector m_oCommunities = new Vector();
	private BGP4PathAttributeHeader m_oHeader;
	
	public BGP4PathAttributeCommunities( byte nFlags, byte nType, short nLength, byte[] bsData ) {
		m_oHeader = new BGP4PathAttributeHeader( nFlags, nType, nLength );
		parseAttribute( bsData );
	}
	
	public BGP4PathAttributeCommunities() {
		
		BGP4PathAttributeFlags oFlags = new BGP4PathAttributeFlags();
		oFlags.setTransitive(true);
		
		m_oHeader = new BGP4PathAttributeHeader( oFlags.toByte(), 
													BGP4PathAttribute.TYPE_COMMUNITIES,
													0 );

	}

	public void addCommunity( int nAS, int nValue ) {
		m_oCommunities.add( new Community( nAS, nValue ) );
		m_oHeader.setAttrLen( m_oHeader.getAttrLen() + Community.size() );
	}
	
	public void parseAttribute( byte[] bsData ) {
		ByteBuffer oBuf;
		int i;
				
		if ( null != bsData && 0 < bsData.length ) {
			oBuf = ByteBuffer.allocate( bsData.length );
			oBuf.put( bsData );
			oBuf.rewind();
			
			for ( i=0; i<m_oCommunities.size(); i++ )
				m_oCommunities.add( new Community( oBuf.getShort(), oBuf.getShort() ) );
		}
		
	}
	
	public byte[] toByteArray() {
		ByteBuffer oB = ByteBuffer.allocate( m_oHeader.length() );
		
		oB.put( m_oHeader.toByteArray() );
		
		for( int i=0; i<m_oCommunities.size(); i++ )
			oB.put( ((Community)m_oCommunities.get(i)).toByteArray() );
		
		return oB.array();
	}
	
	
	public String toString() {
		String s = m_oHeader.toString();
		int i;
				
		if ( null != m_oCommunities ) {
		
			for ( i=0; i<m_oCommunities.size(); i++ )
				s += ", Community: " + ((Community) m_oCommunities.get(i)).getCommunityAS() + ":" + ((Community)m_oCommunities.get(i)).getCommunityValue();
		
		}
		
		return s;
	}

	public int length() { 
		if ( null != m_oHeader )
			return m_oHeader.length();

		return 0;
	}

}
