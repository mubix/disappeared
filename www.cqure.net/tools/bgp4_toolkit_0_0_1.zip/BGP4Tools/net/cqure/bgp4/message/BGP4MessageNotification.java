/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;

public class BGP4MessageNotification extends BGP4Message {
	
	private static final int ERR_MESSAGE_HEADER 	= 1;
	private static final int ERR_OPEN_MESSAGE 		= 2;
	private static final int ERR_UPDATE_MESSAGE 	= 3;
	private static final int ERR_HOLDTIMER_EXPIRED	= 4;
	private static final int ERR_FINITE_STATE		= 5;
	private static final int ERR_CEASE				= 6;
	
	private static final int ERR_MESSAGE_HEADER_NOT_SYNC 	= 1;
	private static final int ERR_MESSAGE_HEADER_LENGTH		= 2;
	private static final int ERR_MESSAGE_HEADER_TYPE		= 3;
	
	private static final int ERR_OPEN_MESSAGE_UNSUPP_VERSION= 1;
	private static final int ERR_OPEN_MESSAGE_BAD_PEER_AS	= 2;
	private static final int ERR_OPEN_MESSAGE_BAD_BGP_IDENT = 3;
	private static final int ERR_OPEN_MESSAGE_UNSUPP_OPTION = 4;
	private static final int ERR_OPEN_MESSAGE_AUTH_FAIL		= 5;
	private static final int ERR_OPEN_MESSAGE_UNACC_HOLD_TM = 6;
	
	private static final int ERR_UPDATE_MESSAGE_MALF_ATTRIB 			= 1;
	private static final int ERR_UPDATE_MESSAGE_UNRECOGN_WK_ATTRIB 		= 2;
	private static final int ERR_UPDATE_MESSAGE_MISSING_WK_ATTRIB		= 3;
	private static final int ERR_UPDATE_MESSAGE_ATTRIB_FLAG_ERROR		= 4;
	private static final int ERR_UPDATE_MESSAGE_ATTRIB_LENGTH_ERROR		= 5;
	private static final int ERR_UPDATE_MESSAGE_INVALID_ORIGIN_ATTRIB	= 6;
	private static final int ERR_UPDATE_MESSAGE_AS_ROUTING_LOOP			= 7;
	private static final int ERR_UPDATE_MESSAGE_INVALID_NEXT_HOP		= 8;
	private static final int ERR_UPDATE_MESSAGE_OPTIONAL_ATTR_ERROR		= 9;
	private static final int ERR_UPDATE_MESSAGE_INVALID_NETWORK_FIELD	= 10;
	private static final int ERR_UPDATE_MESSAGE_MALFORMED_AS_PATH		= 11;
	
	
	private byte m_nCode;
	private byte m_nSubCode;
	private byte m_bsData;
	
	public BGP4MessageNotification( byte[] b ) {
		super( b );
		
		ByteBuffer oBuf;
		
		if ( b.length > BGP4Header.BGP_HEADER_SIZE ) {
			oBuf = ByteBuffer.allocate( b.length - BGP4Header.BGP_HEADER_SIZE );
			oBuf.put( b, BGP4Header.BGP_HEADER_SIZE, b.length - BGP4Header.BGP_HEADER_SIZE );
			oBuf.rewind();
		
			m_nCode = oBuf.get();
			m_nSubCode = oBuf.get();
	
			if ( oBuf.hasRemaining() )
				oBuf.get( m_bsData );
		
		}

	}

	private String getErrorMsg() {
		
		switch ( m_nCode ) {
		
			case ERR_MESSAGE_HEADER:
				return "Message Header Error";
			case ERR_OPEN_MESSAGE:
				return "OPEN Message Error";
			case ERR_UPDATE_MESSAGE:
				return "UPDATE Message Error";
			case ERR_HOLDTIMER_EXPIRED:
				return "Hold Timer Expired";
			case ERR_FINITE_STATE:
				return "Finite State Machine Error";
			case ERR_CEASE:
				return "Cease";
			default:
				return "<Unknown error code>";

		}
		
	}
	
	private String getSubErrorMsg() {

		switch ( m_nCode ) {

			case ERR_MESSAGE_HEADER:
				switch( m_nSubCode ) {
					case ERR_MESSAGE_HEADER_NOT_SYNC:
						return "Connection Not Synchronized";
					case ERR_MESSAGE_HEADER_LENGTH:
						return "Bad Message Length";
					case ERR_MESSAGE_HEADER_TYPE:
						return "Bad Message Type";
				}
			case ERR_OPEN_MESSAGE:
				switch( m_nSubCode ) {	
					case ERR_OPEN_MESSAGE_UNSUPP_VERSION:
						return "Unsupported Version Number";
					case ERR_OPEN_MESSAGE_BAD_PEER_AS:
						return "Bad Peer AS";
					case ERR_OPEN_MESSAGE_BAD_BGP_IDENT:
						return "Bad BGP Identifier";
					case ERR_OPEN_MESSAGE_UNSUPP_OPTION:
						return "Unsupported Optional Parameter";
					case ERR_OPEN_MESSAGE_AUTH_FAIL:
						return "Authentication Failure";
					case ERR_OPEN_MESSAGE_UNACC_HOLD_TM:
						return "Unacceptable Hold Time";
				}		
			case ERR_UPDATE_MESSAGE:
				switch( m_nSubCode ) {	
					case ERR_UPDATE_MESSAGE_MALF_ATTRIB:
						return "Malformed Attribute List";
					case ERR_UPDATE_MESSAGE_UNRECOGN_WK_ATTRIB:
						return "Unrecognized Well-known Attribute";
					case ERR_UPDATE_MESSAGE_MISSING_WK_ATTRIB:
						return "Missing Well-known Attribute";
					case ERR_UPDATE_MESSAGE_ATTRIB_FLAG_ERROR:
						return "Attribute Flags Error";
					case ERR_UPDATE_MESSAGE_ATTRIB_LENGTH_ERROR:
						return "Attribute Length Error";
					case ERR_UPDATE_MESSAGE_INVALID_ORIGIN_ATTRIB:
						return "Invalid ORIGIN Attribute";
					case ERR_UPDATE_MESSAGE_AS_ROUTING_LOOP:
						return "AS Routing Loop";
					case ERR_UPDATE_MESSAGE_INVALID_NEXT_HOP:
						return "Invalid NEXT_HOP Attribute";
					case ERR_UPDATE_MESSAGE_OPTIONAL_ATTR_ERROR:
						return "Optional Attribute Error";
					case ERR_UPDATE_MESSAGE_INVALID_NETWORK_FIELD:
						return "Invalid Network Field";
					case ERR_UPDATE_MESSAGE_MALFORMED_AS_PATH:
						return "Malformed AS_PATH";						
				}						
			default:
				if ( 0 == m_nSubCode )
					return "<no subcode>";
				else
					return "<Unsupported sub error code>";

		}
		
	}
	
	public String toString() {
		String s = getErrorMsg() + " - " + getSubErrorMsg();
		
		return s;
	}
	
}
