/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;

public class BGP4PathAttributeFactory {
	
	public BGP4PathAttributeFactory() {
	
	}
	
	public static BGP4PathAttributeIface create( byte b[] ) {
		
		BGP4PathAttributeFlags oFlags;
		ByteBuffer oBuf;
		byte nFlags, nType;
		short nLength;
		byte[] bsData;
		
		if ( b.length > 1 ) {
			oBuf = ByteBuffer.allocate( b.length );
			oBuf.put( b );
			oBuf.rewind();
			
			nFlags = oBuf.get();
			nType  = oBuf.get();
			
			oFlags = new BGP4PathAttributeFlags( nFlags );
			
			if ( !oFlags.isExtendedLength() )
				nLength = oBuf.get();
			else
				nLength = oBuf.getShort();
			
			bsData = new byte[ oBuf.remaining() ];
			oBuf.get( bsData );
						
			switch ( nType ) {
				case BGP4PathAttribute.TYPE_ORIGIN:
					return new BGP4PathAttributeOrigin( nFlags, nType, nLength, bsData );
				case BGP4PathAttribute.TYPE_AS_PATH:
					return new BGP4PathAttributeASPath( nFlags, nType, nLength, bsData );
				case BGP4PathAttribute.TYPE_NEXT_HOP:
					return new BGP4PathAttributeNextHop( nFlags, nType, nLength, bsData );
				case BGP4PathAttribute.TYPE_MULTI_EXIT_DISC:
					return new BGP4PathAttributeMultiExitDisc( nFlags, nType, nLength, bsData );
				case BGP4PathAttribute.TYPE_LOCAL_PREF:
					return new BGP4PathAttributeLocalPref( nFlags, nType, nLength, bsData );
				case BGP4PathAttribute.TYPE_ATOMIC_AGGREGATE:
					return new BGP4PathAttributeAtomicAggregate( nFlags, nType, nLength, bsData );
				case BGP4PathAttribute.TYPE_AGGREGATOR:
					return new BGP4PathAttributeAggregator( nFlags, nType, nLength, bsData );
				case BGP4PathAttribute.TYPE_COMMUNITIES:
					return new BGP4PathAttributeCommunities( nFlags, nType, nLength, bsData );
				default:
					System.err.println( "ERROR: Unsupported Path Attribute (type=" + nType + ")");
					return null;
			}
			
		}
		
		return null;
		
	}
	
}
