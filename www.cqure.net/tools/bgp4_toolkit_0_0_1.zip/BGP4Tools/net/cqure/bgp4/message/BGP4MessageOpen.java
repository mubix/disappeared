/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


package net.cqure.bgp4.message;

import java.nio.ByteBuffer;
import java.util.Vector;

import net.cqure.bgp4.BGP4MessageOption;

public class BGP4MessageOpen extends BGP4Message {

	private byte m_nVersion;
	private short m_nAS;
	private short m_nHoldTime;
	private int m_nBGPID;
	private byte m_nOptionLen;
	private Vector m_oMsgOption;
	
//	private final short BGP4_DEFAULT_HOLD_TIME = 180;
	
	public BGP4MessageOpen( short nAS, short nHoldTime, int nBGPID ) {
		super();
		
		m_nVersion = 4;
		m_nAS = nAS;
		m_nHoldTime = nHoldTime;
		m_nBGPID = nBGPID;
		
		m_nOptionLen = 0;
		m_oMsgOption = null;
		
		this.setType( BGP4Header.BGP_MSG_OPEN );
		this.setLength( (short)(this.getLength() + 10) );
	}
		
	public BGP4MessageOpen( short nAS, int nBGPID ) {
		this( nAS, (short)180, nBGPID  );
	}
	
	public BGP4MessageOpen( byte b[] ) {
		super();
	}
	
	public void addMessageOption( byte nType, byte nLen, byte[] bsValue ) {
		if ( null == m_oMsgOption)
			m_oMsgOption = new Vector();
		
		m_nOptionLen += nLen + 2;
		m_oMsgOption.add( new BGP4MessageOption( nType, nLen, bsValue ) );
		this.setLength( (short)(this.getLength() + nLen + 2 ) );
	}
	
	public byte[] toByteArray( ) {

		ByteBuffer oMsg, oHeader;
		int i = 0;
		
		oMsg = ByteBuffer.allocate( this.getLength() );
		oHeader = super.toByteBuffer();
		
		oMsg.put( oHeader.array() );
		oMsg.put( m_nVersion );
		oMsg.putShort( m_nAS );
		oMsg.putShort( m_nHoldTime );
		oMsg.putInt( m_nBGPID );
		oMsg.put( m_nOptionLen );

		if ( null != m_oMsgOption && 0 < m_oMsgOption.size() ) {
			for ( i=0; i<m_oMsgOption.size(); i ++ )
				oMsg.put( ((BGP4MessageOption)(m_oMsgOption.get( i ))).toByteArray() );
		}
		
		return oMsg.array();
	}
	
	
}
