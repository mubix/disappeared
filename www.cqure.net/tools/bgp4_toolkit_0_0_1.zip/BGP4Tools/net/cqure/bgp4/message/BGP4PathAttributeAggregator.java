/*
   BGP4Toolkit
   Copyright (c) 2006- Patrik Karlsson <patrik@cqure.net>

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package net.cqure.bgp4.message;

import java.nio.ByteBuffer;

public class BGP4PathAttributeAggregator implements BGP4PathAttributeIface {

	private short m_nAS;
	private int m_nIP;
	
	private BGP4PathAttributeHeader m_oHeader;
	
	public BGP4PathAttributeAggregator( byte nFlags, byte nType, short nLength, byte[] bsData ) {
		m_oHeader = new BGP4PathAttributeHeader( nFlags, nType, nLength );
		parseAttribute( bsData );
	}
	
	public byte[] toByteArray() {
		ByteBuffer oB = ByteBuffer.allocate( m_oHeader.length() );
		
		oB.put( m_oHeader.toByteArray() );
		oB.putShort( m_nAS );
		oB.putInt(m_nIP);
		
		return oB.array();
	}
	
	public void parseAttribute( byte[] bsData ) {
		ByteBuffer oBuf;
		
		if ( bsData.length == 6 ) {
			oBuf = ByteBuffer.allocate(6);
			oBuf.put( bsData );
			oBuf.rewind();
			
			m_nAS = oBuf.getShort();
			m_nIP = oBuf.getInt();
			oBuf = null;
		}
			
	}
	
	public String toString() {		
		return m_oHeader.toString() + " AS: " + m_nAS + " IP: " + m_nIP;
	}

	public int length() { 
		if ( null != m_oHeader )
			return m_oHeader.length();

		return 0;
	}
	
}
