/**
 * TftpEventListener.java
 * Copyright (c) 1998 Gaurang Hirpara
 * @version 1.0 - February 1998
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 */
package tftp.event;
import java.util.EventListener;

public abstract interface TftpEventListener extends EventListener
{
  public static final int SERVER_EVENT = 1;
  public static final int WORKER_EVENT = 1;
  public void tftpMessage (TftpEvent e);
}
