/**
 * TftpEvent.java
 * Copyright (c) 1998 Gaurang Hirpara
 * @version 1.0 - February 1998
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 */
package tftp.event;
import java.net.InetAddress;
import java.util.EventObject;

public class TftpEvent extends EventObject
{
  public TftpEvent(Object source, 
		   InetAddress remote, 
		   int remotePort, 
		   int ID,
		   int type,
		   String arg) {
    super (source);
    this.remote = remote;
    this.remotePort = remotePort;
    this.ID = ID;
    this.type = type;
    this.arg = arg;
  }

  public InetAddress getAddress()
  {
    return remote;
  }

  public int getRemotePort()
  {
    return remotePort;
  }

  public int getID()
  {
    return ID;
  }

  public int getType()
  {
    return type;
  }
  
  public String getArg()
  {
    return arg;
  }

  InetAddress remote; 
  int remotePort, ID, type;
  String arg;

  public final static int REQUEST_RECEIVED   = 1;
  public final static int REQUEST_PROCESSING = 2;
  public final static int REQUEST_COMPLETE   = 3;
  public final static int REQUEST_INCOMPLETE = 4;
}
