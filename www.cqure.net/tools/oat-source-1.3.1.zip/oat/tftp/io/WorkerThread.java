/**
 * WorkerThread.java
 * Copyright (c) 1998 Gaurang Hirpara
 * @version 1.0 - February 1998
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 */
package tftp.io;
import tftp.TftpIface;
import tftp.Utility;
import tftp.event.TftpEvent;
import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;


public class WorkerThread extends Thread
{
    BufferedInputStream bis = null;
    DataOutputStream dos = null;

    DatagramSocket rec = null;
    DatagramPacket inPacket, ackPacket;
    InetAddress remoteAddr;
    ServerThread server;

    byte[] inBuffer, ackBuffer;
    static int seed = 29000;
    int sourceTID, destinationTID, state;
    int opcode, imode;
    int blockNumber = 0, retransmits = 0;
    String idString = null;
    String filename;
    String mode;

    TftpIface iface;

    public WorkerThread(ServerThread server,
			TftpIface iface,
			DatagramPacket firstPacket)
    {
        this.iface = iface;
	this.server = server;
	this.remoteAddr = firstPacket.getAddress();
	destinationTID = firstPacket.getPort();
	sourceTID = seed++;
	if (sourceTID > 65000) {
	    sourceTID = seed = 29000;
	}
	buildRequestInfo (firstPacket);
	inBuffer = new byte[528];
	ackBuffer = new byte[528];

	idString = firstPacket.getAddress().toString() 
	  + ":"
	  + (sourceTID) 
	  + "-"
	  + (destinationTID);
    }

    public String getID()
    {
      return idString;
    }

    public InetAddress getAddress()
    {
      return remoteAddr;
    }
  
    public String getPortKey()
    {
      return sourceTID + ":" + destinationTID;
    }

    public void run()
    {
        int inBlockNumber, inOpcode, setup;
        state = Utility.BEGIN;
	if (opcode == Utility.WRQ_PACKET) {
	    // It's a write request

	    // If filename that came with WWQ is bogus, report error
	    if (filename == null 
		|| filename.length() == 0) {
  	        badFile ("Illegal filename " + filename);
		dispatchTftpEvent (this, remoteAddr,
				   destinationTID,
				   TftpEvent.REQUEST_INCOMPLETE,
				   Utility.ERR_PACKET,
				   "Illegal file name in write request");
		terminate();
		return;
	    }

	    try {
		// Try to open the file stream. If we can't, report error.
	        setup = setupFileWriter();
		if (setup != Utility.ERR_NO_ERROR) {
		  if (setup != Utility.ERR_NOT_DEFINED) {
		    Utility.sendPacket (remoteAddr,
					sourceTID,
					destinationTID,
					Utility.ERR_PACKET,
					setup,
					null,
					null);
		  }
		  dispatchTftpEvent (this, 
				     remoteAddr,
				     destinationTID,
				     TftpEvent.REQUEST_INCOMPLETE,
				     Utility.ERR_PACKET,
				     Utility.fetchErrorMessage (setup,
					 "Could not open file " + filename));
		  terminate();
		  return;
		}

		dispatchTftpEvent (this, 
				   remoteAddr,
				   destinationTID,
				   TftpEvent.REQUEST_PROCESSING,
				   Utility.WRQ_PACKET,
				   filename);
	      
		// Send the first ack letting the remote guy know it's
		// okay to start sending data packets
		Utility.sendPacket (remoteAddr,
				    sourceTID,
				    destinationTID,
				    Utility.ACK_PACKET,
				    blockNumber,
				    null,
				    null);
		
		rec = new DatagramSocket (sourceTID);
		rec.setSoTimeout (iface.getTimeout (remoteAddr));

		while (true) {
		    // Wait for DATA packet
		    inPacket = new DatagramPacket (inBuffer, 528);
		    try {
		        Utility.receive (rec, inPacket); 
			inBlockNumber = Utility.fetchBlockNumber (
					   inPacket.getData());
			inOpcode = Utility.fetchOpcode (
					   inPacket.getData());
			if (inOpcode == Utility.ERR_PACKET) {
			  iface.logMessage (remoteAddr, 1,  
					     Utility.fetchErrorMessage (
					       inPacket.getData()));
			  dispatchTftpEvent (this, remoteAddr,
					     destinationTID,
					     TftpEvent.REQUEST_INCOMPLETE,
					     Utility.ERR_PACKET,
					     Utility.fetchErrorMessage (
						inPacket.getData()));

			  terminate();
			  return;
			}
			if (inBlockNumber != (blockNumber + 1)) {
			  continue;
			}
		    } catch (InterruptedIOException ios) {
			// We didn't get the data packet.
   		        // If we've exhausted our retransmit limit,
   		        // send an error and bail. Otherwise,
  		        // resend the ack.
		        if (++retransmits > 
			    iface.getRetransmitCount (remoteAddr)) {
			  Utility.sendPacket (remoteAddr,
					      sourceTID,
					      destinationTID,
					      Utility.ERR_PACKET,
					      Utility.ERR_NOT_DEFINED,
					      new String ("Retransmit limit exceeded").getBytes(),
					      rec);
			  dispatchTftpEvent (this, remoteAddr,
					     destinationTID,
					     TftpEvent.REQUEST_INCOMPLETE,
					     Utility.ERR_PACKET,
					     "Retransmit limit exceeded");
			  terminate();
			  return;
			} else {
			  Utility.sendPacket (remoteAddr,
					      sourceTID,
					      destinationTID,
					      Utility.ACK_PACKET,
					      blockNumber,
					      null,
					      rec);
			  continue;
			}
		    }		 
		    
		    // We got the data packet, so write it out to 
		    // disk, send the ack for it, and wait again. 
		    writeData (inPacket.getData(), 
			       inPacket.getLength());
		    blockNumber++;
		    Utility.sendPacket (remoteAddr,
					sourceTID,
					destinationTID,
					Utility.ACK_PACKET,
					blockNumber,
					null,
					rec);
		    if (inPacket.getLength() < Utility.BLOCK_SIZE) {
		      break;
		    }
		    
		}
		dispatchTftpEvent (this, remoteAddr,
				   destinationTID,
				   TftpEvent.REQUEST_COMPLETE,
				   Utility.WRQ_PACKET,
				   filename);
		terminate();
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	} else if (opcode == Utility.RRQ_PACKET) {
	  // It's a read request
	  if (filename == null 
	      || filename.length() == 0) {
	    badFile ("Bad file " + filename);
		dispatchTftpEvent (this, remoteAddr,
				   destinationTID,
				   TftpEvent.REQUEST_INCOMPLETE,
				   Utility.ERR_PACKET,
				   "Illegal file name in read request");
	    terminate();
	    return;
	  }

	  setup = setupFileReader ();
	  if (setup != Utility.ERR_NO_ERROR) {
	    if (setup != Utility.ERR_NOT_DEFINED) {
	      Utility.sendPacket (remoteAddr,
				  sourceTID,
				  destinationTID,
				  Utility.ERR_PACKET,
				  setup,
				  new String (
			            "Could not open file.").getBytes(),
				  null);

	    }
	    dispatchTftpEvent (this, remoteAddr,
			       destinationTID,
			       TftpEvent.REQUEST_INCOMPLETE,
			       Utility.ERR_PACKET,
			       Utility.fetchErrorMessage (setup, 
			       "Could not open file for read request"));
	    terminate();
	    return;
	  }

	  int rsize;
	  blockNumber = 1;
	  

	  try {
	    rec = new DatagramSocket (sourceTID);
	    rec.setSoTimeout (iface.getTimeout (remoteAddr));
	  } catch (SocketException e) {
	    e.printStackTrace();
	  }

	  inBuffer = readData(512);
	  
	  if (inBuffer == null) {
	    Utility.sendPacket (remoteAddr,
				sourceTID,
				destinationTID,
				Utility.ERR_PACKET,
				Utility.ERR_NOT_DEFINED,
				new String ("Could not read file "
					    + filename).getBytes(),
				rec);
	    dispatchTftpEvent (this, remoteAddr,
			       destinationTID,
			       TftpEvent.REQUEST_INCOMPLETE,
			       Utility.ERR_PACKET,
			       "Could not open file for read request");
	    terminate();
	    return; // grievous error. send err packet ******
	  }


	  dispatchTftpEvent (this, 
			     remoteAddr,
			     destinationTID,
			     TftpEvent.REQUEST_PROCESSING,
			     Utility.RRQ_PACKET,
			     filename);


	  while (state != Utility.COMPLETE) {
	    Utility.sendPacket (remoteAddr,
				sourceTID,
				destinationTID,
				Utility.DATA_PACKET,
				blockNumber,
				inBuffer,
				rec);
	    // Wait for response ack
	    try {
	      ackPacket = new DatagramPacket (ackBuffer, ackBuffer.length);
	      Utility.receive (rec, ackPacket); 
	      inBlockNumber = Utility.fetchBlockNumber (
				      ackPacket.getData());
	      inOpcode = Utility.fetchOpcode (
				      ackPacket.getData());
	      if (inOpcode == Utility.ERR_PACKET) {
		iface.logMessage (remoteAddr, 1, 
				   Utility.fetchErrorMessage (
				      ackPacket.getData()));
		dispatchTftpEvent (this, remoteAddr,
				   destinationTID,
				   TftpEvent.REQUEST_INCOMPLETE,
				   Utility.ERR_PACKET,
				   Utility.fetchErrorMessage (
				      ackPacket.getData()));

		terminate();
		return;
	      }
	      if (inBlockNumber != blockNumber) {
		continue;
	      }
	    } catch (InterruptedIOException ios) {
	      // Missed! Resend data packet!
	      // We didn't get the ack packet.
	      // If we've exhausted our retransmit limit,
	      // send an error and bail. Otherwise,
	      // resend the ack.
	      if (++retransmits > 
		  iface.getRetransmitCount (remoteAddr)) {
		Utility.sendPacket (remoteAddr,
				    sourceTID,
				    destinationTID,
				    Utility.ERR_PACKET,
				    Utility.ERR_NOT_DEFINED,
				    new String ("Retransmit limit exceeded").getBytes(),
				    rec);
		dispatchTftpEvent (this, remoteAddr,
				   destinationTID,
				   TftpEvent.REQUEST_INCOMPLETE,
				   Utility.ERR_PACKET,
				   "Retransmit limit exceeded");

		terminate();
		return;
	      }
	      continue;
	    } catch (IOException e) {
	      e.printStackTrace();
	    }

	    if (state == Utility.RUNT_PACKET) {
	      state = Utility.COMPLETE;
	      continue;
	    }

	    // Got it! Read more data
	    rsize = readAvailable();
	    inBuffer = readData(512); 
	    if (rsize < 512) {
	      state = Utility.RUNT_PACKET;
	    }
	    blockNumber++;
	  }
	  dispatchTftpEvent (this, remoteAddr,
			     destinationTID,
			     TftpEvent.REQUEST_COMPLETE,
			     Utility.RRQ_PACKET,
			     filename);
	  terminate();
	}
    }

    private void terminate()
    {
      if (bis != null) {
	dismantleFileReader();
      } else if (dos != null) {
	dismantleFileWriter();
      }
      if (rec != null) {
	rec.close();
	rec = null;
      }
      server.workerTerminated (getID());
    }

    private byte[] readData(int len)
    {
      int useLen = Math.min (readAvailable(), len);
      byte[] rv = new byte[useLen];
      try {
	bis.read (rv, 0, useLen);
      } catch (IOException ioe) {
	ioe.printStackTrace();
	return null;
      }
      return rv;
    }

    private void writeData (byte[] data, int len)
    {
      try {
	dos.write (data, 4, len - 4);
      } catch (IOException ioe) {
	ioe.printStackTrace();
      }
    }

    private int readAvailable()
    {
      try {
	return bis.available();
      } catch (IOException ioe) {
	ioe.printStackTrace();
	return -1;
      }
    }

    private int setupFileWriter()
    {
      int rv = Utility.ERR_NO_ERROR;
      File f = new File (filename); 
      if (f.exists() && !iface.getAllowOverWrite (getAddress())) {
	return Utility.ERR_FILE_EXISTS;
      }
      /*if (!f.canWrite()) {
	return Utility.ERR_ACCESS_VIOLATION;
      }*/
      try {
	dos = new DataOutputStream (new FileOutputStream (filename));
	rv = Utility.ERR_NO_ERROR;
      } catch (FileNotFoundException fnf) {
	badFile ("Could not open file " + filename);
	rv = Utility.ERR_NOT_DEFINED;
      } catch (IOException ioe) {
	ioe.printStackTrace();
      } finally {
	return rv;
      }
    }
	
    private int setupFileReader()
    {
      File f = new File (filename); 
      if (!f.exists()) {
	return Utility.ERR_FILE_NOT_FOUND;
      }
      if (!f.canRead()) {
	return Utility.ERR_ACCESS_VIOLATION;
      }
      try {
	bis = new BufferedInputStream (new FileInputStream (f));
      } catch (FileNotFoundException fnf) {
	badFile ("Could not open file " + filename);
	return Utility.ERR_NOT_DEFINED;
      }
      return Utility.ERR_NO_ERROR;
    }

    private void dismantleFileWriter()
    {
      try {
	dos.close();
	dos = null;
      } catch (IOException ioe) {
	ioe.printStackTrace();
      }
    }

    private void dismantleFileReader()
    {
      try {
	bis.close();
	bis = null;
      } catch (IOException ioe) {
	ioe.printStackTrace();
      }
    }


     private void dispatchTftpEvent(Object source,
				   InetAddress addr,
				   int port,
				   int id,
				   int opcode,
				   String arg)
    {
				   
      server.dispatchTftpEvent (new TftpEvent (source, addr, port, id, opcode,
					      arg));
    }

    private void badFile(String message)
    {
      Utility.sendPacket (remoteAddr,
			  sourceTID,
			  destinationTID,
			  Utility.ERR_PACKET,
			  blockNumber,
			  message.getBytes(),
			  null);
    }

    public void buildRequestInfo (DatagramPacket inp)
    { 
        String temp;
        int fileStart, modeStart, count, i;
	byte[] data = inp.getData();
	this.opcode = Utility.fetchOpcode (data);
	if (opcode == Utility.RRQ_PACKET 
	    || opcode == Utility.WRQ_PACKET) {

  	    for (i = 2; i < data.length; i++) {
	      if (data[i] == 0) break;
	    }
	    fileStart = 2;
	    filename = new String (data, fileStart, i - 2);
	    
	    modeStart = 2 + filename.length() + 1;
	    
	    for (i = modeStart, count = 0 ; i < data.length; i++, count++) {
	      if (data[i] == 0) break;
	    }
	    mode = new String (data, modeStart, count);

	    temp = iface.getBasePath (remoteAddr);
	    if (temp != null 
		&& !temp.equals ("")) {

		/* 20020102 - dot dot workaround by patrik.karlsson@ixsecurity.com */
		while ( filename.indexOf("..") != -1 ) {
		    filename = filename.substring(filename.indexOf("..")+2);
		}

	      filename = temp + (File.separator) + filename;
	    } 
	} else {
	    filename = null;
	    mode = null;
	}
	if (mode.equalsIgnoreCase ("ascii")
	     || mode.equalsIgnoreCase ("netascii")) {
	  imode = Utility.ASCII_MODE;
	} else if (mode.equalsIgnoreCase ("octet")) {
	  imode = Utility.OCTET_MODE;
	} else {
	  imode = Utility.UNKNOWN_MODE;
	}
    }
	    
}




