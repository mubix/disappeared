#!/bin/sh
#
# Wrapper for OraclePWGuess by patrik.karlsson@ixsecurity.com
#

JAVA=java
JDBC=classes111.zip
$JAVA -cp .:$JDBC:ork.jar ork.OraclePwGuess $*