/* 
   Oracle Auditing Tools
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package ork;

import java.sql.*;
import java.util.*;
import java.io.*;
import java.net.*;
import oracle.jdbc.driver.*;
import gnu.getopt.*;

public class OracleTNSCtrl {

    private static OracleTNSSocket m_oTNSSock = null;

    private static String m_sVersion = OATVersion.getVersion();
    private static String m_sAuthor = OATVersion.getAuthor();

    void OracleTNSCtrl() {

    }

    public static void usage() {

	System.out.println("\tOracle TNS Control " + m_sVersion + " by " + m_sAuthor);
	System.out.println("\t---------------------------------------------");
	System.out.println("\tOracleTNSCtrl [options]");
	System.out.println("\t\t-s*\t<servername>");
	System.out.println("\t\t-P\t<portnr>");
	System.out.println("\t\t-c\tcommand to execute (status/services/version/etc.)");
	System.out.println("\t\t-I*\tinteractive mode");
	System.out.println("\t\t-v\tbe verbose");
	System.out.println("");

    }

    private static void execTNSCmd(String sCommand) {

	byte buf2[] = new byte[1024];
	String sAnswer = new String();

	if ( sCommand.equalsIgnoreCase("status") ) {
	    System.out.println("Status command returned SIDS:");
	    Vector oVector = m_oTNSSock.getOracleSIDS();

	    /* did the status call actualy return stuff ?? */
	    if ( oVector != null ) {
		for ( int i = 0; i<oVector.size(); i++ ) {
		    System.out.println( (String) oVector.get( i ) );
		}
	    }
	}
	else {
	    if ( !m_oTNSSock.sendCommand(sCommand) ) {
		System.err.println("ERROR: Could not send command (verify port try 1521 or 1526)");
		System.exit(1);
	    }
	    
	    byte buf[] = m_oTNSSock.recvCommandAnswer();

	    /* Was the command succesfull ?? */
	    if ( buf[4] != 2 )
		return;
	    
	    while ( ( buf2 = m_oTNSSock.recvCommandAnswer() ) != null ) {
		sAnswer += new String( buf2 );
	    }

	    System.out.println(sAnswer);

	}	   

    }

    public static void main (String args []) {

	Getopt oOpt = new Getopt("OraclePwGuess", args, "s:hc:P:I");
	int c;
	String arg;
	String sCommand = "";
	String sServerName = null;
	int nOraclePort = 1521;
	boolean bInteractiveMode = false;

	/* parse arguments */
	while ( ( c = oOpt.getopt() ) != -1 ) {

	    switch( c ) {

	    case 'c':
		arg = oOpt.getOptarg();
		sCommand = arg;
		break;

	    case 's':
		arg = oOpt.getOptarg();
		sServerName = arg;
		break;
		
	    case 'P':
		nOraclePort = Integer.parseInt( oOpt.getOptarg() );
		break;

	    case 'I':
		bInteractiveMode = true;
		break;

	    case 'h':
		usage();
		System.exit(1);
		break;
	    }

	}

	if ( sServerName == null || ( sCommand.length() == 0 && bInteractiveMode == false ) ) {
	    usage();
	    System.exit(1);
	}

	/* do some bragging */
	System.out.println("Oracle TNS Control " + m_sVersion + " by " + m_sAuthor);
	System.out.println("---------------------------------------------");

	m_oTNSSock = new OracleTNSSocket( sServerName, nOraclePort );
	
	/* Can we connect to the listener ?? */
	if ( !m_oTNSSock.connect() || m_oTNSSock == null ) {
	    System.err.println("ERROR: Failed to connect to ORACLE listener!");
	    System.exit(1);
	}

	if ( !bInteractiveMode )
	    execTNSCmd(sCommand);
	else {

	    LineNumberReader oInReader = new LineNumberReader( new InputStreamReader( System.in ) );

	    while ( sCommand != null && !sCommand.equalsIgnoreCase("quit") && !sCommand.equalsIgnoreCase("exit") ) {
		
		m_oTNSSock.connect();

		try {
		    System.out.print("tnscmd> ");
		    sCommand = oInReader.readLine();
		}
		catch ( IOException e ) {
		    e.printStackTrace();
		}

		if ( sCommand != null && sCommand.equalsIgnoreCase("set password") ) {
		    System.out.print("password: ");
		    try {
			m_oTNSSock.setTNSPassword(oInReader.readLine());
		    }
		    catch( IOException e ) {
			e.printStackTrace();
		    }
		}
		else if ( sCommand != null && sCommand.equalsIgnoreCase("help") ) {
		    System.out.println("help");
		    System.out.println("set password - sets the password with which to connect to the listener");
		    System.out.println("services - shows services");
		    System.out.println("status - shows status");
		    System.out.println("version - returns version information");
		}
		else if ( sCommand != null && !sCommand.equalsIgnoreCase("quit") && !sCommand.equalsIgnoreCase("exit") && 
		     sCommand.length() > 0 )
		    execTNSCmd(sCommand);

		m_oTNSSock.close();

	    } // end while

	} // end else
	
    } // end main

}
