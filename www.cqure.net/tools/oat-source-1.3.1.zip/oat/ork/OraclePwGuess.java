/* 
   Oracle Auditing Tools
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
  Changes:
  2002-06-03 - Changed order of password so that the most likely to exist are tested first
               If the sid contains extproc, skipp password checking.


*/


package ork;

import java.sql.*;
import java.util.*;
import java.io.*;
import oracle.jdbc.driver.*;
import gnu.getopt.*;

public class OraclePwGuess {

    static Connection m_oConn = null;
    private static boolean m_bDebug = false; /* should we be verbose or not */
    private static Vector m_oUserVector = null;
    private static Vector m_oPwVector = null;
    private static int m_nUser = 0;
    private static int m_nPw = 0;
    private static String m_sConnURL = null;

    private static String m_sVersion = OATVersion.getVersion();
    private static String m_sAuthor = OATVersion.getAuthor();

    /* 
       lame empty constructor 
       Yes I know my OO really sucks ! 
       Sorry but I'll do it better next time, I promise ! :)
    */
    public OraclePwGuess() {

    }

    private static String getNextPw() {

	if ( m_nPw == m_oPwVector.size() )
	    return null;

	String sPw = (String) m_oPwVector.get(m_nPw);
	m_nPw ++;
	return sPw;

    }

    private static String getNextUser() {

	if ( m_nUser == m_oUserVector.size() )
	    return null;

	String sUser = (String) m_oUserVector.get(m_nUser);
	m_nUser ++;
	return sUser;
    }

    private static void setNextUser(int nPos) {
	m_nUser = nPos;
    }

    private static void setNextPw(int nPos) {
	m_nPw = nPos;
    }

    /*
      Some usage info
    */
    public static void usage() {

	System.out.println("\tOracle Password Guesser " +m_sVersion + " by " + m_sAuthor);
	System.out.println("\t--------------------------------------------------");
	System.out.println("\tOraclePwGuess [options]");
	System.out.println("\t\t-s*\t<servername>");
	System.out.println("\t\t-u\t<userfile>");
	System.out.println("\t\t-p\t<passfile>");
	System.out.println("\t\t-d\t<SID>");
	System.out.println("\t\t-P\t<portnr>");
	System.out.println("\t\t-D\tdisables default pw checks");
	System.out.println("\t\t-C\tcheck for CREATE LIBRARY permissions");
	System.out.println("\t\t-v\tbe verbose");
	System.out.println("");

    }

    public static boolean checkLibraryPerms(String sUserName) {
	
	String sSQL = "select grantee, privilege from dba_sys_privs ";
	sSQL += "where privilege like 'CREATE%LIBRARY' ";
	sSQL += "and grantee='" +sUserName+ "'";

	try {

	    Statement oStmt = m_oConn.createStatement();
	    ResultSet oRS = oStmt.executeQuery(sSQL);

	    if ( oRS != null ) {
		oRS.close();
		return true;
	    }
	}
	catch ( SQLException e ) {
	    // e.printStackTrace();
	    // System.err.println("ERROR: Access to table denied");
	}

	return false;

    }

    /*
      do the actual oracle login
    */
    private static boolean oracleLogin(String sUserName, String sPassWord) {
	    
	/*
	  Lets try to load the Oracle JDBC driver
	*/
	try {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	}
	catch( ClassNotFoundException e ) {
	    System.err.println("ERROR: Could not load JDBC driver. Make sure it's in the classpath");
	    System.exit(1);
	    /* e.printStackTrace(); */
	}
	
	/*
	  Ok so the Driver loaded, let's try to login
	*/
	try {
	    m_oConn = DriverManager.getConnection (m_sConnURL, sUserName, sPassWord);
	}
	catch ( SQLException e ) {
	    /* do some corny error checking */
	    if ( e.toString().indexOf("could not establish") != -1 ) {
		System.out.println("ERROR: Wrong Oracle Port ! Try ( 1521 or 1526)");
		System.exit(1);
	    }
	    return false;
	}
	
	return true;
    }

    /* ugly wrappers are us */
    public static Connection checkDefaultPasswords(String sConnURL, boolean bCheckLibraryPerms,
						   boolean bReturnFirst) {

	/* convert url to lowercase and compare for extproc, if found abort */
	if ( sConnURL.toLowerCase().indexOf( "extproc" ) != -1 )
	    return null;

	m_sConnURL = sConnURL;
	return checkDefaultPasswords( bCheckLibraryPerms, bReturnFirst );
    }

    /* 
       Tries default accounts and if bCheckLibraryPerms is true it checks for
       Create Library permissions
       If bReturnFirst is true, it returns the first one found.
    */
    public static Connection checkDefaultPasswords(boolean bCheckLibraryPerms, boolean bReturnFirst) {

	String sUserName;
	String sPassWord;

	/* Thanks to Pete Finnigan at http://www.pentest-limited.com for the default logins
	 */
	
	PasswordItemList oList = new PasswordItemList( );
	PasswordItem oItem;

	oList.LoadPasswordFile( "accounts.default", "/" );
	
	while ( ( oItem = oList.GetNextItem() ) != null ) {    
	    
	    sUserName = oItem.GetUsername();
	    sPassWord = oItem.GetPassword();

	    if ( m_bDebug ) {
		System.err.println("DEBUG: Trying " + sUserName+ " with password " + sPassWord);
	    }

	    if ( oracleLogin( sUserName, sPassWord ) ) {
		System.out.println("Successfully logged in with " + sUserName + "/" + sPassWord);
		
		if ( bCheckLibraryPerms && checkLibraryPerms(sUserName) && bReturnFirst )
		    return m_oConn;
		else if ( bCheckLibraryPerms && checkLibraryPerms(sUserName) )
		    System.out.println("INFO: User has CREATE LIBRARY permissions");
	    }

	}

	return null;
    }

    /*
      Load the userfile into a Vector
    */
    private static Vector loadUserFile(String sFileName) {

	LineNumberReader oReader = null;
	Vector oVector = new Vector();
	String sLine = null;

	try {
	    oReader = new LineNumberReader( new FileReader ( sFileName ) );
	}
	catch ( FileNotFoundException e ) {
	    System.out.println("ERROR: Userfile was not found");
	    System.exit(1);
	}

	try {

	    /* add all usernames to a vector */
	    while ( ( sLine = oReader.readLine() ) != null ) {
		oVector.add( sLine );
	    }

	}
	catch ( IOException e ) {
	    System.out.println("ERROR: Could not read userfile");
	    System.exit(1);
	}
	
	m_nUser = 0;
	return oVector;

    }

    /* reset vector position */
    private static void resetUserVectorPos() {
	m_nUser = 0;
    }

    /* reset vector position */
    private static void resetPwVectorPos() {
	m_nPw = 0;
    }

    /*
      Load the PW file into a Vector
    */
    private static Vector loadPwFile(String sFileName) {

	LineNumberReader oReader = null;
	Vector oVector = new Vector();
	String sLine = null;

	try {
	    oReader = new LineNumberReader( new FileReader ( sFileName ) );
	}
	catch ( FileNotFoundException e ) {
	    System.out.println("ERROR: Passfile was not found");
	    System.exit(1);
	}

	try {

	    /* add all usernames to a vector */
	    while ( ( sLine = oReader.readLine() ) != null ) {
		oVector.add( sLine );
	    }

	}
	catch ( IOException e ) {
	    System.out.println("ERROR: Could not read passfile");
	    System.exit(1);
	}
	
	m_nPw = 0;
	return oVector;

    }

    /*
      Do some pwguessing using the user & password files
    */
    private static void doPwGuess( boolean bCheckLibraryPerms ) {

	String sUserName;
	String sPassWord;
	boolean bSuccess;

	while ( ( sUserName = getNextUser() ) != null ) {
	    while ( ( sPassWord = getNextPw() ) != null ) {
		bSuccess = oracleLogin(sUserName, sPassWord );
		if ( bSuccess ) {
		    System.out.println("Successfully logged in with " + sUserName + "/" + sPassWord );

		    if ( bCheckLibraryPerms && checkLibraryPerms(sUserName) ) {
			System.out.println("INFO: User has CREATE LIBRARY permissions");
		    }
		}
	    }
	    setNextPw(0);
	}

    }


    /*
      Main function
    */
    public static void main (String args []) {

	String sHostName = null;
	String sDataBase = null;
	String sLocalIP = null;

	boolean bCheckLibraryPerm = false;
	boolean bDefPassCheck = true;

	int nOraclePort = 1521;
	Getopt oOpt = new Getopt("OraclePwGuess", args, "s:d:u:p:hP:l:vCD");
	int c;
	String arg;
	Vector oSIDVector = new Vector();

	/* parse arguments */
	while ( ( c = oOpt.getopt() ) != -1 ) {

	    switch( c ) {

	    case 'C':
		bCheckLibraryPerm = true;
		break;

	    case 'D':
		bDefPassCheck = false;
		break;

	    case 's':
		arg = oOpt.getOptarg();
		sHostName = arg;
		break;
		
	    case 'd':
		arg = oOpt.getOptarg();
		sDataBase = arg;
		oSIDVector.add(sDataBase);
		break;

	    case 'u':
		arg = oOpt.getOptarg();
		m_oUserVector = loadUserFile( arg );
		break;
		
	    case 'p':
		arg = oOpt.getOptarg();
		m_oPwVector = loadPwFile( arg );
		break;

	    case 'P':
		arg = oOpt.getOptarg();
		nOraclePort = Integer.parseInt(arg);
		break;
		
	    case 'l':
		arg = oOpt.getOptarg();
		sLocalIP = arg;
		break;

	    case 'h':
		usage();
		System.exit(1);
		break;

	    case 'v':
		m_bDebug = true;
		break;

	    default:
		usage();
		System.exit(0);
	    }

	}

	/* do we have all the parameters needed */
	if ( sHostName == null || nOraclePort == -1 ) {
	    usage();
	    System.exit(0);
	}

	System.out.println("Oracle Password Guesser " +m_sVersion + " by " + m_sAuthor);
	System.out.println("--------------------------------------------------");

	/* Try to retrieve the database SID */
	if ( sDataBase == null ) {

	    OracleTNSSocket oTNSSock = new OracleTNSSocket( sHostName, nOraclePort );
	    oTNSSock.connect();
	    
	    oSIDVector = oTNSSock.getOracleSIDS();

	    if ( oSIDVector == null || oSIDVector.size() == 0 ) {
		System.err.println("ERROR: Enumerating ORACLE SIDS");
		System.exit(1);
	    }
	    
	}

	/* Make sure both user and pw file is chosen ! */
	if ( ( m_oUserVector != null && m_oPwVector == null ) || 
	     ( m_oUserVector == null && m_oPwVector != null ) ) {
	    usage();
	    System.exit(0);
	}

	/* loop through all SIDS */
	for ( int i=0; i<oSIDVector.size(); i++ ) {

	    sDataBase = (String) oSIDVector.get(i);

	    /* if we run into the extproc sid, skip it */
	    if ( sDataBase.equalsIgnoreCase("extproc") || sDataBase.equalsIgnoreCase("plsextproc") ) {
		System.err.println( "Skipping " + sDataBase + " ...");
	    }
	    else {

		System.out.println("INFO: Running pwcheck on SID " + sDataBase);

		m_sConnURL = "jdbc:oracle:thin:@" + sHostName + ":" + nOraclePort;
		m_sConnURL += ":" + sDataBase;
	    
		if ( bDefPassCheck )
		    checkDefaultPasswords( bCheckLibraryPerm, false);

		/* do we have a user and pw vector */
		if ( m_oUserVector != null && m_oPwVector != null )
		    doPwGuess( bCheckLibraryPerm );
	    
		/* Make sure we reset the vector positions on the preloaded files */
		resetUserVectorPos();
		resetPwVectorPos();
	    } /* end if plscheck */

	} /* end loop through sids */

    }
}
