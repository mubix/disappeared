#!/bin/sh
#
# This script extracts information from a SIP REGISTER, authentication request
# It uses these values to build a string suitable for offline cracking with John the Ripper
# http://www.openwall.com/john/
#
# In order to be able to start cracking the hash John the Ripper needs to be patched twice
# First off the jumbo patch needs to be applied which integrates lots of contributed patches
# The jumbo patch is available from the John the Ripper main page.
#
# Secondly my patch against the HDAA_fmt, which was written by Romain Raboin, needs to be applied
# This patch adds support for the older RFC2069 HTTP digest authentication used by SIP
# In addition it contains a fix for allowing the colon (:) in the SIP uri
#
# This patch can be found here:
# http://www.cqure.net/tools/HDAA_RFC2069.diff
#
# usage:
#
# extracting authorization information from a capture file (sipdump.pcap)
# tcpdump -nvr sipdump.pcap | ./extractsipauth.sh
#
# extracting authorization information from a live capture
# tcpdump -nvs 1500 -i eth1 'udp && port 5060' | ./extractsipauth.sh
#
# output:
# 
# 103:$response$ead7dbe427c115e952dc6df9b3458388$103$asterisk$REGISTER$sip_192.168.56.3$51ad969d$$$
# 103:$response$7ffeffbf79eb07c85815ae78b9e54083$103$asterisk$REGISTER$sip_192.168.56.3$2850d9ee$$$
#
# If all is good John the ripper should be able to crack the above information with the password "secret"
#
# Q: Why is this a shell script and not some fancy scripting language?
# A: Good question!
#
#
# Version 0.1 
#
# 20091122 - Created the initial version of the script - Patrik Karlsson <patrik@cqure.net>
#
#

function processAuthInfo
{
    # we just want to get rid of what's to the left of the first colon (:)
    hdrvalue=`echo $1 | cut -d':' -f 2-`

    # split the string on comma
    valuepairs=`echo $hdrvalue | awk '{z=split($0,flds,",")
for(i=1;i<=z;i++)
print flds[i]}'`

    for val in $valuepairs
    do
      paramname=`echo $val|cut -d'=' -f 1`
      paramval=`echo $val|cut -d'=' -f 2`

      # clean any surrounding quotes ...
      paramval=`echo $paramval | sed s/\"//g | sed s/:/_/g`
      typeset hash_${paramname}=$paramval
    done

    echo "$hash_username:\$response\$$hash_response\$$hash_username\$$hash_realm\$REGISTER\$$hash_uri\$$hash_nonce\$\$\$"
}

while read line
do
  if [[ $line == Authorization* ]]; then
      processAuthInfo "$line"
  fi
done