
struct db2_host {
	char name[22];
	char version[9];
	char name2[22];
	char ip[16];
};

SOCKET db2_send_discovery( char *p_srcip, char *p_dstip );
int db2_recv_discovery( SOCKET s, int n_timeout, struct db2_host **pp_hosts, int *n_count );
