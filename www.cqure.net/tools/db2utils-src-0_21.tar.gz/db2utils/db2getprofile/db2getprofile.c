//
// (C) Copyright Patrik Karlsson cqure.net 2007-
//     patrik@cqure.net, http://www.cqure.net
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>

#define _strdup(s) strdup(s)
#define _strnicmp(s1, s2, n1) strncasecmp(s1, s2, n1)
typedef unsigned long DWORD;
#endif


#include "db2getprofile.h"
#include "db2common.h"
#include "db2_structs.h"
#include "getopt.h"

/*
 * Tries to read data from SOCKET s into p_packet
 *
 * s		- the socket
 * p_packet - the char buffer to hold the data
 * n_size   - the size in chars of p_packet
 *
 * Returns: the number of bytes read
 *
 */
int read_socket( SOCKET s, char *p_packet, int n_size ) {

	fd_set rset;
	struct timeval tv;
	int n_read = 0, n_ret = 0;
	
	while( 1 ) {
	
		FD_ZERO( &rset );
		FD_SET( s, &rset );

		tv.tv_sec = 2;
		tv.tv_usec = 0;

#ifndef WIN32
		if ( 1 == select( s + 1, &rset, NULL, NULL, &tv ) ) {
#else
		if ( 1 == select( 2, &rset, NULL, NULL, &tv ) ) {
#endif
			n_ret = recv( s, p_packet + n_read, n_size, 0 );
			if ( 0 == n_ret || -1 == n_ret )
				break;
			else
				n_read += n_ret;
		}
		else
			break;

		if ( n_read == n_size )
			break;

	}

	return n_read;

}

/*
 * Reads a DB2DAS packet data into p_packet
 *
 * s	    - socket to read from
 * p_packet - char buffer that holds the data recieved from the socket
 * n_size   - the size of the buffer
 *
 * Returns: the number of bytes read
 */
int db2_read_packet( SOCKET s, char *p_packet, DWORD n_size ) {

	int n_read = -1;
	DWORD n_datalen = -1;
	char header_data[41];
	
	if ( sizeof( header_data ) != ( n_read = read_socket( s, header_data, sizeof( header_data ) ) ) ) {
		return DB2_COULD_NOT_READ_HEADER;
	}
	
	memcpy( &n_datalen, header_data+37, sizeof( n_datalen ) );

	if ( n_size < n_datalen ) {
		return DB2_BUFFER_TO_SMALL;
	}

	return read_socket( s, p_packet, n_datalen );
}

/* 
 * Creates a DB2DAS packet header and add the data in p_data.
 * Calculates the proper length and adds it to the header
 * 
 * unknown   - is the byte left of the length DWORD. Could be type?!
 * n_datalen - is the length of the data in p_data 
 * p_data    - is the actual data to be sent
 *
 * Returns: a db2_packet struct
 */
struct db2_packet *db2_create_packet( unsigned char unknown, int n_datalen, char *p_data ) {

	struct db2_packet *packet;
	char p_header[] = {	0x00, 0x00, 0x00, 0x00, 0x44, 0x42, 0x32, 0x44, 
						0x41, 0x53, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 
						0x01, 0x04, 0x00, 0x00, 0x00, 0x10, 0x39, 0x7a, 
						0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
						0x00, 0x00, 0x00, 0x00, 0x02 };

	if ( NULL == ( packet = malloc( sizeof( struct db2_packet ) ) ) )
		return NULL;

	p_header[ sizeof( p_header ) - 1 ] = unknown;

	memcpy( (char *)&packet->header, p_header, sizeof( p_header ) );
	packet->header.n_datalen = n_datalen;

	if ( NULL == ( packet->p_data = (char *) malloc( n_datalen ) ) )
		return NULL;

	memcpy( packet->p_data, p_data, n_datalen );
	
	return packet;
}

/*
 * Sends a DB2DAS packet
 * db2_send_packet calls db2_create_packet in order to create a proper packet header.
 *
 * s	   - is the socket
 * unknown - is the byte left of the size in the header. Type?!
 * n_len   - is the length of the packet
 * p_data  - is the data to be sent
 */
int db2_send_packet( SOCKET s, unsigned char unknown, DWORD n_len, char *p_data ) {
	
	int n_sent;
	struct db2_packet *packet;

	packet = db2_create_packet( unknown, n_len, p_data );

	if ( NULL == ( p_data = (char *) malloc( packet->header.n_datalen + sizeof( packet->header ) ) ) ) {
		return -1;
	}

	memcpy( p_data, &packet->header, sizeof( packet->header ) );
	memcpy( p_data + sizeof( packet->header ), packet->p_data, packet->header.n_datalen );

	n_sent = send( s, p_data, packet->header.n_datalen + sizeof( packet->header ), 0 );

	free( packet->p_data );
	free( packet );
	free( p_data );

	return n_sent;

}

/* Gets the profile information for p_ip */
void db2_get_profile( char *p_ip ) {

	SOCKET s;

	struct sockaddr_in sin;
	char rbuf[8192];
	int n_sent = -1, n_recv = -1, n_retry = 10;

	sin.sin_addr.s_addr = inet_addr( p_ip );
	sin.sin_family = AF_INET;
	sin.sin_port = htons( 523 );

	while ( n_retry > 0 ) {

		if ( INVALID_SOCKET == ( s = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP ) ) ) {
			fprintf(stderr, "[e] Failed to create socket\n" );
			return;
		}

		if ( SOCKET_ERROR == ( connect( s, ( const struct sockaddr *)&sin, sizeof( sin ) ) ) ) {
			fprintf(stderr, "[e] Connecting to %s failed\n", p_ip );
			return;
		}

		n_retry --;

		/* a discovery packet needs to be sent, if not the rest does not work */
		//db2_send_discovery( NULL, p_ip );

		/* The ugly code starts here */
		n_sent = db2_send_packet( s, 2, sizeof( discover_instance_data_1 ), discover_instance_data_1 );
		if ( 0 > ( n_recv = db2_read_packet( s, rbuf, sizeof( rbuf ) ) ) ) {
			closesocket( s );
			continue;
		}

		n_sent = db2_send_packet( s, 5, sizeof( discover_instance_data_3 ), discover_instance_data_3 );
		if ( 0 > ( n_recv = db2_read_packet( s, rbuf, sizeof( rbuf ) ) ) ) {
			closesocket( s );
			continue;
		}

		n_sent = db2_send_packet( s, 3, sizeof( discover_instance_data_5 ), discover_instance_data_5 );
		if ( 0 > ( n_recv = db2_read_packet( s, rbuf, sizeof( rbuf ) ) ) ) {
			closesocket( s );
			continue;
		}

		n_sent = db2_send_packet( s, 10, sizeof( discover_instance_data_7 ), discover_instance_data_7 );
		if ( 0 > ( n_recv = db2_read_packet( s, rbuf, sizeof( rbuf ) ) ) ) {
			closesocket( s );
			continue;
		}

		n_sent = db2_send_packet( s, 6, sizeof( discover_instance_data_9 ), discover_instance_data_9 );
		n_sent = db2_send_packet( s, 7, sizeof( discover_instance_data_10 ), discover_instance_data_10 );

		if ( 0 > ( n_recv = db2_read_packet( s, rbuf, sizeof( rbuf ) ) ) ) {
			closesocket( s );
			continue;
		}

		/* is the packet big enough? If so dump it to the screen */
		if ( n_recv > 195 ) {
			printf( "%s", rbuf+195 );
			break;
		}

		closesocket( s );

	}

	/* The last read was negative. No profile was found */
	if ( 0 > n_recv )
		fprintf( stderr, "[e] An error occured fetching profile information for %s\n", p_ip );


}

void banner() {

	int n_chars = -1;
	
	printf("\n");
	n_chars = printf( "%s %s by %s\n", TOOL_TITLE, TOOL_VERSION, TOOL_AUTHOR );
	for( ; n_chars>1; n_chars -- )
		printf( "-" );

	printf("\n");

}

void usage( char *p_prog ) {
	banner();
	printf("usage: %s <ip>\n", p_prog );
	printf("\n");
}

int main( int argc, char **argv ) {

	int c = -1, n_counter = 0;
	char *p_dstip;

#ifdef WIN32
	WSADATA wsa;

	WSAStartup( MAKEWORD( 2, 2 ), &wsa );
#endif

	while( 1 ) {
		c = getopt( argc, argv, "h" );

		if ( -1 == c )
			break;

		n_counter += 2;

		switch( c ) {

			case 'h':
				usage( argv[0] );
				exit( -1 );
				break;
			default:
				usage( argv[0] );
				exit( -1 );	
				break;

		}
	
	}

	if ( argc != 2 ) {
		usage(argv[0]);
		exit(-1);
	}

	p_dstip = _strdup( argv[ argc - 1 ] );
	banner();
	db2_get_profile( p_dstip );

#ifdef WIN32
	WSACleanup();
#endif

}
