//
// (C) Copyright Patrik Karlsson cqure.net 2007-
//     patrik@cqure.net, http://www.cqure.net
//

#pragma pack(push, 1)

struct db2_getaddr {
	char header[11];//  = "DB2GETADDR";
	char version[9]; // = "SQL09010";
};

struct db2_retaddr {
	char header[11];
	char version[9];
	char name[22];
	char name2[22];
	char pad[234];
};
