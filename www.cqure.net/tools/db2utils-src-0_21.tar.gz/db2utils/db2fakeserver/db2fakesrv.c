//
// (C) Copyright Patrik Karlsson cqure.net 2007-
//     patrik@cqure.net, http://www.cqure.net
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
#include <winsock2.h>
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#define _strdup(s) strdup(s)
#define _strnicmp(s1, s2, n1) strncasecmp(s1, s2, n1)
#endif

#include "db2fakesrv.h"
#include "db2_structs.h"
#include "getopt.h"

#ifdef WIN32
void srv_startup() {
	WSADATA wsa;

	WSAStartup( MAKEWORD(2,2), &wsa );
}
void srv_shutdown() {
	WSACleanup();
}
#else
void srv_startup() {
	return;
}
void srv_shutdown() {
	return;
}
#endif

char *to_lowercase( char *p_str ) {

	int n_pos = (int)strlen( p_str );
	char *p_lowcstr;

	p_lowcstr = _strdup( p_str );
	
	for( ; n_pos >=0 ; n_pos -- )
		p_lowcstr[n_pos] = tolower( p_str[n_pos] );

	return p_lowcstr;
}

void srv_listen( char *p_ip, unsigned int n_port, char *p_name, char *p_version ) {

#ifdef WIN32
	SOCKET s;
#else
	int s;
#endif

	char rbuf[1024];
	char *p_lname;
	int n_clilen, n_err, n_optval = 1;

	struct db2_retaddr db2_ret;
	struct sockaddr_in sin, cli_sin;

	if ( NULL == p_ip )
		sin.sin_addr.s_addr = htonl( INADDR_ANY );
	else
		sin.sin_addr.s_addr = inet_addr( p_ip );

	sin.sin_family = AF_INET;
	sin.sin_port = htons( n_port );

	if ( INVALID_SOCKET == ( s = socket( AF_INET, SOCK_DGRAM, IPPROTO_UDP ) ) ) {
		fprintf(stderr, "[e] Failed to create socket\n");
		return;
	}

	if ( SOCKET_ERROR == ( bind( s, (struct sockaddr *)&sin, sizeof( sin ) ) ) ) {
		fprintf(stderr, "[e] Failed to bind to %s:%d\n", p_ip, n_port );
		return;
	}

	n_clilen = sizeof( cli_sin );
	p_lname = to_lowercase(p_name);
		
	printf("Listening for discovery packets on %s:%d ...\n", p_ip, n_port );
	while ( 0 < ( n_err = recvfrom( s, rbuf, sizeof( rbuf ), 0, (struct sockaddr *)&cli_sin, &n_clilen ) ) ) {
		memset( (char *)&db2_ret, 0, sizeof( db2_ret ) );
		strncpy( db2_ret.header, "DB2RETADDR", sizeof( db2_ret.header ) - 1 );
		strncpy( db2_ret.name, p_name, sizeof( db2_ret.name ) - 1);
		strncpy( db2_ret.name2, p_lname, sizeof( db2_ret.name2 ) - 1);
		strncpy( db2_ret.version, p_version, sizeof( db2_ret.version ) );
		printf("Sending response to %s\n", inet_ntoa( cli_sin.sin_addr ) );
		sendto( s, (char *)&db2_ret, sizeof( db2_ret ), 0, (struct sockaddr *)&cli_sin, sizeof( cli_sin ) );
	}

}

void banner() {

	int n_chars = -1;
	
	printf("\n");
	n_chars = printf( "%s %s by %s\n", TOOL_TITLE, TOOL_VERSION, TOOL_AUTHOR );
	for( ; n_chars>1; n_chars -- )
		printf( "-" );

	printf("\n");

}

void usage( char *p_prog ) {

	banner();
	printf("usage: %s <-a|-s> [-n <name> -v <version>]\n", p_prog );
	printf("\n");
	printf("Options:\n");
	printf("  -a        - bind to all interfaces\n");
	printf("  -s <ip>   - bind to ip address\n" );
	printf("  -n <name> - respond with specified name\n");
	printf("  -v <ver>  - respond with specified version\n");
	
}


int main( int argc, char **argv ) {

	char *p_srcip = NULL, *p_name = "fakedb2", *p_version = "SQL09010";
	unsigned int n_port = 523;
	
	int c = -1;

	while( 1 ) {
		c = getopt( argc, argv, "s:n:v:ah" );

		if ( -1 == c )
			break;

		switch( c ) {

			case 'a':
				p_srcip = _strdup( "0.0.0.0" );
				break;
			case 'n':
				p_name = _strdup( optarg );
				break;
			case 'v':
				p_version = _strdup( optarg );
				break;
			case 's':
				p_srcip = _strdup( optarg );
				break;
			case 'h':
				usage( argv[0] );
				exit( -1 );
				break;
			default:
				usage( argv[0] );
				exit( -1 );	
				break;

		}
	
	}

	if ( NULL == p_srcip ) {
		usage( argv[0] );
		exit( -1 );
	}

	banner();
	srv_startup();
	srv_listen( p_srcip, n_port, p_name, p_version );
	srv_shutdown();

}
