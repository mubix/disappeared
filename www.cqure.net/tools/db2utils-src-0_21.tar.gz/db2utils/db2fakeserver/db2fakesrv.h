//
// (C) Copyright Patrik Karlsson cqure.net 2007-
//     patrik@cqure.net, http://www.cqure.net
//

const char *TOOL_TITLE   = "db2fakesrv";
const char *TOOL_VERSION = "v0.21";
const char *TOOL_AUTHOR  = "patrik@cqure.net";

#ifndef SOCKET_ERROR
#define SOCKET_ERROR -1
#endif

#ifndef INVALID_SOCKET
#define INVALID_SOCKET -1
#endif
