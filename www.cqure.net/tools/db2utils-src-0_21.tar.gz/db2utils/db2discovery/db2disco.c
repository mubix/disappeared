//
// (C) Copyright Patrik Karlsson cqure.net 2007-
//     patrik@cqure.net, http://www.cqure.net
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>

#define _strdup(s) strdup(s)
#define _strnicmp(s1, s2, n1) strncasecmp(s1, s2, n1)
#endif

#include "getopt.h"
#include "db2disco.h"
#include "db2common.h"

void banner();

void discover_hosts( char *p_srcip, char *p_dstip, int n_timeout ) {

	SOCKET s;
	int n_count;
	struct db2_host *p_hosts;

	banner();
	s = db2_send_discovery( p_srcip, p_dstip );
	
	if ( 1 > db2_recv_discovery( s, n_timeout, &p_hosts, &n_count ) ) {
		fprintf( stderr, "[w] no hosts discovered. wrong source ip?\r\n" );
	}
	else {
		n_count --; /* zero indexed array */
		for( ; n_count >= 0; n_count -- )
			printf("%s;%s;%s\n", p_hosts[n_count].ip, p_hosts[n_count].name, p_hosts[n_count].version );
	}

	free( p_hosts );
}

void banner() {

	int n_chars = -1;
	
	printf("\n");
	n_chars = printf( "%s %s by %s\n", TOOL_TITLE, TOOL_VERSION, TOOL_AUTHOR );
	for( ; n_chars>1; n_chars -- )
		printf( "-" );

	printf("\n");

}

void usage( char *p_prog ) {

	banner();
	printf("usage: %s [options] <ip>\n", p_prog );
	printf("\n");
	printf("Options:\n");
	printf("  -s <ip>  - source ip address\n" );
	printf("  -t <sec> - timeout in seconds\n" );
	
	
}

int main( int argc, char **argv ) {

	char *p_srcip = NULL, *p_dstip = NULL;
	int c = -1, n_timeout = -1, n_counter = 1;

#ifdef WIN32
	WSADATA wsa;

	WSAStartup( MAKEWORD( 2, 2 ), &wsa );
#endif

	while( 1 ) {
		c = getopt( argc, argv, "s:t:h" );

		if ( -1 == c )
			break;

		n_counter += 2;

		switch( c ) {

			case 's':
				p_srcip = _strdup( optarg );
				break;
			case 't':
				n_timeout = atoi( optarg );
				break;
			case 'h':
				usage( argv[0] );
				exit( -1 );
				break;
			default:
				usage( argv[0] );
				exit( -1 );	
				break;

		}
	
	}

	if ( 1 != argc - n_counter ) {
		usage(argv[0]);
		exit(-1);
	}

	p_dstip = _strdup( argv[ argc - 1 ] );
	discover_hosts( p_srcip, p_dstip, n_timeout );

#ifdef WIN32
	WSACleanup();
#endif

}
