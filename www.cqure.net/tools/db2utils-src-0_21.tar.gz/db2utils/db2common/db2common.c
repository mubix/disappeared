//
// (C) Copyright Patrik Karlsson cqure.net 2007-
//     patrik@cqure.net, http://www.cqure.net
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef WIN32
#include <winsock2.h>
#include <windows.h>
#define _CRT_SECURE_NO_DEPRECATE 1
#else
typedef int SOCKET;
#include <sys/socket.h>
#include <netinet/in.h>

#define _strdup(s) strdup(s)
#define _strnicmp(s1, s2, n1) strncasecmp(s1, s2, n1)
#endif

#ifndef SOCKET_ERROR
#define SOCKET_ERROR -1
#endif

#ifndef INVALID_SOCKET
#define INVALID_SOCKET -1
#endif

#include "db2_structs.h"

struct db2_host {
	char name[22];
	char version[9];
	char name2[22];
	char ip[16];
};

struct db2_host *process_response( unsigned char *p_buf, int n_len ) {

	struct db2_retaddr retaddr;
	struct db2_host *p_host;

	int n_offset = 0;

	if ( sizeof( struct db2_retaddr ) != n_len )
		return NULL;

	if ( NULL == ( p_host = (struct db2_host *) malloc( sizeof( struct db2_host ) ) ) )
		return NULL;

	memset( (char *)&retaddr, 0, sizeof( struct db2_retaddr ) );
	memcpy( &retaddr, p_buf, sizeof( retaddr ) );

	memset( p_host, 0, sizeof( struct db2_host ) );
	strncpy( p_host->name, retaddr.name, sizeof( p_host->name ) - 1 );
	strncpy( p_host->name2, retaddr.name2, sizeof( p_host->name2 ) - 1 );
	strncpy( p_host->version, retaddr.version, sizeof( p_host->version ) - 1 );
	
	return p_host;
}


int db2_recv_discovery( SOCKET s, int n_timeout, struct db2_host **pp_hosts, int *n_count ) {
	
	fd_set rset;
	struct timeval t_timeval;
	struct sockaddr_in sin_from;
	struct db2_host *p_hosts, *p_host;
	int n_fromlen, n_packetlen, n_clients = 0;
	
	char buf[1024];


	if ( NULL == ( p_hosts = malloc( sizeof( struct db2_host ) ) ) )
		return 0;

	while ( 1 ) {

		FD_ZERO( &rset );
		FD_SET( s, &rset );

		if ( n_timeout < 0 )
			t_timeval.tv_sec = 3;
		else
			t_timeval.tv_sec = n_timeout;

		t_timeval.tv_usec = 0;

#ifdef WIN32
		if ( 1 != select( 2, &rset, NULL, NULL, &t_timeval ) )
			break;
#else
		if ( 1 != select( s+1, &rset, NULL, NULL, &t_timeval ) )
			break;
#endif
		
		memset( buf, 0, sizeof( buf ) );
		n_fromlen = sizeof( sin_from );

		if ( -1 != ( n_packetlen = recvfrom( s, buf, sizeof( buf ) - 1, 0, (struct sockaddr *)&sin_from, &n_fromlen ) ) ) {
			if ( NULL != (p_host = process_response( buf, n_packetlen ) ) ) {

				strncpy( p_host->ip, (char *)inet_ntoa( sin_from.sin_addr ), sizeof( p_host->ip ) - 1 );
				
				if ( NULL == ( p_hosts = realloc( p_hosts, ( n_clients + 1 ) * sizeof( struct db2_host ) ) ) ) {
					return 0;
				}
				
				memcpy( p_hosts + n_clients, p_host, sizeof( struct db2_host ) );
				free( p_host );
			}
		}
		
		n_clients ++;
	}

	*n_count = n_clients;
	*pp_hosts = p_hosts;

	return *n_count;
}

SOCKET db2_send_discovery( char *p_srcip, char *p_dstip ) {

	SOCKET s;
	struct sockaddr_in sin, sin_server;
	struct db2_getaddr t_getaddr;

	int n_optval = 1, n_clients = 0;

	strcpy( t_getaddr.header, "DB2GETADDR" );
	strcpy( t_getaddr.version, "SQL09010" );
	
	if ( NULL == p_dstip )
		return -1;
	
	sin.sin_addr.s_addr = inet_addr( p_dstip );
	sin.sin_family = AF_INET;
	sin.sin_port = htons(523);

	/* Create our UDP socket */
	if ( INVALID_SOCKET == ( s = socket( AF_INET, SOCK_DGRAM, IPPROTO_UDP ) ) ) {
		perror( "socket");
		return -1;
	}

	/* we want broadcast support */
	if ( SOCKET_ERROR == ( setsockopt(s, SOL_SOCKET, SO_BROADCAST, (char *) &n_optval, sizeof(n_optval)) ) ) {
		perror( "setsockopt" );
		return -1;
	}

	/* If a specific src ip was set use it */
	if ( NULL != p_srcip )
		sin_server.sin_addr.s_addr = inet_addr( p_srcip );
	else
		sin_server.sin_addr.s_addr = INADDR_ANY;
	
	sin_server.sin_family = AF_INET;
	sin_server.sin_port = 0;

	if ( SOCKET_ERROR == bind( s, (struct sockaddr *)&sin_server, sizeof( sin_server ) ) ) {
		fprintf(stderr, "[e] Failed to bind to ip (%s)\n", p_srcip );
		return -1;
	}

	if ( sizeof( t_getaddr ) != sendto( s, (char *)&t_getaddr, sizeof( t_getaddr ), 0, 
										(const struct sockaddr *)&sin, sizeof( sin ) ) ) {
			fprintf(stderr, "[e] Discovery packet was not sent\n" );
			return -1;
	}

	
	return s;

}
