#ifndef _DB2_STRUCTS_H
#define _DB2_STRUCTS_H

#pragma pack(push, 1)

#ifndef WIN32
typedef unsigned long DWORD;
#endif

struct db2_getaddr {
	char header[11];//  = "DB2GETADDR";
	char version[9]; // = "SQL09010";
};

struct db2_retaddr {
	char header[11];
	char version[9];
	char name[22];
	char name2[22];
	char pad[234];
};

struct db2_packet_header {
	char foo[37];
	DWORD n_datalen;
};

struct db2_packet {
	struct db2_packet_header header;
	char *p_data;
};


#endif
