/*
 * Created on Dec 5, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package cqure.repeng;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.event.TreeSelectionListener;

import javax.swing.tree.TreeNode;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ReportViewerPanel extends JPanel implements TreeSelectionListener {

	private JTree m_oTree;
	private ReportTree m_oRepTree;
	private JEditorPane m_oPropPane;

	public void setReportTree( ReportTree oTree ) {
		m_oRepTree.getTreeModel().setRoot( (TreeNode) oTree.getTreeModel().getRoot() );
	}
	
	public ReportViewerPanel() {
		
		super(new GridLayout(1, 0));
		m_oRepTree = new ReportTree();
		m_oTree = new JTree(m_oRepTree);
		m_oTree.getSelectionModel().setSelectionMode(
			TreeSelectionModel.SINGLE_TREE_SELECTION);

		m_oTree.addTreeSelectionListener(this);
		m_oTree.setCellRenderer(new ReportTreeCellRenderer());

		JScrollPane treeView = new JScrollPane(m_oTree);

		m_oPropPane = new JEditorPane();
		m_oPropPane.setEditable(false);
		JScrollPane htmlView = new JScrollPane(m_oPropPane);

		JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		splitPane.setTopComponent(treeView);
		splitPane.setBottomComponent(htmlView);

		Dimension minimumSize = new Dimension(100, 50);
		htmlView.setMinimumSize(minimumSize);
		treeView.setMinimumSize(minimumSize);
		splitPane.setDividerLocation(300);
		splitPane.setPreferredSize(new Dimension(500, 500));

		add(splitPane);
	}

	public void valueChanged(TreeSelectionEvent e) {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) m_oTree.getLastSelectedPathComponent();

		String sTmp = "";
		ReportObject oRo = null;

		if (node == null)
			return;

		Object nodeInfo = node;

		if (nodeInfo instanceof ReportObject)
			oRo = (ReportObject) nodeInfo;

		if (oRo != null) {

			if (oRo.getValue() != null)
				sTmp = (String) oRo.getValue();
			else
				sTmp = oRo.getPropertiesAsString();

			m_oPropPane.setText(sTmp);

		}

	}

	protected static ImageIcon createImageIcon(String path) {
	
		java.net.URL imgURL = ReportViewerPanel.class.getResource(path);
		
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
	
}

	
