/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package cqure.repeng;

import java.io.*;
import java.beans.*;
import javax.swing.JTree;
import javax.swing.tree.*;

public class ExportTool {

 	public static ReportTree loadFromFile(String sName) {

		FileInputStream oFIS = null;
		ObjectInputStream oOIS = null;
		ReportTree oTree = null;

		try {
			oFIS = new FileInputStream(sName);
			oOIS = new ObjectInputStream(oFIS);

			oTree = (ReportTree) oOIS.readObject();
			oFIS.close();
			oOIS.close();
		} catch (Exception e) {
			System.err.println("[x] Failed to load report");
			e.printStackTrace();
		}

		return oTree;

	}

	public static void main(String[] args) {

		String sInfile = "oracle9i.rep";
		String sOutfile = "export.xml";
		JTree oTree = null;
		ReportTree oRepTree = null;
		
		XMLEncoder oEncoder = null;
		
		try {
			oEncoder = new XMLEncoder(new FileOutputStream(sOutfile));
		}
		catch(Exception e) {
			e.printStackTrace();	
		}
		
		oRepTree = loadFromFile(sInfile);
		oRepTree.setShowLinks(false);

		oTree = new JTree(oRepTree);
	
		TreeNode node = (TreeNode)oTree.getModel().getRoot();
		//expandAll( oTree, true );
		
		oEncoder.writeObject( node );
		oEncoder.close();
		//oTree.setShowLinks(false);

		//ExpHtml oHtml = new ExpHtml(oTree);
		//oHtml.export(sOutfile);
		

	}

}