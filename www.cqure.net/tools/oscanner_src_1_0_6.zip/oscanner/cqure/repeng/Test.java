/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package cqure.repeng;

public class Test {

	public Test() {

	}

	public static void main(String args[]) {

		ReportObject o = new ReportObject("test");
		ReportTree oTree = new ReportTree();

		oTree.setShowLinks(false);

		if (oTree.addReportItem(null, o)) {
			System.err.println("Addedd root node");
		}

		o = new ReportObject("abc");

		if (oTree.addReportItem("test", o)) {
			System.err.println("success");
		}

		o = new ReportObject("kalle");

		if (oTree.addReportItem("test", o)) {
			System.err.println("success");
		}

		o = new ReportObject("tove");
		o.setType(ReportObject.REPORT_LINK);

		if (oTree.addReportItem("test/abc", o)) {
			System.err.println("success");
		}

		o.setValue("t is the w");

		if (oTree.addReportItem("test/abc", o)) {
			System.err.println("success");
		}

		o = new ReportObject("aaa");
		o.setValue("p is the b");
		if (oTree.addReportItem("test/kalle", o)) {
			System.err.println("success");
		}

		o = new ReportObject("karin");
		o.setType(ReportObject.REPORT_LINK);
		o.setValue("test/kalle/aaa");

		if (oTree.addReportItem("test/abc", o)) {
			System.err.println("success");
		}

		o = new ReportObject("abc");

		if (oTree.addReportItem("test", o)) {
			System.err.println("success abc");
		}

		o = new ReportObject("vvv");

		if (oTree.addReportItem("test", o)) {
			System.err.println("success abc");
		}
		o = new ReportObject("bbb");

		if (oTree.addReportItem("test", o)) {
			System.err.println("success abc");
		}
		o = new ReportObject("sss");

		if (oTree.addReportItem("test", o)) {
			System.err.println("success abc");
		}

		oTree.storeToFile("tree.dat");

	}

}