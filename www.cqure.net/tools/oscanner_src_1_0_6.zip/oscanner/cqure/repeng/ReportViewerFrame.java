/*
 * Created on Dec 5, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package cqure.repeng;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ReportViewerFrame extends JFrame {
	
	private JMenuBar jMenuBar1;
	private JMenu jMenu1;
	private JMenuItem jMenuItem1;
	private ReportViewerPanel m_oPanel;
	
	public ReportViewerFrame() {
	
		this.setSize(333, 153);
		jMenuBar1 = new JMenuBar();
		setJMenuBar(jMenuBar1);
		jMenu1 = new JMenu();
		jMenuBar1.add(jMenu1);
		jMenu1.setText("File");
		jMenuItem1 = new JMenuItem();
		jMenu1.add(jMenuItem1);
		jMenuItem1.setText("Exit");
		//javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		this.addWindowListener(new WindowAdapter() {
		       public void windowClosing(WindowEvent e) {System.exit(0);}
		});

		jMenuItem1.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		m_oPanel = new ReportViewerPanel();
		this.getContentPane().add( m_oPanel );			
	}

	public void setReportTree( ReportTree oTree ) {
		m_oPanel.setReportTree( oTree );		
	}
	
}
