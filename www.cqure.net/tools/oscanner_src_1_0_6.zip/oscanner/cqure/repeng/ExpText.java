/*
 * Created on Dec 6, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package cqure.repeng;

import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ExpText {

	private static ReportTree m_oTree;
	
	public static void visitAllNodes() {
		TreeNode root = (TreeNode) m_oTree.getRoot();
		visitAllNodes(root);
	}

	public static void visitAllNodes(TreeNode node) {

		ReportObject oRo = null;
		Hashtable oH = null;
		Enumeration oE = null;
		String sKey;
		int nLevel;

		System.out.println("=>");
		
		if (node instanceof ReportObject) {
			oRo = (ReportObject) node;
			nLevel = ((DefaultMutableTreeNode) node).getLevel();

			System.out.print(oRo.toString() + ";");

			if (oRo.getPropertyCount() > 0) {
				oH = oRo.getProperties();

				for (oE = oH.keys(); oE.hasMoreElements();) {
					sKey = (String) oE.nextElement();

					if (oH.get(sKey) != null
							&& ((String) oH.get(sKey)).length() > 0) {
						System.out.print(sKey + ": " + oH.get(sKey) + ";");
					}
				}

			}
		}

		if (node.getChildCount() >= 0) {
			for (Enumeration e = node.children(); e.hasMoreElements();) {
				TreeNode n = (TreeNode) e.nextElement();
				visitAllNodes(n);
			}
		}

		System.out.println("");
	}

	
	
	public static void main(String[] args) {
		m_oTree = new ReportTree();
		
		m_oTree.loadFromFile( args[0] );
		visitAllNodes();
	}

}
