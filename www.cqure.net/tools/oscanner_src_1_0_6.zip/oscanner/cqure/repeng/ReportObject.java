/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package cqure.repeng;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.Hashtable;
import java.util.Enumeration;

public class ReportObject extends DefaultMutableTreeNode {

	private int m_nType = 0;

	private int m_nSeverity = 0;

	private String m_sName = null;

	private Object m_oValue = null;

	private Hashtable m_oProperties = new Hashtable();

	public static final int REPORT_ITEM = 1000;

	public static final int REPORT_PROPERTY = 1001;

	public static final int REPORT_LINK = 1002;

	public static final int SEVERITY_LEVEL_INFO = 2000;

	public static final int SEVERITY_LEVEL_WARNING = 2001;

	public static final int SEVERITY_LEVEL_CRITICAL = 2002;

	public ReportObject() {
	}

	public ReportObject(String sName) {
		m_sName = sName;
	}

	public ReportObject(String sName, Object oVal) {
		m_sName = sName;
		m_oValue = oVal;
	}

	public void setName(String s) {
		m_sName = s;
	}

	public void setType(int t) {
		m_nType = t;
	}

	public void setSeverity(int nLevel) {
		m_nSeverity = nLevel;
	}

	public void setValue(String s) {
		m_oValue = s;
	}

	public void addProperty(String sName, String sValue) {

		if (sValue == null)
			sValue = "";

		if (sName != null && sName.length() > 0)
			m_oProperties.put(sName, sValue);
	}

	public String getPropertiesAsString() {
		String sTmp = "";
		String sKey = "";

		for (Enumeration oE = m_oProperties.keys(); oE.hasMoreElements();) {
			sKey = (String) oE.nextElement();

			if (m_oProperties.get(sKey) != null
					&& ((String) m_oProperties.get(sKey)).length() > 0) {
				sTmp += sKey + ": " + m_oProperties.get(sKey) + "\n";
			}
		}

		return sTmp;
	}

	public Hashtable getProperties() {
		return m_oProperties;
	}

	public void setProperties(Hashtable h) {
		m_oProperties = h;
	}
	
	public Object getProperty(String s) {
		return m_oProperties.get(s);
	}

	public int getPropertyCount() {
		return m_oProperties.size();
	}

	public Object getValue() {
		return m_oValue;
	}

	public int getSeverity() {
		return m_nSeverity;
	}

	public int getType() {
		return m_nType;
	}

	public String toString() {
		return m_sName;
	}

	public String getName() {
		return m_sName;
	}

}