/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package cqure.repeng;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;

public class ReportTreeCellRenderer extends JLabel implements TreeCellRenderer {

	private static final String ICON_PATH = "cqure/repeng/icons/";

	private ImageIcon m_oCriticalIcon = null;

	private ImageIcon m_oWarningIcon = null;

	private ImageIcon m_oInfoIcon = null;

	public ReportTreeCellRenderer() {
		setOpaque(false);
		setBackground(null);

		m_oCriticalIcon = createImageIcon(ICON_PATH + "critical.gif");
		m_oWarningIcon = createImageIcon(ICON_PATH + "warning.gif");
		m_oInfoIcon = createImageIcon(ICON_PATH + "info.gif");
	}

	protected static ImageIcon createImageIcon(String path) {
		//java.net.URL imgURL = ReportViewer.class.getResource(path);
		if (path != null) {
			return new ImageIcon(path);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}

	public Component getTreeCellRendererComponent(JTree tree, Object value,
			boolean sel, boolean expanded, boolean leaf, int row,
			boolean hasFocus) {

		ReportObject oRo;

		setFont(tree.getFont());
		String stringValue = tree.convertValueToText(value, sel, expanded,
				leaf, row, hasFocus);

		setEnabled(tree.isEnabled());
		setText(stringValue);

		if (sel)
			setForeground(Color.blue);
		else
			setForeground(Color.black);
		if (leaf) {
			setIcon(UIManager.getIcon("Tree.leafIcon"));
		} else if (expanded) {
			setIcon(UIManager.getIcon("Tree.openIcon"));
		} else {
			setIcon(UIManager.getIcon("Tree.closedIcon"));
		}

		if (value instanceof ReportObject) {
			oRo = (ReportObject) value;
			if (oRo.getSeverity() == ReportObject.SEVERITY_LEVEL_CRITICAL)
				setIcon(m_oCriticalIcon);
			else if (oRo.getSeverity() == ReportObject.SEVERITY_LEVEL_WARNING)
				setIcon(m_oWarningIcon);
			else
				setIcon(m_oInfoIcon);
		}

		return this;

	}

}