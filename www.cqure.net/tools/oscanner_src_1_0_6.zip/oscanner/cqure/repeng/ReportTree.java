/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package cqure.repeng;

import javax.swing.tree.*;

import java.io.*;
import java.util.*;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;

public class ReportTree extends DefaultTreeModel implements Serializable {

	private boolean m_bShowLinks = true;

	private boolean m_bSorted = true;

	public ReportTree() {
		/* Add the root object */
		super(new DefaultMutableTreeNode("root"));
	}

	public void setShowLinks(boolean b) {
		m_bShowLinks = b;
	}

	public void setSorted(boolean b) {
		m_bSorted = b;
	}

	public TreePath find(TreePath oParent, Object[] oNodes, int nDepth) {

		TreeNode oNode = (TreeNode) oParent.getLastPathComponent();
		String s = oNode.toString();

		if (s.equalsIgnoreCase((String) oNodes[nDepth])) {

			if (nDepth == oNodes.length - 1) {
				return oParent;
			}

			if (oNode.getChildCount() >= 0) {

				for (Enumeration e = oNode.children(); e.hasMoreElements();) {

					TreeNode oN = (TreeNode) e.nextElement();
					TreePath oPath = oParent.pathByAddingChild(oN);
					TreePath oResult = find(oPath, oNodes, nDepth + 1);
					// Found a match
					if (oResult != null) {
						return oResult;
					}

				}

			}

		}

		return null;

	}

	private TreePath findItemByName(Object[] sPath) {

		TreeNode oNode = (TreeNode) this.getRoot();
		return find(new TreePath(oNode), sPath, 0);

	}

	private Object[] createSearchArray(String sPath) {

		StringTokenizer oTokenizer;
		Vector oV = new Vector();
		String s;

		if (sPath != null)
			sPath = "root/" + sPath;

		if (sPath != null && sPath.length() > 0) {
			oTokenizer = new StringTokenizer(sPath, "/");
			while (oTokenizer.hasMoreTokens()) {
				s = (String) oTokenizer.nextElement();
				oV.add(s);
			}

		} else
			return null;

		return oV.toArray();

	}

	public ReportObject findReportItem(String sPath) {

		Object[] oSrchArray = null;
		TreePath oPath = null;

		if ( sPath == null )
			return null;
		
		oSrchArray = createSearchArray(sPath);
		oPath = findItemByName(oSrchArray);

		if (oPath == null)
			return null;

		return (ReportObject) oPath.getLastPathComponent();

	}

	/* If an item already exists it is overwritten with the new values */
	public boolean addReportItem(String sPath, ReportObject o) {

		DefaultMutableTreeNode oNode;
		DefaultMutableTreeNode oNewNode;
		TreePath oPath;
		Object[] oSrchArray = null;
		ReportObject o1, o2;

		if (o == null)
			return false;

		/* First check if we already have an object by that name */
		/* Create a search array */
		oSrchArray = createSearchArray(sPath + "/" + o.toString());

		if (oSrchArray != null) {

			/* Does the Item exist ? */
			if ((oPath = findItemByName(oSrchArray)) != null) {
				//removeNodeFromParent( (DefaultMutableTreeNode)
				//	      oPath.getLastPathComponent() );
				oPath = new TreePath(o.getRoot());
				return true;
			}
			if (sPath != null && sPath.length() > 0) {
				/* do we have a valid path ? */
				oSrchArray = createSearchArray(sPath);
				oPath = findItemByName(oSrchArray);
			} else {
				/*
				 * The object was not found and we do not have a valid path get
				 * us the root object
				 */
				oPath = new TreePath((TreeNode) this.getRoot());
			}
		} else {
			/*
			 * The search array could not be created get us the root object
			 */
			oPath = new TreePath((TreeNode) this.getRoot());
		}

		/* Did we retrieve a valid path ? */
		if (oPath != null) {
			oNode = (DefaultMutableTreeNode) oPath.getLastPathComponent();
			oNewNode = o;

			if (m_bSorted && oNode.getChildCount() > 0) {
				for (int i = 0; i < oNode.getChildCount(); i++) {
					o1 = (ReportObject) oNode.getChildAt(i);
					//System.err.println("o1.toString()=" + o1.toString() );
					//System.err.println("o.toString()=" + o.toString() );
					//System.err.println("Compare returned: " +
					//		       o.toString().compareTo( o1.toString()));
					if (o.toString().compareTo(o1.toString()) < 0) {
						//System.err.println("Adding node..");
						insertNodeInto(oNewNode, oNode, i);
						return true;
					}
					//System.err.println("Retrying...");
				}
				insertNodeInto(oNewNode, oNode, oNode.getChildCount());
			} else
				insertNodeInto(oNewNode, oNode, oNode.getChildCount());

			return true;
		}

		return false;

	}

	public boolean storeToFile(String sName) {

		try {
			FileOutputStream oF = new FileOutputStream(sName);
			XMLEncoder oEncoder = new XMLEncoder( oF );
			oEncoder.writeObject( this.getRoot() );
			oEncoder.close();

			return true;
		} catch (IOException e) {
			System.err.println("[x] Failed to write report file");
			System.err.println("[x] " + e.getMessage());
		}

		return false;

	}

	public boolean loadFromFile(String sName) {

		FileInputStream oFIS = null;
		XMLDecoder oDecoder = null;
		DefaultMutableTreeNode oNode = null;
		
		try {
			oFIS = new FileInputStream(sName);
			oDecoder = new XMLDecoder( oFIS );

			oNode = (DefaultMutableTreeNode)oDecoder.readObject();
			this.getTreeModel().setRoot( oNode );
			
			oDecoder.close();
			oFIS.close();
		} 
		catch (Exception e) {
			System.err.println("[x] Failed to load report");
			e.printStackTrace();
			
			return false;
		}

		return true;	
	}

	
	public DefaultTreeModel getTreeModel() {
		return this;
	}

	public int getChildCount(Object parent) {
		int nCount = super.getChildCount(parent);
		Object o = null;
		ReportObject oRo = null;
		int i, nTmp;

		if (nCount > 0) {
			nTmp = nCount;
			for (i = 0; i < nTmp; i++) {
				/* Get the child without checking for link mumbojumbo */
				o = super.getChild(parent, i);

				/* Is this a ReportObject */
				if (o instanceof ReportObject) {
					oRo = (ReportObject) o;
					/*
					 * if this is a link and followlinks is not set decrease
					 * object count by 1
					 */
					if (oRo.getType() == ReportObject.REPORT_LINK
							&& !m_bShowLinks)
						nCount--;
				}
			}
		}

		return nCount;
	}

	public boolean isLeaf(Object oNode) {
		if (getChildCount(oNode) > 0)
			return false;

		return true;
	}

	public Object getChild(Object parent, int index) {
		Object o = super.getChild(parent, index);

		if (o instanceof ReportObject) {
			ReportObject oRo = (ReportObject) o;
			ReportObject oLink = null;

			if (oRo.getType() == ReportObject.REPORT_LINK) {
				oLink = findReportItem((String) oRo.getValue());

				if (oLink == null) {
					oLink = oRo;
					oLink.setValue("!! THIS IS A BROKEN LINK !!");
				}

				/*
				 * This is a link and if we should follow it return the linked
				 * object. If m_bShowLinks is false return null
				 */

				if (m_bShowLinks)
					return (Object) oLink;
				else
					return null;

			}

		}

		return o;
	}

}