/*
 * Created on Dec 5, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package cqure.repeng;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.beans.XMLDecoder;
import java.io.FileInputStream;

import javax.swing.tree.DefaultMutableTreeNode;

public class ReportViewer {

	public static ReportTree loadFromFile(String sName) {

		FileInputStream oFIS = null;
		XMLDecoder oDecoder = null;
		ReportTree oTree = null;
		DefaultMutableTreeNode oNode = null;
		
		try {
			oFIS = new FileInputStream(sName);
			oDecoder = new XMLDecoder( oFIS );
			oTree = new ReportTree();

			oNode = (DefaultMutableTreeNode)oDecoder.readObject();
			oTree.getTreeModel().setRoot( oNode );
			
			oDecoder.close();
			oFIS.close();
		} 
		catch (Exception e) {
			System.err.println("[x] Failed to load report");
			e.printStackTrace();
		}

		return oTree;	
	}
	
	public static void main(String[] args) {

		DefaultMutableTreeNode oNode = null;
		ReportViewerPanel oPanel = null;
		
		if (args.length < 1) {
			System.err.println("Reportviewer v.0.0.1 by patrik@cqure.net");
			System.err.println("----------------------------------------");
			System.err.println("Reportviewer [filename]");
			System.exit(1);
		}

		ReportViewerFrame oFrm = new ReportViewerFrame();
		ReportTree oTree = loadFromFile( args[0] );
		
		oFrm.setReportTree( oTree );
		oFrm.pack();
		oFrm.setVisible(true);

	}
}
