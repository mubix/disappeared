/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package cqure.repeng;

import javax.swing.tree.*;
import java.util.Enumeration;
import java.util.Hashtable;

public class ExpHtml {

	private ReportTree m_oTree;

	public ExpHtml(ReportTree oTree) {
		m_oTree = oTree;
	}

	public void setTree(ReportTree oTree) {
		m_oTree = oTree;
	}

	public void doTab(int nCount) {
		for (int i = 0; i < nCount; i++) {
			System.out.print("&nbsp;");
		}
	}

	private void htmlMarkupLevelStart(int nLevel) {
		int nSize = 6 - nLevel;

		if (nSize < 1)
			nSize = 1;

		//doTab( nLevel * 10 );
		System.out.print("<font size=\"" + nSize + "\">");
	}

	private void htmlMarkupLevelEnd() {
		System.out.println("</font><br>");
	}

	public void visitAllNodes() {
		TreeNode root = (TreeNode) m_oTree.getRoot();
		visitAllNodes(root);
	}

	public void visitAllNodes(TreeNode node) {

		ReportObject oRo = null;
		Hashtable oH = null;
		Enumeration oE = null;
		String sKey;
		int nLevel;

		if (node instanceof ReportObject) {
			oRo = (ReportObject) node;
			nLevel = ((DefaultMutableTreeNode) node).getLevel();

			htmlMarkupLevelStart(nLevel);
			System.out.print(oRo.toString());
			htmlMarkupLevelEnd();

			if (oRo.getPropertyCount() > 0) {
				oH = oRo.getProperties();

				System.out.println("<ul>");
				for (oE = oH.keys(); oE.hasMoreElements();) {
					sKey = (String) oE.nextElement();

					if (oH.get(sKey) != null
							&& ((String) oH.get(sKey)).length() > 0) {
						System.out.print("<li>" + sKey + ": " + oH.get(sKey)
								+ "</li>");
					}
				}
				System.out.println("</ul>");

			}
		}

		if (node.getChildCount() >= 0) {
			for (Enumeration e = node.children(); e.hasMoreElements();) {
				TreeNode n = (TreeNode) e.nextElement();
				visitAllNodes(n);
			}
		}
	}

	/* Retrieve Header of HTML page from template file */
	public void createHeader(String sFile) {
		/* FIXME: Implement this */
	}

	/* Retrieve Footer of HTML page from template file */
	public void createFooter(String sFile) {
		/* FIXME: Implement this */
	}

	public void createHeader() {
		System.out.println("<html>");
		System.out.println("    <body>");
	}

	public void createFooter() {
		System.out.println("    </body>");
		System.out.println("</html>");
	}

	public boolean export(String sFile) {

		createHeader();
		visitAllNodes();
		createFooter();

		return true;
	}

}