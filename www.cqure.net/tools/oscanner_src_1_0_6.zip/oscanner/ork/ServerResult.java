/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.util.*;

public class ServerResult {

	private String m_sServer = null;

	private int m_nPort = -1;

	private AccountList m_oAccountList = new AccountList();

	private Vector m_oProperty = new Vector();

	private Logger m_oLogger = new Logger();

	private SIDList m_oSIDList = null;

	private PluginReportList m_oPluginReportList = new PluginReportList();

	public ServerResult(String sServer, int nPort) {
		m_sServer = sServer;
		m_nPort = nPort;
	}

	public String getServer() {
		return m_sServer;
	}

	public int getPort() {
		return m_nPort;
	}

	public void setSIDList(SIDList o) {
		m_oSIDList = o;
	}

	public PluginReportList getPluginReportList() {
		return m_oPluginReportList;
	}

	public synchronized SIDList getSIDList() {
		SIDList oList = new SIDList();

		if (m_oSIDList == null) {
			System.err.println("[x] SIDs have not been retrieved");
			return oList;
		}

		oList = (SIDList) m_oSIDList.clone();
		oList.reset();
		return oList;
	}

	public synchronized void addAccount(String sSID, String sUser,
			String sPass, String sHash, int nState) {

		if (m_sServer == null)
			System.err.println("[x] addAccount: Missing servername ...");

		m_oAccountList.addAccountForSID(sSID, new Account(sUser, sPass, null,
				nState));

	}

	public AccountList getAccountList() {
		return m_oAccountList;
	}

	public synchronized void addProperty(String sName, String sValue) {

		Hashtable oProp = new Hashtable();

		oProp.put(sName, sValue);
		m_oProperty.add(oProp);

	}

	public void outputAsText() {

		Vector oVector = null;
		String sSID = null;
		Account oAcc;

		m_oLogger.log("Accounts");
		m_oLogger.log("========");
		m_oLogger.log("");

		m_oSIDList.reset();

		while ((sSID = m_oSIDList.getNextSID()) != null) {

			oVector = m_oAccountList.getAccountsForSID(sSID);

			if (oVector != null) {

				m_oLogger.log("SID " + sSID);
				m_oLogger.log("===========================================");

				for (int i = 0; i < oVector.size(); i++) {
					oAcc = (Account) oVector.get(i);

					if (oAcc.getState() != Account.ACCOUNT_STATUS_UNKNOWN)
						m_oLogger.log(oAcc.getAsString());
				}

			}

		}

		m_oLogger.log(m_oProperty.toString());

	}

}