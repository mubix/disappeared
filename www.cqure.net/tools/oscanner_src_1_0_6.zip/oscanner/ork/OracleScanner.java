/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.beans.XMLDecoder;
import java.lang.reflect.Constructor;
import java.sql.*;
import java.io.*;
import gnu.getopt.*;
import ork.plugins.*;
import cqure.repeng.*;


public class OracleScanner {

	static Connection m_oConn = null;

	private static String m_sConnURL = null;
	private static Logger oLogger = new Logger();
	private static OracleDBConnection oOraDBConn = new OracleDBConnection();
	private static String m_sVersion = "1.0.6";
	private static String m_sAuthor = "patrik@cqure.net";

	//private static String m_sRepFile = null;

	/*
	 * Some usage info
	 */
	public static void usage() {

		System.out.println("\tOracle Scanner " + m_sVersion + " by "
				+ m_sAuthor);
		System.out.println("\t--------------------------------------");
		System.out.println("\tOracleScanner -s <ip> -r <repfile> [options]");
		System.out.println("\t\t-s\t<servername>");
		System.out.println("\t\t-f\t<serverlist>");
		System.out.println("\t\t-P\t<portnr>");
		System.out.println("\t\t-v\tbe verbose");
//		System.out.println("\t\t-r\t<reportfile>");
		System.out.println("");

	}

	public static ScannerConfig loadScannerConfig(String s) {

		FileInputStream oFIS = null;
		XMLDecoder oDecoder = null;
		ScannerConfig oConf = null;
		
		try {
			oFIS = new FileInputStream(s);
			oDecoder = new XMLDecoder( oFIS );

			oConf = (ScannerConfig)oDecoder.readObject();
			
			oDecoder.close();
			oFIS.close();
		} 
		catch (Exception e) {
			System.err.println("[x] Failed to load report");
			e.printStackTrace();
			
			return null;
		}

		return oConf;

	}

	/*
	 * Main function
	 */
	public static void main(String args[]) {

		String sHostName = null;
		String sLocalIP = null;
		String sRepFile = null;
		
		int nOraclePort = 1521;
		Getopt oOpt = new Getopt("OracleScanner", args, "s:f:P:v"); //r:");
		int c, nErr;
		String arg;

		PluginList oPlugList = null;
		ServerList oSrvList = new ServerList();
		ScannerConfig oConfig = null;
		SIDList oSIDList = null;
		String sSID, sTmp;
		String sConfigFile = "default.conf";
		ReportTree oTree = new ReportTree();

		/* parse arguments */
		while ((c = oOpt.getopt()) != -1) {

			switch (c) {

			/*
			case 'r':
				arg = oOpt.getOptarg();
				m_sRepFile = arg;
				break;
			*/
			case 's':
				arg = oOpt.getOptarg();
				oSrvList.addServer(arg);
				break;

			case 'P':
				arg = oOpt.getOptarg();
				nOraclePort = Integer.parseInt(arg);
				oOraDBConn.setPort(nOraclePort);
				break;

			case 'v':
				oLogger.setLogLevel(Logger.LOG_DEBUG);
				break;

			case 'o':
				arg = oOpt.getOptarg();

				if (oLogger.setLogFile(arg) != Logger.OK) {
					System.err.println("[x] Failed to create logger");
					System.exit(0);
				}

				break;

			case 'f':
				arg = oOpt.getOptarg();

				if (oSrvList.loadServerList(arg) != ServerList.OK) {
					System.err.println("[x] failed to open serverlist");
					System.exit(0);
				}

				break;

			default:
				usage();
				System.exit(0);
			}

		}

		/* do we have all the parameters needed */
		if ( oSrvList.getServerCount() == 0 || nOraclePort == -1 ) {
			usage();
			System.exit(0);
		}

		oConfig = new ScannerConfig();

		if ((oConfig = loadScannerConfig(sConfigFile)) == null) {
			System.err.println("[x] Failed to load configfile: " + sConfigFile);
			System.exit(0);
		}

		if ((sTmp = oConfig.getConfigOption("oracleplugins")) == null) {
			System.err.println("[x] Failed to load Oracle pluginlist from"
					+ " file " + sTmp);
			System.exit(0);
		}

		oPlugList = new PluginList();
		if (oPlugList.loadFromFile(oConfig.getConfigOption("oracleplugins")) != FileListLoader.OK) {
			System.err.println("[x] Failed to open plugin list: "
					+ oConfig.getConfigOption("oracleplugins"));
			System.exit(1);
		}

		oLogger.log("Oracle Scanner " + m_sVersion + " by " + m_sAuthor);
		oLogger.log("--------------------------------------------------");

		while ((sHostName = oSrvList.getNextServer()) != null) {

			oLogger.log("[-] Checking host " + sHostName);

			oOraDBConn.setHost(sHostName);
			oTree.addReportItem(null, new ReportObject(sHostName));

			ServerResult oRes = new ServerResult(sHostName, nOraclePort);
			CommonValuesDB oCommDB = new CommonValuesDB();
			Object plug = null;

			oRes.setSIDList(oSIDList);

			for (int i = 0; i < oPlugList.size(); i++) {

				try {
					Class cl = Class.forName((String) oPlugList.get(i));
					Constructor oCt = cl
							.getConstructor(new Class[] { ServerResult.class });

					plug = oCt.newInstance(new Object[] { oRes });

					((PluginIface) plug).setLogger(oLogger);
					((PluginIface) plug).setConfig(oConfig);
					((PluginIface) plug).setCommonValuesDB(oCommDB);
					((PluginIface) plug).setReportTree(oTree);

					if (((PluginIface) plug).scan() != PluginIface.PLUGIN_SUCCESS) {
						oLogger.log("Plugin " + (String) oPlugList.get(i)
								+ " failed");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

			sRepFile = "oscanner_" + sHostName.replace('.','_') + "_report.xml";
			oTree.storeToFile(sRepFile);
			
			oTree = null;
			oTree = new ReportTree();

			/*
			oLogger.log("[i] Starting Report GUI ...");
			
			ReportViewerFrame oFrm = new ReportViewerFrame();
			
			oFrm.setReportTree( oTree );
			oFrm.pack();
			oFrm.setVisible(true);
			*/
			
		} /* End server file loop */

	}
}