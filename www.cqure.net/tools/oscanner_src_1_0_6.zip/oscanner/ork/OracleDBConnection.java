/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.sql.*;

public class OracleDBConnection {

	private String m_sSid = null;

	private String m_sUser = null;

	private String m_sPass = null;

	private String m_sHost = null;

	private Connection m_oConn = null;

	private int m_nPort = 1521; /* Default Oracle Port */

	/*
	 * Error messages go under here
	 *  
	 */
	public static final int ERROR_NO_HOST = -1000;

	public static final int ERROR_CONNECTION_FAILED = -1001;

	public static final int ERROR_LOGIN_FAILED = 1017;

	public static final int ERROR_ACCOUNT_LOCKED = 28000;

	/* This occures when trying to connect against unavailable sid */
	public static final int ERROR_IO_EXCEPTION = 17002;

	/*
	 * The username and password match but the account requires connection as
	 * sysdba or sysoper
	 */
	public static final int ERROR_CONNECT_AS_SYSDBA = 28009;

	public static final int OK = 0;

	public Connection getConnection() {
		return m_oConn;
	}

	public OracleDBConnection() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.err.println("[x] Failed to load Oracle JDBC driver");
			try {
				throw e.getException();
			} catch (Throwable ex) {
				System.err.println("[x] Uncaught exception in "
						+ "OracleDBConnection constructor");
			}
		}

	}

	public OracleDBConnection(String sServer, int nPort, String sSID) {
		this();
		setHost(sServer);
		setSID(sSID);
		setPort(nPort);
	}

	public OracleDBConnection(OracleDBConnection oConn) {
		this();
		setSID(oConn.getSid());
		setUser(oConn.getUser());
		setPassword(oConn.getPassword());
		setHost(oConn.getHost());
		setPort(oConn.getPort());
	}

	public void setSID(String sSid) {
		m_sSid = sSid;
	}

	public void setUser(String sUser) {
		m_sUser = sUser;
	}

	public void setPassword(String sPass) {
		m_sPass = sPass;
	}

	public void setHost(String sHost) {
		m_sHost = sHost;
	}

	public void setPort(int nPort) {
		m_nPort = nPort;
	}

	public String getSid() {
		return m_sSid;
	}

	public String getUser() {
		return m_sUser;
	}

	public String getPassword() {
		return m_sPass;
	}

	public String getHost() {
		return m_sHost;
	}

	public int getPort() {
		return m_nPort;
	}

	public int login() {

		String sUrl = null;
		int nErr = OK;

		if (m_sSid == null)
			System.err.println("[x] Warning SID not set!!");

		if (m_sUser == null)
			System.err.println("[x] Warning User not set!!");

		if (m_sPass == null)
			System.err.println("[x] Warning Password not set!!");

		if (m_sHost == null) {
			System.err.println("[x] Host has not been set!!");
			return ERROR_NO_HOST;
		}

		sUrl = "jdbc:oracle:thin:@" + m_sHost + ":" + m_nPort + ":" + m_sSid;

		try {
			m_oConn = DriverManager.getConnection(sUrl, m_sUser, m_sPass);
		} catch (SQLException e) {
			/*
			 * System.err.println("[x] Connection failed (error " +
			 * e.getErrorCode() + ")");
			 */

			/*
			 * This is known to happen when the SID does not exist on newer JDBC
			 * drivers. Why should the drivers behave the same when they can
			 * behave different and fuck things up. This was most probably a
			 * security feauture to make it more unbreakable :)
			 */
			if (e.getErrorCode() == 0) {
				return ERROR_IO_EXCEPTION;
			} else if (e.getErrorCode() == ERROR_ACCOUNT_LOCKED)
				nErr = ERROR_ACCOUNT_LOCKED;
			else if (e.getErrorCode() == ERROR_CONNECT_AS_SYSDBA) {
				m_sUser += " AS SYSDBA";
				return login();
			} else
				nErr = e.getErrorCode();
		}

		return nErr;

	}

	public void close() {

		try {
			if (m_oConn != null && !m_oConn.isClosed())
				m_oConn.close();
		} catch (SQLException e) {

		}

	}

}