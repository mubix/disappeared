/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * If SID enumeration fails the SIDs are loaded from a file (services.txt)
 * 
 * CHANGES: 
 * 	20041128 - Check if SIDS loaded from file are valid before adding them to the SID list 
 *				
 */

package ork.plugins;

import ork.*;
import cqure.repeng.*;

public class EnumerateSids implements PluginIface {

	private CommonValuesDB m_oDB;

	private OracleDBConnection m_oOraDBConn;

	private ServerResult m_oRes = null;

	private Logger m_oLogger = new Logger();

	private ScannerConfig m_oConfig = null;

	private ReportTree m_oTree = null;

	private String m_sServer = null;

	private String m_sSID = null;

	private int m_nPort = -1;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public EnumerateSids(ServerResult oRes) {
		m_oRes = oRes;
		m_sServer = oRes.getServer();
		m_nPort = oRes.getPort();
	}

	public int scan() {

		SIDList oList = new SIDList(m_sServer, m_nPort);
		FileListLoader oF = null;
		String sSID;
		OracleDBConnection oConn = null;

		if (oList.retrieveSids() != SIDList.OK)
			m_oLogger.log("[x] Failed to enumerate sids from host");

		if (oList == null || oList.size() == 0) {

			m_oLogger.log("[-] Loading services/sids from service file");
			oF = new FileListLoader();
			oF.loadFromFile(m_oConfig.getConfigOption("ServiceFile"));

			for (int i = 0; i < oF.size(); i++) {
		
				/*
				 *  Check if SIDS are valid by authenticating with any account
				 *  and check for ORA-1017
				 */
				 
				oConn = new OracleDBConnection(m_sServer, m_nPort, (String)oF.get(i));
				
				oConn.setUser("oscanner_test");
				oConn.setPassword("oscanner_test");
				
				if ( oConn.login() == 1017) {
					m_oLogger.debug("[i] Adding SID " + (String) oF.get(i) );
					oList.add(oF.get(i));
				}
				else {
					m_oLogger.debug( "[x] Removing SID " + (String)oF.get(i) );
				}
			}

		}
		
		m_oRes.setSIDList(oList);

		/* Add sids to report */
		oList.reset();

		while ((sSID = oList.getNextSID()) != null) {
			if (sSID.toLowerCase().indexOf("extproc") == -1)
				if (!m_oTree.addReportItem(m_sServer, new ReportObject(sSID)))
					m_oLogger.log("[x] addReportItem failed");
		}

		return PLUGIN_SUCCESS;

	}

}