/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.sql.*;
import cqure.repeng.*;

public class CheckOracleVersion implements PluginIface {

	private CommonValuesDB m_oDB;

	private OracleDBConnection m_oOraDBConn;

	private ServerResult m_oRes = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private int m_nPort = -1;

	private SIDList m_oSIDList = null;

	private PluginHelper m_oPlugHelp;

	private ScannerConfig m_oConfig = null;

	private ReportTree m_oTree = null;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public CheckOracleVersion(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
		m_oPlugHelp = new PluginHelper(oRes);
	}

	public int scan() {

		Connection oConn = null;
		String sSQL = "SELECT * FROM v$version";
		Statement oStmt = null;
		ResultSet oRs = null;
		String sVersion = "";

		if ((oConn = m_oPlugHelp.getAnyConnection()) == null)
			return PLUGIN_FAILURE;

		m_oLogger.log("[-] Querying database for version information");

		try {
			oStmt = oConn.createStatement();
			oRs = oStmt.executeQuery(sSQL);

			while (oRs != null && oRs.next()) {
				sVersion += oRs.getString("banner") + "\n";
			}

			if (oRs != null)
				oRs.close();

			if (oStmt != null)
				oStmt.close();

			oConn.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return PLUGIN_FAILURE;
		}

		/*
		 * FIXME PluginReport oRep = new PluginReport( "Oracle Version",
		 * sVersion ); m_oRes.getPluginReportList().add( oRep );
		 */

		/*
		 * ReportObject oRo = new ReportObject("Version", sVersion);
		 * 
		 * if ( !m_oTree.addReportItem( m_sServer, oRo ) ) m_oLogger.log("[x]
		 * CheckOracleVersion addReportItem failed");
		 *  
		 */

		ReportObject oRo = m_oTree.findReportItem(m_sServer);

		if (oRo != null)
			oRo.addProperty("Version", sVersion);

		return PLUGIN_SUCCESS;
	}

}