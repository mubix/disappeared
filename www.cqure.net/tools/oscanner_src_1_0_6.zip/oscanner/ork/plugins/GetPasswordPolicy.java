/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.sql.*;
import cqure.repeng.*;

public class GetPasswordPolicy implements PluginIface {

	private CommonValuesDB m_oDB;

	private ServerResult m_oRes = null;

	private ScannerConfig m_oConfig = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private String m_sSID = null;

	private int m_nPort = -1;

	private ReportTree m_oTree = null;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public GetPasswordPolicy(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
	}

	private void addPolicy(String sPolname, String sSID, String sInfo) {

		PluginReport oRep = null;

		if (sInfo.length() > 0) {
			oRep = new PluginReport();
			oRep.setHeader("Password policy \"" + sPolname + "\"");
			oRep.setSID(sSID);
			oRep.setHost(m_sServer);
			oRep.setBody(sInfo);
			m_oRes.getPluginReportList().add(oRep);

			if (!m_oTree.addReportItem(m_sServer + "/" + sSID + "/"
					+ "Password Policies", new ReportObject(sPolname, sInfo)))
				m_oLogger.log("[x] Failed to add password policy to report");
		}

	}

	public int scan() {

		SIDList oSIDList = m_oRes.getSIDList();
		Connection oConn = null;
		Statement oStmt = null;
		ResultSet oRs = null;
		PluginHelper oHelper = new PluginHelper(m_oRes, m_oLogger, m_oTree);
		String sSID, sPwPol = "";
		String sSQL = "SELECT profile,resource_name,limit "
				+ "FROM dba_profiles WHERE resource_type='PASSWORD' "
				+ "ORDER BY profile";

		String sTmp = "";

		if (oSIDList.size() < 1) {
			return PLUGIN_FAILURE;
		}

		while ((sSID = oSIDList.getNextSID()) != null) {

			m_oTree.addReportItem(m_sServer + "/" + sSID, new ReportObject(
					"Password Policies"));

			sPwPol = "";

			oConn = oHelper.getConnectionWithRole(sSID, "DBA");

			/* if no DBA accounts where found for this particular sid */
			if (oConn == null)
				continue;

			try {
				oStmt = oConn.createStatement();
				oRs = oStmt.executeQuery(sSQL);

				while (oRs != null && oRs.next()) {

					if (!sTmp.equals(oRs.getString("profile"))
							&& sPwPol.length() > 0) {
						addPolicy(sTmp, sSID, sPwPol);
						sPwPol = "";
					}

					sPwPol += oRs.getString("resource_name") + " is ";
					sPwPol += oRs.getString("limit") + "\r\n";
					sTmp = oRs.getString("profile");
				}

				addPolicy(sTmp, sSID, sPwPol);

				if (oRs != null)
					oRs.close();

				if (oStmt != null)
					oStmt.close();

			} catch (SQLException e) {
				m_oLogger.log("[x] Failed to retrieve password policy");
				e.printStackTrace();
				return PLUGIN_FAILURE;
			}

		}

		try {
			if (oConn != null)
				oConn.close();

		} catch (SQLException e) {
			m_oLogger.debug("[x] Failed to close database connection");
		}

		return PLUGIN_SUCCESS;
	}

}