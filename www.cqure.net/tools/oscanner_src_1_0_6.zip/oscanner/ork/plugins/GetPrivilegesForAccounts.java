/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * FIXME: The SQL statement does not take in to account privileges assigned via
 * roles granted via roles.
 *  
 */

package ork.plugins;

import ork.*;
import java.util.*;
import java.sql.*;
import cqure.repeng.*;

public class GetPrivilegesForAccounts implements PluginIface {

	private CommonValuesDB m_oDB;

	private ServerResult m_oRes = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private String m_sSID = null;

	private int m_nPort = -1;

	private ScannerConfig m_oConfig = null;

	private ReportTree m_oTree = null;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public GetPrivilegesForAccounts(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
	}

	private boolean getAccountPrivilegesAsAdmin(String sSID) {

		PluginHelper oHelper = new PluginHelper(m_oRes, m_oLogger, m_oTree);
		String sSQL = "SELECT grantee, granted_role from dba_role_privs "
				+ "ORDER BY grantee";
		OracleDBConnection oDBConn = null;
		Connection oConn = null;
		Statement oStmt = null;
		ResultSet oRs = null;
		ReportObject oRo = null;
		String sPath = null, sPrivs = null, sRole = null;
		Vector oAccountVector = null;
		boolean bDone = false;
		Account oA = null;
		Vector oRoleVec = null;

		if ((oAccountVector = m_oRes.getAccountList().getOpenAccountsForSID(
				sSID)) == null)
			return false;

		for (int i = 0; i < oAccountVector.size(); i++) {

			oA = (Account) oAccountVector.get(i);
			oDBConn = new OracleDBConnection(m_sServer, m_nPort, sSID);
			m_oLogger.debug("[-] GetPrivilegesForAccounts() user:"
					+ oA.getUsername() + ",pw:" + oA.getPassword() + ", sid: "
					+ sSID);
			oDBConn.setUser(oA.getUsername());
			oDBConn.setPassword(oA.getPassword());
			oDBConn.login();

			if ((oConn = oDBConn.getConnection()) == null) {
				m_oLogger.debug("[x] getAccountRolesAsAdmin(\"" + sSID
						+ "\") failed to connect.");
				continue;
			}

			try {
				oStmt = oConn.createStatement();
				oRs = oStmt.executeQuery(sSQL);
				oRoleVec = new Vector();

				while (oRs != null && oRs.next()) {

					sPath = m_sServer + "/" + sSID + "/Accounts/"
							+ oRs.getString("grantee");
					//m_oLogger.debug("Path: " + sPath );

					sRole = oRs.getString("granted_role");
					//m_oLogger.debug("Role: " + sRole );

					oRo = m_oTree.findReportItem(sPath);

					if (oRo != null) {
						sPrivs = (String) oRo.getProperty("Privileges");
						//m_oLogger.debug("Privs: " + sPrivs );

						if (sPrivs != null)
							sPrivs += "," + sRole;
						else
							sPrivs = sRole;

						//m_oLogger.debug("Privs: " + sPrivs );
						oRo.addProperty("Privileges", sPrivs);

					} else {

						/*
						 * FIXME: Until roles granted via roles is implemented
						 * this will generate an error
						 */

						/*
						 * m_oLogger.log("[x] Plugin: GetRolesForAccounts() " +
						 * "failed to retrieve object " + sPath );
						 */
					}

					oRoleVec.add(sRole);

					oA.setRoles(oRoleVec);
					m_oRes.getAccountList().addAccountForSID(sSID, oA);

					bDone = true;
				}

				if (oRs != null)
					oRs.close();

				if (oStmt != null)
					oStmt.close();

				if (oConn != null)
					oConn.close();

				if (bDone)
					return true;

			} catch (SQLException e) {

				/*
				 * ORA-00942: table or view does not exist The user most
				 * probably does not have access
				 */
				if (e.getErrorCode() != 942) {
					/* Something else is wrong.... */
					m_oLogger.debug("[x] Plugin: GetPrivilegesForAccounts "
							+ "failed in getAccountRolesAsAdmin()");
					m_oLogger.debug("[x] Error msg: " + e.getMessage());
				}
				continue;
			}

		}

		return true;

	}

	private boolean getPrivilegesForEachAccount(String sSID) {

		Account oA = null;
		Vector oAccountVector = null;
		Vector oRoleVec = null;
		Connection oConn;
		OracleDBConnection oDBConn = null;
		Statement oStmt;
		ResultSet oRs;
		ReportObject oRo;
		String sSQL = "SELECT granted_role FROM user_role_privs";
		String sPath = null, sPrivs = null;

		if ((oAccountVector = m_oRes.getAccountList().getOpenAccountsForSID(
				sSID)) == null)
			return false;

		for (int i = 0; i < oAccountVector.size(); i++) {

			oA = (Account) oAccountVector.get(i);
			oDBConn = new OracleDBConnection(m_sServer, m_nPort, sSID);
			m_oLogger.debug("[-] GetPrivilegesForAccounts() user:"
					+ oA.getUsername() + ",pw:" + oA.getPassword() + ", sid: "
					+ sSID);
			oDBConn.setUser(oA.getUsername());
			oDBConn.setPassword(oA.getPassword());
			oDBConn.login();

			if ((oConn = oDBConn.getConnection()) == null)
				continue;

			try {
				oStmt = oConn.createStatement();
				oRs = oStmt.executeQuery(sSQL);

				oRoleVec = new Vector();

				while (oRs != null && oRs.next()) {

					String sRole = oRs.getString("granted_role");
					sPath = m_sServer + "/" + sSID + "/Accounts/"
							+ oA.getUsername();

					oRo = m_oTree.findReportItem(sPath);

					if (oRo != null) {
						sPrivs = (String) oRo.getProperty("Privileges");

						if (sPrivs != null)
							sPrivs += "," + sRole;
						else
							sPrivs = sRole;

						oRo.addProperty("Privileges", sPrivs);
					}

					oRoleVec.add(oRs.getString("granted_role"));
				}

				if (oRs != null)
					oRs.close();

				if (oStmt != null)
					oStmt.close();

				if (oDBConn != null)
					oDBConn.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}

			if (oRoleVec.size() > 0) {
				oA.setRoles(oRoleVec);
				m_oRes.getAccountList().addAccountForSID(sSID, oA);
			}

		}

		return true;

	}

	public int scan() {

		SIDList oSIDList = m_oRes.getSIDList();
		String sSID = null;

		if (oSIDList.size() < 1) {
			return PLUGIN_FAILURE;
		}

		while ((sSID = oSIDList.getNextSID()) != null) {

			if (sSID.toLowerCase().indexOf("extproc") != -1)
				continue;

			if (!getAccountPrivilegesAsAdmin(sSID)) {
				m_oLogger.debug("[x] Plugin: GetPrivilegesForAccounts "
						+ "failed retrieving roles using "
						+ "getAccountRolesAsAdmin (" + sSID + ")");
				getPrivilegesForEachAccount(sSID);
			}

		}

		return PLUGIN_SUCCESS;

	}

}