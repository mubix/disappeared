/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.util.*;
import java.sql.*;
import cqure.repeng.*;

public class GetDatabaseLinks implements PluginIface {

	private CommonValuesDB m_oDB;

	private ServerResult m_oRes = null;

	private ReportTree m_oTree = null;

	private ScannerConfig m_oConfig = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private String m_sSID = null;

	private int m_nPort = -1;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public GetDatabaseLinks(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
	}

	public int scan() {

		SIDList oSIDList = m_oRes.getSIDList();
		Connection oConn = null;
		Statement oStmt = null;
		ResultSet oRs = null;
		PluginHelper oHelper = new PluginHelper(m_oRes, m_oLogger);
		PluginReport oRep = null;
		String sSID, sDBLinks = "";
		String sSQL = "SELECT name, host, userid, password FROM sys.link$";
		Vector oAccounts;
		Account oA;
		OracleDBConnection oOraDB;

		m_oLogger.debug("[-] Getting database links");

		while ((sSID = oSIDList.getNextSID()) != null) {

			if (sDBLinks.length() > 0)
				return PLUGIN_SUCCESS;

			/*
			 * We need an administrative account in order to enumerate all
			 * database links
			 * 
			 * FIXME: If no administrative access is granted we could enumerate
			 * all links for each account ...
			 */

			oAccounts = m_oRes.getAccountList().getAllAccountsForRole(sSID,
					"DBA");

			if (oAccounts == null)
				continue;

			//m_oLogger.debug("[.] Creating Oracle connection object");

			oOraDB = new OracleDBConnection(m_sServer, m_nPort, sSID);

			ReportObject o = new ReportObject("Links");
			if (!m_oTree.addReportItem(m_sServer + "/" + sSID, o)) {
				m_oLogger.log("[x] Failed to add link object");
			}

			for (int i = 0; i < oAccounts.size(); i++) {

				oA = (Account) oAccounts.get(i);
				oOraDB.setUser(oA.getUsername());
				oOraDB.setPassword(oA.getPassword());
				oOraDB.login();
				oConn = oOraDB.getConnection();

				if (oConn == null)
					continue;

				try {
					oStmt = oConn.createStatement();

					//m_oLogger.debug("[.] Executing SQL command");
					oRs = oStmt.executeQuery(sSQL);

					while (oRs != null && oRs.next()) {
						//m_oLogger.debug("[.] Adding link");
						o = new ReportObject(oRs.getString("name"));
						o.addProperty("Host", oRs.getString("host"));
						o.addProperty("User", oRs.getString("userid"));
						o.addProperty("Password", oRs.getString("password"));
						o.setSeverity(ReportObject.SEVERITY_LEVEL_WARNING);

						if (!m_oTree.addReportItem(m_sServer + "/" + sSID
								+ "/Links", o)) {
							m_oLogger.log("[x] Failed to add "
									+ "dblink to report");
						}

						sDBLinks += "Name: " + oRs.getString("name") + ", ";
						sDBLinks += "Host: " + oRs.getString("host") + ", ";
						sDBLinks += "User: " + oRs.getString("userid") + ", ";
						sDBLinks += "Password: " + oRs.getString("password");
						sDBLinks += "\r\n";
					}

					if (oRs != null)
						oRs.close();

					if (oStmt != null)
						oStmt.close();

					oOraDB.close();
					m_oLogger.debug("[-] Found database links");

					break;

				} catch (SQLException e) {
					m_oLogger.log("[x] Failed to enumerate database links");
					//e.printStackTrace();
					return PLUGIN_FAILURE;
				}

			}

			if (sDBLinks.length() > 0) {
				oRep = new PluginReport();
				oRep.setHeader("Database links");
				oRep.setSID(sSID);
				oRep.setHost(m_sServer);
				oRep.setBody(sDBLinks);
				m_oRes.getPluginReportList().add(oRep);

			}

		}

		try {
			if (oConn != null)
				oConn.close();

		} catch (SQLException e) {
			m_oLogger.debug("[x] Failed to close database connection");
		}

		return PLUGIN_SUCCESS;
	}

}