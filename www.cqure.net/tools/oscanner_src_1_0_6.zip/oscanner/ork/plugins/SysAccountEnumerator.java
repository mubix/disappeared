/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */


package ork.plugins;

import ork.*;
import java.sql.*;

public class SysAccountEnumerator {

	private Connection m_oConn;

	private ServerResult m_oRes;

	private String m_sSID;

	private Logger m_oLogger = null;

	public SysAccountEnumerator() {

	}

	public SysAccountEnumerator(Connection oConn, String sSID,
			ServerResult oRes, Logger oLog) {

		m_oConn = oConn;
		m_oRes = oRes;
		m_sSID = sSID;
		m_oLogger = oLog;

	}

	public void setConnection(Connection oConn) {
		m_oConn = oConn;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setSID(String sSID) {
		m_sSID = sSID;
	}

	public boolean enumerateSysAccounts() {

		/*
		 * String sSQL = "select a.username, a.password " + "from sys.dba_users
		 * a left outer join sys.dba_users b " + "on b.username = a.username";
		 */

		String sSQL = "SELECT username FROM all_users";

		Statement oStmt = null;
		ResultSet oRS = null;
		String sUsername; //, sPassword;
		boolean bRet = false;
		int nAccounts = 0;

		m_oLogger.log("[-] Enumerating system accounts for SID (" + m_sSID
				+ ")");

		try {
			oStmt = m_oConn.createStatement();
			oRS = oStmt.executeQuery(sSQL);

			while (oRS != null && oRS.next()) {
				sUsername = oRS.getString("username");
				//sPassword = oRS.getString("password");

				m_oLogger.debug("[-] Adding account " + sUsername);

				m_oRes.addAccount(m_sSID, sUsername, null, null,
						Account.ACCOUNT_STATUS_UNKNOWN);

				nAccounts++;
				bRet = true;
			}
			if (oRS != null)
				oRS.close();
			else
				m_oLogger.log("[x] Enumerating system accounts failed");

			if (oStmt != null)
				oStmt.close();

		} catch (SQLException e) {
			m_oLogger.log("[x] Enumerating system accounts failed");
			System.err.println(e.getMessage());
		}

		m_oLogger.log("[-] Succesfully enumerated " + nAccounts + " accounts");

		return bRet;

	}

}