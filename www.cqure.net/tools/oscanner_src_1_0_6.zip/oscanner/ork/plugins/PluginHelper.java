/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.util.*;
import java.sql.*;
import cqure.repeng.*;

public class PluginHelper {

	ServerResult m_oRes = null;

	AccountList m_oAccList = null;

	SIDList m_oSIDList = null;

	Logger m_oLogger = null;

	ReportTree m_oTree = null;

	public PluginHelper(ServerResult oRes) {
		m_oRes = oRes;
		m_oAccList = oRes.getAccountList();
		m_oSIDList = oRes.getSIDList();
	}

	public PluginHelper(ServerResult oRes, Logger oLogger) {
		m_oRes = oRes;
		m_oAccList = oRes.getAccountList();
		m_oSIDList = oRes.getSIDList();
		m_oLogger = oLogger;
	}

	public PluginHelper(ServerResult oRes, Logger oLogger, ReportTree oTree) {
		m_oRes = oRes;
		m_oAccList = oRes.getAccountList();
		m_oSIDList = oRes.getSIDList();
		m_oLogger = oLogger;
		m_oTree = oTree;
	}

	/*
	 * public Connection getConnectionWithRole(String sSID, String sRole) {
	 * Account oA = null; OracleDBConnection oOraDBConn = null;
	 * 
	 * oA = m_oRes.getAccountList().getAccountWithRole( sSID, sRole );
	 * 
	 * if ( oA == null ) { return null; }
	 * 
	 * if ( m_oLogger != null ) { m_oLogger.debug("[-] got account with " +
	 * sRole + " role"); m_oLogger.debug("[-] account is " + oA.getUsername() +
	 * "/" + oA.getPassword()); }
	 * 
	 * oOraDBConn = new OracleDBConnection( m_oRes.getServer(),
	 * m_oRes.getPort(), sSID );
	 * 
	 * oOraDBConn.setUser( oA.getUsername() ); oOraDBConn.setPassword(
	 * oA.getPassword() );
	 * 
	 * if ( oOraDBConn.login() == oOraDBConn.ERROR_CONNECT_AS_SYSDBA ) {
	 * m_oLogger.debug("[x] Connection requires AS SYSDBA, trying ...");
	 * oOraDBConn.setUser( oA.getUsername() + " AS SYSDBA"); oOraDBConn.login(); }
	 * 
	 * return oOraDBConn.getConnection(); }
	 */

	public Connection getConnectionWithRole(String sSID, String sRole) {

		String sPath = m_oRes.getServer() + "/" + sSID + "/Accounts";
		String sPriv = null;
		String sStatus = null;
		ReportObject oRo;
		OracleDBConnection oOConn = null;
		StringTokenizer oPrivs = null;

		if (m_oTree == null)
			return null;

		if ((oRo = m_oTree.findReportItem(sPath)) == null) {
			m_oLogger.info("PluginHelper: failed to find path: " + sPath);
			return null;
		}

		for (Enumeration oEnum = oRo.children(); oEnum.hasMoreElements();) {
			oRo = (ReportObject) oEnum.nextElement();
			sStatus = (String) oRo.getProperty("Status");

			if (sStatus == null || !sStatus.equalsIgnoreCase("Open"))
				continue;

			if ((String) oRo.getProperty("Privileges") != null) {
				oPrivs = new StringTokenizer((String) oRo
						.getProperty("Privileges"), ",");
			}

			while (oPrivs != null && oPrivs.hasMoreTokens()) {

				sPriv = oPrivs.nextToken();

				if (sPriv.equalsIgnoreCase(sRole)) {

					oOConn = new OracleDBConnection(m_oRes.getServer(), m_oRes
							.getPort(), sSID);

					oOConn.setUser(oRo.getName());
					oOConn.setPassword((String) oRo.getProperty("Password"));

					if (oOConn.login() == OracleDBConnection.ERROR_CONNECT_AS_SYSDBA) {
						m_oLogger.debug("[x] Connection requires AS "
								+ "SYSDBA, trying ...");
						oOConn.setUser(oRo.getName() + " AS SYSDBA");
						oOConn.login();
					}

				}

			}

		}

		if (oOConn != null)
			return oOConn.getConnection();
		else
			return null;

	}

	public Connection getAdminConnection() {
		return null;
	}

	public Connection getAnyConnection() {

		String sSID = null;
		Vector oV = null;
		boolean bFound = false;
		Account oA = null;
		int i = 0;
		OracleDBConnection oOraConn = null;

		while ((sSID = m_oSIDList.getNextSID()) != null) {

			oV = m_oAccList.getAccountsForSID(sSID);

			while (oV != null && !bFound && i < oV.size()) {

				oA = (Account) oV.get(i);

				if (oA != null && oA.getState() == Account.ACCOUNT_STATUS_VALID) {
					oOraConn = new OracleDBConnection(m_oRes.getServer(),
							m_oRes.getPort(), sSID);

					oOraConn.setUser(oA.getUsername());
					oOraConn.setPassword(oA.getPassword());

					oOraConn.login();
					return oOraConn.getConnection();
				}

				i++;

			}

		}

		return null;

	}

}