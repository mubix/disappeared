/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.sql.*;
import cqure.repeng.*;

public class GetAuditInfo implements PluginIface {

	private CommonValuesDB m_oDB;

	private OracleDBConnection m_oOraDBConn;

	private ServerResult m_oRes = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private int m_nPort = -1;

	private SIDList m_oSIDList = null;

	private PluginHelper m_oPlugHelp;

	private ScannerConfig m_oConfig = null;

	private ReportTree m_oTree = null;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public GetAuditInfo(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
		m_oPlugHelp = new PluginHelper(oRes);
	}

	public int scan() {

		PluginHelper oHelper = new PluginHelper(m_oRes, m_oLogger, m_oTree);
		Connection oConn = null;
		Statement oStmt = null;
		ResultSet oRs = null;
		SIDList oSIDList = m_oRes.getSIDList();
		String sSID = null, sPath = null, sRole = null;
		ReportObject oRo = null;
		String sSQL = "SELECT * FROM sys.dba_priv_audit_opts "
				+ "WHERE privilege='CREATE SESSION'";

		if (oSIDList.size() < 1) {
			return PLUGIN_FAILURE;
		}

		while ((sSID = oSIDList.getNextSID()) != null) {

			m_oLogger.debug("[-] Plugin: GetAuditInfo getting DBA "
					+ "for sid: " + sSID);

			oConn = oHelper.getConnectionWithRole(sSID, "DBA");

			if (oConn == null) {
				m_oLogger.debug("[-] Plugin: Failed to get connection");
				continue;
			}

			try {
				oStmt = oConn.createStatement();
				oRs = oStmt.executeQuery(sSQL);

				m_oTree.addReportItem(m_sServer + "/" + sSID, new ReportObject(
						"Auditing"));

				if (oRs != null && oRs.next()) {

					m_oTree.addReportItem(
							m_sServer + "/" + sSID + "/Auditing/",
							new ReportObject("Login Attempts"));

					sPath = m_sServer + "/" + sSID + "/Auditing"
							+ "/Login Attempts";

					if (oRs.getString("failure").equalsIgnoreCase("NOT SET")) {

						oRo = new ReportObject("Failed login attempts");
						oRo.setSeverity(ReportObject.SEVERITY_LEVEL_CRITICAL);
						oRo.addProperty("Comment", "Not logging failed "
								+ "login attempts");

						m_oTree.addReportItem(sPath, oRo);

					}

					if (oRs.getString("success").equalsIgnoreCase("NOT SET")) {
						oRo = new ReportObject("Successful login attempts");
						oRo.setSeverity(ReportObject.SEVERITY_LEVEL_WARNING);
						oRo.addProperty("Comment", "Not logging successfull "
								+ "login attempts");
						m_oTree.addReportItem(sPath, oRo);
					}

				}
				/*
				 * if no resultset was returned, auditing is obviosly not
				 * enabled
				 */
				else {
					oRo = new ReportObject("Login attempts");
					oRo.setSeverity(ReportObject.SEVERITY_LEVEL_CRITICAL);
					oRo.addProperty("Comment", "Auditing of login attempts "
							+ "not enabled");
					m_oTree.addReportItem(
							m_sServer + "/" + sSID + "/Auditing/", oRo);
				}

				if (oStmt != null)
					oStmt.close();

				if (oRs != null)
					oRs.close();

				if (oConn != null)
					oConn.close();

			} catch (SQLException e) {
				/* This should not happen :) */
				m_oLogger.log("Plugin: GetAuditInfo error: " + e.getMessage());
			}

		} /* end while sid ... */

		return PLUGIN_SUCCESS;
	}

}