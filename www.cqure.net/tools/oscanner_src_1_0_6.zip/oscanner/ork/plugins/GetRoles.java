/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.sql.*;
import cqure.repeng.*;

public class GetRoles implements PluginIface {

	private CommonValuesDB m_oDB;

	private OracleDBConnection m_oOraDBConn;

	private ServerResult m_oRes = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private int m_nPort = -1;

	private SIDList m_oSIDList = null;

	private PluginHelper m_oPlugHelp;

	private ScannerConfig m_oConfig = null;

	private ReportTree m_oTree = null;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public GetRoles(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
		m_oPlugHelp = new PluginHelper(oRes);
	}

	public int scan() {

		PluginHelper oHelper = new PluginHelper(m_oRes, m_oLogger, m_oTree);
		Connection oConn = null;
		Statement oStmt = null;
		ResultSet oRs = null;
		SIDList oSIDList = m_oRes.getSIDList();
		String sSID = null, sPath = null, sRole = null;
		ReportObject oRo = null;
		String sSQL = "SELECT * FROM dba_roles ORDER BY role";

		String sPrivs = null;

		if (oSIDList.size() < 1) {
			return PLUGIN_FAILURE;
		}

		while ((sSID = oSIDList.getNextSID()) != null) {

			if (sSID.toLowerCase().indexOf("extproc") != -1)
				continue;

			m_oLogger.debug("[-] Plugin: GetRoles getting DBA connection "
					+ "for sid: " + sSID);

			oConn = oHelper.getConnectionWithRole(sSID, "DBA");

			if (oConn == null) {
				m_oLogger.debug("[-] Plugin: Failed to get DBA connection");
				continue;
			}

			try {
				oStmt = oConn.createStatement();
				oRs = oStmt.executeQuery(sSQL);

				if (oRs != null) {
					m_oTree.addReportItem(m_sServer + "/" + sSID,
							new ReportObject("Roles"));
				}

				while (oRs != null && oRs.next()) {
					sPath = m_sServer + "/" + sSID + "/Roles/";
					sRole = oRs.getString("role");

					if (!m_oTree.addReportItem(sPath, new ReportObject(sRole)))
						m_oLogger.log("[x] Plugin: GetRoles failed to add "
								+ "role " + sRole);

				}

				if (oStmt != null)
					oStmt.close();

				if (oRs != null)
					oRs.close();

				if (oConn != null)
					oConn.close();

			} catch (SQLException e) {

				/*
				 * ORA-00942: table or view does not exist The user most
				 * probably does not have access
				 */
				if (e.getErrorCode() != 942) {
					/* Something else is wrong.... */
					m_oLogger.debug("[x] Plugin: GetPrivilegesForRoles "
							+ "failed in getAccountRolesAsAdmin()");
					m_oLogger.debug("[x] Error msg: " + e.getMessage());
				}
				continue;

			}

		} /* end while sid ... */

		return PLUGIN_SUCCESS;
	}

}