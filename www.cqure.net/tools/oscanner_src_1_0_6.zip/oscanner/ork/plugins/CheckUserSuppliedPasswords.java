/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.util.*;
import cqure.repeng.*;

public class CheckUserSuppliedPasswords implements PluginIface {

	private CommonValuesDB m_oDB;

	private ServerResult m_oRes = null;

	private static final int STATUS_RERUN = 1;

	private static final int STATUS_SUCCESS = 0;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private String m_sSID = null;

	private int m_nPort = -1;

	private ScannerConfig m_oConfig = null;

	private ReportTree m_oTree = null;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public CheckUserSuppliedPasswords(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
	}

	public int checkAccounts(String sSID, UserList oU, PasswordList oP) {

		String sUID = null, sPWD = null;
		AccountList oA = m_oRes.getAccountList();
		OracleDBConnection oOraDB = new OracleDBConnection(m_sServer, m_nPort,
				sSID);
		SysAccountEnumerator oSysAccEnum = null;
		Vector oUsers = null;
		int nErr;

		/*
		 * This loop is entered only if no user/password has yet been
		 * discovered. It runs a check for all supplied passwords against all
		 * supplied user. Upon a match it enumerates all users and exits with a
		 * status that tells the main loop to reenter the checkaccounts
		 * function. If this happens we should be entering the else part of this
		 * if-statement.
		 *  
		 */
		if (oA != null && !oA.isAccountsEnumeratedForSID(sSID)) {

			for (int i = 0; i < oU.size(); i++) {
				sUID = ((String) oU.get(i)).toUpperCase();
				oOraDB.setUser(sUID);

				for (int j = 0; j < oP.size(); j++) {
					sPWD = ((String) oP.get(j)).toUpperCase();

					/* Handle special cases */
					if (sPWD.equalsIgnoreCase("%username%"))
						sPWD = sUID;

					oOraDB.setPassword(sPWD);

					m_oLogger.debug("[-] Trying " + sUID + "/" + sPWD);
					nErr = oOraDB.login();

					/* Successfull login ? */
					if (nErr == OracleDBConnection.OK) {

						m_oLogger.log("[-] Account " + sUID + "/" + sPWD
								+ " found");

						m_oRes.addAccount(sSID, sUID, sPWD, null, nErr);

						/* enumerate system accounts */
						oSysAccEnum = new SysAccountEnumerator(oOraDB
								.getConnection(), sSID, m_oRes, m_oLogger);

						if (oSysAccEnum.enumerateSysAccounts()) {
							oA.setAccountsEnumeratedForSID(sSID);
							oOraDB.close();

							return STATUS_RERUN;
						}

					} /* endif succesfully logged in */
					else if (nErr == OracleDBConnection.ERROR_ACCOUNT_LOCKED) {
						m_oLogger.log("[-] Account " + sUID + "/" + sPWD
								+ " is locked");
						m_oRes.addAccount(sSID, sUID, "", null, nErr);
					}
					/* Does the account require sysdba */
					else if (nErr == OracleDBConnection.ERROR_CONNECT_AS_SYSDBA) {
						m_oLogger.log("[-] Account " + sUID + "/" + sPWD
								+ " requires connect as sysdba");
						m_oRes.addAccount(sSID, sUID, // + " AS SYSDBA",
								sPWD, null, OracleDBConnection.OK);
					} else if (nErr == OracleDBConnection.ERROR_IO_EXCEPTION) {
						m_oLogger.log("[x] Got IO Exception");
						break;
					} else if (nErr == OracleDBConnection.ERROR_LOGIN_FAILED) {
					} else {
						m_oLogger.log("[x] Error: " + nErr + " occured");
					}

					oOraDB.close();
				}

			}

		}
		/*
		 * If we are here it means that all accounts have been succesfully
		 * enumerated. This means that we don't actually need to care about the
		 * supplied userlist and that we should only run the password list
		 * against accounts having the UNKNOWN state set. What are we waiting
		 * for? let's go!
		 *  
		 */
		else {

			m_oLogger.log("[-] Checking user supplied dictionary");
			oUsers = oA.getUknownAccountsForSID(sSID);

			for (int i = 0; i < oUsers.size(); i++) {
				sUID = (String) ((Account) oUsers.get(i)).getUsername();
				oOraDB.setUser(sUID);

				for (int j = 0; j < oP.size(); j++) {
					sPWD = ((String) oP.get(j)).toUpperCase();

					/* Handle special cases */
					if (sPWD.equalsIgnoreCase("%username%"))
						sPWD = sUID;

					oOraDB.setPassword(sPWD);

					m_oLogger.debug("[-] Trying " + sUID + "/" + sPWD);
					nErr = oOraDB.login();

					/* Successfull login ? */
					if (nErr == OracleDBConnection.OK) {
						m_oLogger.log("[-] Account " + sUID + "/" + sPWD
								+ " found");
						m_oRes.addAccount(sSID, sUID, sPWD, null, nErr);

						break;
					} else if (nErr == OracleDBConnection.ERROR_ACCOUNT_LOCKED) {
						m_oLogger.log("[-] Account " + sUID + "/" + sPWD
								+ " is locked");
						m_oRes.addAccount(sSID, sUID, "", null, nErr);
						break;
					}
					/* Does the account require sysdba */
					else if (nErr == OracleDBConnection.ERROR_CONNECT_AS_SYSDBA) {
						m_oLogger.log("[-] Account " + sUID + "/" + sPWD
								+ " requires connect as sysdba");
						m_oRes.addAccount(sSID, sUID + " AS SYSDBA", sPWD,
								null, OracleDBConnection.OK);
						break;
					} else if (nErr == OracleDBConnection.ERROR_IO_EXCEPTION) {
						m_oLogger.log("[x] Sid does not exist");

						/* The sid does not exist eject */
						return STATUS_SUCCESS;
					} else if (nErr == OracleDBConnection.ERROR_LOGIN_FAILED) {
					} else {
						m_oLogger.log("[x] Error: " + nErr + " occured");
					}

					oOraDB.close();

				} /* end password loop */

			} /* end user loop */

		} /* end else if accounts were discovered */

		return STATUS_SUCCESS;

	}

	public String padWithSpaces(int nCount) {
		String s = "";

		for (int i = 0; i < nCount; i++)
			s += " ";

		return s;
	}

	/*
	 * This plugin should log a report of the passwords found The next pw plugin
	 * (CheckUserSuppliedPasswords) should check the report area for this entry
	 * and remove it and insert an updated version since it should contain
	 * everything we are reporting
	 */
	public void report() {

		Account oA = null;
		AccountList oAList = m_oRes.getAccountList();
		PluginReport oRep;
		SIDList oSIDList = m_oRes.getSIDList();
		Vector oUsers = null;
		String sSID;
		String sHeader = null;
		String sBody = "", sTmp = "";
		ReportObject oRo = null;

		while ((sSID = oSIDList.getNextSID()) != null) {

			sHeader = "Accounts";
			oUsers = oAList.getAccountsForSID(sSID);

			if (oUsers == null)
				continue;

			for (int i = 0; i < oUsers.size(); i++) {
				oA = (Account) oUsers.get(i);

				sTmp = oA.getUsername();

				if ((oRo = m_oTree.findReportItem(m_sServer + "/" + sSID
						+ "/Accounts/" + sTmp)) == null) {
					oRo = new ReportObject(sTmp);
					m_oTree.addReportItem(m_sServer + "/" + sSID + "/Accounts",
							oRo);
				}

				oRo.addProperty("Password", oA.getPassword());

				if (oA.getPassword() != null && oA.getPassword().length() > 0)
					sTmp += "/" + oA.getPassword();

				if (oA.getState() == Account.ACCOUNT_STATUS_LOCKED) {
					sTmp += padWithSpaces(50 - sTmp.length());
					sBody += sTmp + "[locked]\n";
					oRo.addProperty("Status", "Locked");
				} else if (oA.getState() == Account.ACCOUNT_STATUS_VALID) {
					sTmp += padWithSpaces(50 - sTmp.length());
					sBody += sTmp + "[open]\n";
					oRo.addProperty("Status", "Open");
					//System.err.println("==>SID: " + sSID + " U:" +
					// oA.getUsername());

					if (oA.getUsername().equalsIgnoreCase(oA.getPassword()))
						oRo.setSeverity(ReportObject.SEVERITY_LEVEL_CRITICAL);
					else {
						if (oRo.getSeverity() == ReportObject.SEVERITY_LEVEL_INFO)
							oRo
									.setSeverity(ReportObject.SEVERITY_LEVEL_WARNING);
					}

				} else {
					/* Password is unknown */
					sBody += sTmp + "\n";
				}

			} /* End forloop */

			if (sBody.length() > 0) {
				oRep = new PluginReport();
				oRep.setHeader(sHeader);
				oRep.setSID(sSID);
				oRep.setBody(sBody);
				oRep.setHost(m_sServer);
				m_oRes.getPluginReportList().add(oRep);
			}

			sBody = "";

		} /* end sid loop */
	}

	public int scan() {

		UserList oUserList = new UserList();
		PasswordList oPassList = new PasswordList();

		String sUserfile = m_oConfig.getConfigOption("UsernameFile");
		String sPassfile = m_oConfig.getConfigOption("DictionaryFile");
		String sSID = null;

		SIDList oSIDList = (SIDList) m_oRes.getSIDList().clone();
		int nRet;

		if (sUserfile == null) {
			m_oLogger.log("[x] Failed to get value for userfile");
			return PLUGIN_FAILURE;
		}

		if (sPassfile == null) {
			m_oLogger.log("[x] Failed to get value for dictionaryfile");
			return PLUGIN_FAILURE;
		}

		if (oUserList.loadFromFile(sUserfile) != UserList.OK) {
			m_oLogger.log("[x] Failed to load userfile (" + sUserfile + ")");
			return PLUGIN_FAILURE;
		}

		if (oPassList.loadFromFile(sPassfile) != UserList.OK) {
			m_oLogger.log("[x] Failed to load dictionary (" + sPassfile + ")");
			return PLUGIN_FAILURE;
		}

		while ((sSID = oSIDList.getNextSID()) != null) {

			if (sSID.toLowerCase().indexOf("extproc") == -1) {

				m_oLogger.log("[-] Checking user supplied passwords "
						+ "against sid (" + sSID + ")");

				if (!m_oTree.addReportItem(m_sServer + "/" + sSID,
						new ReportObject("Accounts"))) {

					m_oLogger.log("[x] CheckCommonPasswords "
							+ "addReportItem failed");

				}

				do {
					nRet = checkAccounts(sSID, oUserList, oPassList);
				} while (nRet == STATUS_RERUN);

			} /* end if check for extproc */

		} /* end whileloop */

		report();

		return PLUGIN_SUCCESS;
	}

}