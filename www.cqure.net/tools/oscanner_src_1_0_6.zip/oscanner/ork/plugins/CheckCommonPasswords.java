/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.util.*;
import cqure.repeng.*;

public class CheckCommonPasswords implements PluginIface {

	private CommonValuesDB m_oDB;

	private OracleDBConnection m_oOraDBConn;

	private ServerResult m_oRes = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private int m_nPort = -1;

	private SIDList m_oSIDList = null;

	private ScannerConfig m_oConfig = null;

	private ReportTree m_oTree = null;

	private static final int STATUS_SUCCESS = 0;

	private static final int STATUS_RERUN = 1;

	private static final int STATUS_FAILURE = -1;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public CheckCommonPasswords(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
	}

	private int guessDefaultPwOnSID(String sSID, PasswordItemList oList) {

		PasswordItem oItem;
		String sUserName, sPassWord;
		int nErr = -1;
		SysAccountEnumerator oSysAccEnum = null;
		AccountList oA = m_oRes.getAccountList();

		/* Iterate over user/password items */
		while ((oItem = oList.GetNextItem()) != null) {

			sUserName = oItem.getUsername();
			sPassWord = oItem.getPassword();

			if (oA.isAccountsEnumeratedForSID(sSID)) {
				if (oA.getAccountForUsername(sUserName, sSID) == null) {
					continue;
				}
			}

			m_oLogger.debug("[-] Trying " + sUserName + "/" + sPassWord);
			m_oOraDBConn = new OracleDBConnection(m_sServer, m_nPort, sSID);

			if (m_oOraDBConn == null) {
				m_oLogger.log("[x] Plugin1: Failed to aquire "
						+ "Oracle Connection object");
				return STATUS_FAILURE;
			}

			m_oOraDBConn.setUser(sUserName);
			m_oOraDBConn.setPassword(sPassWord);

			nErr = m_oOraDBConn.login();

			if (nErr == OracleDBConnection.OK) {
				m_oLogger.log("[-] Account " + sUserName + "/" + sPassWord
						+ " found");

				m_oRes.addAccount(sSID, sUserName, sPassWord, null, nErr);

				/* enumerate system accounts */
				oSysAccEnum = new SysAccountEnumerator(m_oOraDBConn
						.getConnection(), sSID, m_oRes, m_oLogger);

				if (!oA.isAccountsEnumeratedForSID(sSID)) {

					if (oSysAccEnum.enumerateSysAccounts()) {
						/* mark sysaccountenumeration done */
						oA.setAccountsEnumeratedForSID(sSID);
						m_oOraDBConn.close();
						return STATUS_RERUN;
					}
				}

			} else if (nErr == OracleDBConnection.ERROR_ACCOUNT_LOCKED) {
				m_oLogger.log("[-] Account " + sUserName + "/" + sPassWord
						+ " is locked");
				m_oRes.addAccount(sSID, sUserName, "", null, nErr);
			} else if (nErr == OracleDBConnection.ERROR_IO_EXCEPTION) {
				m_oLogger.log("[x] Got IO Exception");
				break;
			} else if (nErr == OracleDBConnection.ERROR_CONNECT_AS_SYSDBA) {
				m_oLogger.log("[-] Account " + sUserName + "/" + sPassWord
						+ " requires connect as sysdba");
				m_oRes.addAccount(sSID, sUserName, // + " AS SYSDBA",
						sPassWord, null, OracleDBConnection.OK);
			}
			/* empty if in order to not reach last catchall logger */
			else if (nErr == OracleDBConnection.ERROR_LOGIN_FAILED) {
			} else {
				m_oLogger.debug("[-] Got error " + nErr);
			}

			m_oOraDBConn.close();

		}

		return STATUS_SUCCESS;
	}

	public String padWithSpaces(int nCount) {
		String s = "";

		for (int i = 0; i < nCount; i++)
			s += " ";

		return s;
	}

	/*
	 * This plugin should log a report of the passwords found The next pw plugin
	 * (CheckUserSuppliedPasswords) should check the report area for this entry
	 * and remove it and insert an updated version since it should contain
	 * everything we are reporting
	 */
	public void report() {

		Account oA = null;
		AccountList oAList = m_oRes.getAccountList();
		PluginReport oRep;
		SIDList oSIDList = m_oRes.getSIDList();
		Vector oUsers = null;
		String sSID;
		String sHeader = null;
		String sBody = "", sTmp = "";
		ReportObject oRo;

		while ((sSID = oSIDList.getNextSID()) != null) {

			sHeader = "Accounts for SID (" + sSID + ")";
			oUsers = oAList.getAccountsForSID(sSID);

			if (oUsers == null)
				continue;

			for (int i = 0; i < oUsers.size(); i++) {
				oA = (Account) oUsers.get(i);
				sTmp = oA.getUsername();

				if ((oRo = m_oTree.findReportItem(m_sServer + "/" + sSID
						+ "/Accounts/" + sTmp)) == null) {
					oRo = new ReportObject(sTmp);
					m_oTree.addReportItem(m_sServer + "/" + sSID + "/Accounts",
							oRo);
				}

				oRo.addProperty("Password", oA.getPassword());

				if (oA.getPassword() != null && oA.getPassword().length() > 0)
					sTmp += "/" + oA.getPassword();

				if (oA.getState() == Account.ACCOUNT_STATUS_LOCKED) {
					sTmp += padWithSpaces(50 - sTmp.length());
					sBody += sTmp + "[locked]\n";
					oRo.addProperty("Status", "Locked");
				} else if (oA.getState() == Account.ACCOUNT_STATUS_VALID) {
					sTmp += padWithSpaces(50 - sTmp.length());
					sBody += sTmp + "[open]\n";
					oRo.addProperty("Status", "Open");
					oRo.setSeverity(ReportObject.SEVERITY_LEVEL_CRITICAL);
				} else {
					/* Account in unknown */
					sBody += sTmp + "\n";
				}

			} /* End forloop */

			if (sBody.length() > 0) {
				/*
				 * FIXME oRep = new PluginReport( sHeader, sBody );
				 * m_oRes.getPluginReportList().add( oRep );
				 */
			}

			sBody = "";

		} /* end sid loop */
	}

	public int scan() {

		PasswordItemList oList = new PasswordItemList();
		String sSID;
		int nErr;

		if ((m_oSIDList = m_oRes.getSIDList()) == null) {
			m_oLogger.log("[x] Plugin failed to retrieve SID list");
			return PLUGIN_FAILURE;
		}

		if (m_sServer == null) {
			m_oLogger.log("[x] No server has been set");
			return -1;
		}

		if (!oList.LoadPasswordFile("accounts.default", "/")) {
			System.err.println("[x] Plugin1: Failed to open accounts.default");
			return -1;
		}

		if (m_oRes == null) {
			m_oLogger.log("[x] Plugin1: Serverresult not set");
			return -1;
		}

		while ((sSID = m_oSIDList.getNextSID()) != null) {

			nErr = 0;
			oList.reset();

			if (sSID.toLowerCase().indexOf("extproc") == -1) {
				m_oLogger.log("[-] Checking sid (" + sSID
						+ ") for common passwords");

				if (!m_oTree.addReportItem(m_sServer + "/" + sSID,
						new ReportObject("Accounts"))) {

					m_oLogger.log("[x] CheckCommonPasswords "
							+ "addReportItem failed");

				}

				do {
					nErr = guessDefaultPwOnSID(sSID, oList);
				} while (nErr == STATUS_RERUN);

			}
		}

		report();
		return PLUGIN_SUCCESS;
	}

}