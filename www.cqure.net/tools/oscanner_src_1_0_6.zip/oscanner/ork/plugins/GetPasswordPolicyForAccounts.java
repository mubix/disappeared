/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork.plugins;

import ork.*;
import java.sql.*;
import cqure.repeng.*;

public class GetPasswordPolicyForAccounts implements PluginIface {

	private CommonValuesDB m_oDB;

	private ServerResult m_oRes = null;

	private ScannerConfig m_oConfig = null;

	private Logger m_oLogger = new Logger();

	private String m_sServer = null;

	private String m_sSID = null;

	private int m_nPort = -1;

	private ReportTree m_oTree = null;

	public void setCommonValuesDB(CommonValuesDB oDB) {
		m_oDB = oDB;
	}

	public void setServerResult(ServerResult oRes) {
		m_oRes = oRes;
	}

	public void setLogger(Logger oLogger) {
		m_oLogger = oLogger;
	}

	public void setParameters(Object o) {
	}

	public void setConfig(ScannerConfig o) {
		m_oConfig = o;
	}

	public void setReportTree(ReportTree o) {
		m_oTree = o;
	}

	public GetPasswordPolicyForAccounts(ServerResult oRes) {
		m_oRes = oRes;
		m_nPort = m_oRes.getPort();
		m_sServer = m_oRes.getServer();
	}

	public int scan() {

		String sSQL = "SELECT username, profile FROM dba_users";
		String sSID, sPath = null, sProfile = null;
		SIDList oSIDList = m_oRes.getSIDList();
		Connection oConn = null;
		Statement oStmt = null;
		ResultSet oRs = null;
		ReportObject oRo = null;
		PluginHelper oHelper = new PluginHelper(m_oRes, m_oLogger, m_oTree);

		if (oSIDList.size() < 1) {
			return PLUGIN_FAILURE;
		}

		/* Loop over SIDS */
		while ((sSID = oSIDList.getNextSID()) != null) {

			oConn = oHelper.getConnectionWithRole(sSID, "DBA");

			/* if no DBA accounts where found for this particular sid */
			if (oConn == null)
				continue;

			try {
				oStmt = oConn.createStatement();
				oRs = oStmt.executeQuery(sSQL);

				while (oRs != null && oRs.next()) {

					sPath = m_sServer + "/" + sSID + "/Accounts/"
							+ oRs.getString("username");

					sProfile = oRs.getString("profile");

					oRo = new ReportObject(oRs.getString("username"));
					oRo.setType(ReportObject.REPORT_LINK);
					oRo.setValue(sPath);

					if (!m_oTree.addReportItem(m_sServer + "/" + sSID
							+ "/Password Policies/" + sProfile, oRo)) {

						m_oLogger.log("[x] Failed to add account for "
								+ "password profile");
					}

					oRo = m_oTree.findReportItem(sPath);

					if (oRo != null)
						oRo.addProperty("Profile", sProfile);

				}

				if (oRs != null)
					oRs.close();

				if (oStmt != null)
					oStmt.close();

			} catch (SQLException e) {
				m_oLogger.log("[x] Failed to retrieve ....");
				e.printStackTrace();
				return PLUGIN_FAILURE;
			}

		}

		try {
			if (oConn != null)
				oConn.close();
		} catch (SQLException e) {
			m_oLogger.debug("[x] Failed to close database connection");
		}

		return PLUGIN_SUCCESS;
	}

}