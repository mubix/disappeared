/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.util.*;

public class PasswordItem {

	private String m_sUser = null;

	private String m_sPassword = null;

	public PasswordItem() {
	}

	/*
	 * sComb = User and Password delimited by sDelimiter
	 *  
	 */
	public void addDelimitedItem(String sComb, String sDelimiter) {
		StringTokenizer oSt = new StringTokenizer(sComb, sDelimiter);

		try {
			m_sUser = oSt.nextToken();
			m_sPassword = oSt.nextToken();
		} catch (Exception e) {
			System.err.println("[x] Failed to process password");
			return;
		}
	}

	public String getUsername() {
		return m_sUser;
	}

	public String getPassword() {
		return m_sPassword;
	}

	public void setUsername(String sUser) {
		m_sUser = sUser;
	}

	public void setPassword(String sPass) {
		m_sPassword = sPass;
	}
}

