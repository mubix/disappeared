/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.util.*;
import java.io.*;

public class PasswordItemList extends Vector {

	private int nPos = 0;

	public PasswordItemList() {

	}

	public synchronized PasswordItem GetNextItem() {

		PasswordItem oItem = null;

		if (nPos == this.size())
			return null;

		oItem = (PasswordItem) this.get(nPos);
		nPos++;

		return oItem;
	}

	public void reset() {
		nPos = 0;
	}

	public boolean LoadPasswordFile(String sFilename, String sDelimiter) {

		PasswordItem oItem = null;
		LineNumberReader oReader = null;
		String sLine = null;

		try {
			oReader = new LineNumberReader(new FileReader(sFilename));
		} catch (FileNotFoundException e) {
			System.err
					.println("ERROR: LoadPasswordFile() Could not find password file "
							+ sFilename + ".");
			return false;
		}

		do {
			try {
				sLine = oReader.readLine();
			} catch (IOException e) {
				System.err
						.println("ERROR: LoadPasswordFile() Reading password file failed");
				return false;
			}

			if (sLine != null) {
				oItem = new PasswordItem();
				oItem.addDelimitedItem(sLine, sDelimiter);
				this.add(oItem);
			}

		} while (sLine != null);

		return true;
	}

}