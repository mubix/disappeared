/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.util.Vector;
import java.io.*;

public class Account implements Serializable {

	private String m_sHash;

	private String m_sUser;

	private String m_sPassword;

	private int m_nState = 0;

	private Vector m_oRoles;

	public static final int ACCOUNT_STATUS_LOCKED = 28000;

	public static final int ACCOUNT_STATUS_VALID = 0;

	public static final int ACCOUNT_STATUS_UNKNOWN = -1;

	public Account(String sUser, String sPass, String sHash, int nState) {

		m_sUser = sUser;
		m_sPassword = sPass;
		m_nState = nState;
		m_sHash = sHash;
	}

	public Account() {

	}

	public Object clone() {
		Account oA1;

		oA1 = new Account();
		oA1.m_sHash = this.m_sHash;
		oA1.m_sUser = this.m_sUser;
		oA1.m_sPassword = this.m_sPassword;
		oA1.m_nState = this.m_nState;

		if (m_oRoles != null)
			oA1.m_oRoles = (Vector) this.m_oRoles.clone();
		else
			oA1.m_oRoles = null;

		return oA1;
	}

	public int getState() {
		return m_nState;
	}

	public String getUsername() {
		return m_sUser;
	}

	public String getHash() {
		return m_sHash;
	}

	public String getPassword() {
		return m_sPassword;
	}

	public void setHash(String s) {
		m_sHash = s;
	}

	public void setState(int n) {
		m_nState = n;
	}

	public void setPassword(String s) {
		m_sPassword = s;
	}

	public Vector getRoles() {
		return m_oRoles;
	}

	public void setRoles(Vector v) {
		m_oRoles = v;
	}

	public String getRolesAsString() {

		String sRoles = "";

		if (m_oRoles == null)
			return "";

		for (int i = 0; i < m_oRoles.size(); i++) {
			sRoles += (String) m_oRoles.get(i);

			if (i + 1 < m_oRoles.size())
				sRoles += ",";
		}

		return sRoles;

	}

	public String getAsString() {

		String sAccount = m_sUser + "/" + m_sPassword; // + "@" + m_sSID;

		if (m_nState == ACCOUNT_STATUS_VALID)
			sAccount += " [ok]";
		else if (m_nState == ACCOUNT_STATUS_LOCKED) {
			sAccount += " [locked]";
		}

		return sAccount;
	}

}