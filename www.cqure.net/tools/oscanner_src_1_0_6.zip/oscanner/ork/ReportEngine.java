/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.util.*;

public class ReportEngine {

	private final int TYPE_TXT = 1;

	private int m_nType = TYPE_TXT;

	private Vector oResVector = null;

	public ReportEngine(Vector oVector, int nType) {
		oResVector = oVector;
		m_nType = nType;
	}

	public void report() {

		ServerResult oRes = null;
		PluginReport oPlugRep = null;
		Vector oPlugRepList = null;

		if (oResVector == null)
			return;

		for (int i = 0; i < oResVector.size(); i++) {
			oRes = (ServerResult) oResVector.get(i);
			oPlugRepList = oRes.getPluginReportList();

			for (int j = 0; j < oPlugRepList.size(); j++) {
				oPlugRep = (PluginReport) oPlugRepList.get(j);
				System.out.println(oPlugRep.getReportAsTxt());
			}

		}

	}

}