/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.util.*;

public class AccountList extends Hashtable {

	/*
	 * A hashtable where SIDS are put after a successfull oracle account
	 * enumeration in order to tell the next plugin to not perform enumeration
	 */
	private Hashtable m_oSIDEnum = new Hashtable();

	public void outputAsTxt() {

	}

	/*
	 * Sets a flag telling the plugin Oracle account enumeration has already
	 * been done for this account
	 */
	public void setAccountsEnumeratedForSID(String s) {

		if (m_oSIDEnum.get(s) == null)
			m_oSIDEnum.put(s, new Integer(1));

	}

	/*
	 * Checks wheter Oracle account enumeration has been performed on this SID
	 */
	public boolean isAccountsEnumeratedForSID(String s) {
		if (m_oSIDEnum.get(s) != null)
			return true;

		return false;
	}

	/*
	 * Returns a vector with all accounts for the given SID
	 */
	public Vector getAccountsForSID(String s) {
		return (Vector) get(s);
	}

	public Vector getAccountsWithStateForSID(int nState, String sSID) {

		Vector oVec = null;
		int i = 0;

		if (get(sSID) == null) {
			return null;
		}

		oVec = (Vector) ((Vector) get(sSID)).clone();

		do {
			if (((Account) oVec.get(i)).getState() != nState)
				oVec.remove(i);
			else
				i++;
		} while (i < oVec.size());

		return oVec;

	}

	public Vector getOpenAccountsForSID(String s) {
		return getAccountsWithStateForSID(Account.ACCOUNT_STATUS_VALID, s);
	}

	public Vector getUknownAccountsForSID(String s) {
		return getAccountsWithStateForSID(Account.ACCOUNT_STATUS_UNKNOWN, s);
	}

	public Vector getLockedAccountsForSID(String s) {
		return getAccountsWithStateForSID(Account.ACCOUNT_STATUS_LOCKED, s);
	}

	public Account getAccountWithRole(String sSID, String sRole) {

		Vector oAccVector = getOpenAccountsForSID(sSID);
		Vector oRoles = null;
		Account oA;
		String sTmpRole;

		if (oAccVector == null)
			return null;

		for (int i = 0; i < oAccVector.size(); i++) {
			oA = (Account) oAccVector.get(i);

			if ((oRoles = oA.getRoles()) == null)
				return null;

			for (int j = 0; j < oRoles.size(); j++) {
				sTmpRole = (String) oRoles.get(j);

				if (sTmpRole.equalsIgnoreCase(sRole))
					return oA;
			}

		}

		return null;

	}

	public Vector getAllAccountsForRole(String sSID, String sRole) {

		Vector oAccVector = getOpenAccountsForSID(sSID);
		Vector oRoles = null;
		Account oA;
		String sTmpRole;
		Vector oTmp = new Vector();

		if (oAccVector == null)
			return null;

		for (int i = 0; i < oAccVector.size(); i++) {
			oA = (Account) oAccVector.get(i);

			if ((oRoles = oA.getRoles()) == null)
				continue;

			for (int j = 0; j < oRoles.size(); j++) {
				sTmpRole = (String) oRoles.get(j);

				if (sTmpRole.equalsIgnoreCase(sRole)) {
					oTmp.add(oA);
				}

			}

		}

		return oTmp;

	}

	/*
	 * Returns an Account for the giver user/sid combination
	 */
	public Account getAccountForUsername(String sUser, String sSID) {

		Vector oV = null;
		Account oA = null;

		oV = (Vector) get(sSID);

		if (oV == null)
			return null;

		for (int i = 0; i < oV.size(); i++) {
			oA = (Account) oV.get(i);

			if (oA.getUsername().equalsIgnoreCase(sUser)) {
				return oA;
			}

		}

		return null;

	}

	/*
	 * Tries to consolidate properties of two account objects
	 */
	private Account consolidateAccountInfo(Account oA1, Account oA2) {

		Account oA3;
		LinkedHashSet oSet;
		int nCounter = 1, nPos = -1;

		oA3 = (Account) oA1.clone();

		if (oA3.getPassword() == null)
			oA3.setPassword(oA2.getPassword());

		if (oA3.getHash() == null)
			oA3.setHash(oA2.getHash());

		if (oA3.getState() == Account.ACCOUNT_STATUS_UNKNOWN)
			oA3.setState(oA2.getState());

		/* This is not correct and brakes stuff */
		if (oA3.getRoles() != null || oA2.getRoles() != null) {

			oSet = new LinkedHashSet();

			if (oA3.getRoles() != null)
				oSet.addAll(oA3.getRoles());

			if (oA2.getRoles() != null)
				oSet.addAll(oA2.getRoles());

			/* Debbuging information */
			/*
			 * System.out.println("oA2=" + oA2.getRoles().toString());
			 * System.out.println("oA3=" + oA3.getRoles().toString());
			 * System.out.println("oSet=" + oSet.toString());
			 */

			oA3.setRoles(new Vector(oSet));
		}

		return oA3;

	}

	/*
	 * Adds account information for a given SID
	 */
	public void addAccountForSID(String sSID, Account oA) {

		/* Get vector for SID */
		Vector oV = null;
		Account oTmp = null;
		boolean bSet = true;

		if ((oV = (Vector) get(sSID)) == null) {
			oV = new Vector();
			put(sSID, oV);
		}

		for (int i = 0; i < oV.size(); i++) {
			oTmp = (Account) oV.get(i);

			if (oA.getUsername().equalsIgnoreCase(oTmp.getUsername())) {
				oV.set(i, consolidateAccountInfo(oA, oTmp));
				bSet = false;
			}

		}

		if (bSet)
			oV.add(oA);

	}

}