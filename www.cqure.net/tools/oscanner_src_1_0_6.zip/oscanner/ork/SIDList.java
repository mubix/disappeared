/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.util.*;

public class SIDList extends FileListLoader {

	private String m_sHostname = null;

	private int m_nPort = 1521;

	private int m_nError = OK;

	public static final int ERROR_HOST_NOT_FOUND = -1000;

	public static final int ERROR_CONNECTION_FAILED = -1001;

	public static final int ERROR_GETSIDS_FAILED = -1002;

	public static final int OK = 0;

	public SIDList() {
		super();
	}

	public SIDList(String sHost, int nPort) {
		m_sHostname = sHost;
		m_nPort = nPort;
	}

	public void dumpSIDs() {
		System.err.println("SIDs");
		System.err.println("====");

		for (int i = 0; i < this.size(); i++) {
			System.err.println((String) this.get(i));
		}
	}

	public void setHostname(String sHostname) {
		m_sHostname = sHostname;
	}

	public void setPort(int nPort) {
		m_nPort = nPort;
	}

	public String getNextSID() {
		return getNextItem();
	}

	public String getErrorMessage() {

		if (m_nError == ERROR_CONNECTION_FAILED)
			return "Connetion to server failed";
		else if (m_nError == ERROR_HOST_NOT_FOUND)
			return "The host was not found";
		else if (m_nError == ERROR_GETSIDS_FAILED)
			return "Failed to retrieve sids";
		else
			return "";

	}

	public int retrieveSids() {

		OracleTNSSocket oTNSSock = null;
		Vector oTmp;

		if (m_sHostname == null)
			m_nError = ERROR_HOST_NOT_FOUND;

		oTNSSock = new OracleTNSSocket(m_sHostname, m_nPort);

		if (!oTNSSock.connect()) {
			m_nError = ERROR_CONNECTION_FAILED;
		}

		oTmp = oTNSSock.getOracleSIDS();
		oTNSSock.close();

		if (oTmp == null || oTmp.size() == 0)
			return ERROR_GETSIDS_FAILED;

		for (int i = 0; i < oTmp.size(); i++) {
			this.add((String) oTmp.get(i));
		}

		return m_nError;
	}

}