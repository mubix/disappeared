/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

public class PluginReport {

	private String m_sHeading;

	private String m_sBody;

	private String m_sSID;

	private String m_sHost;

	public PluginReport() {

	}

	public void setSID(String s) {
		m_sSID = s;
	}

	public void setHost(String h) {
		m_sHost = h;
	}

	public void setHeader(String h) {
		m_sHeading = h;
	}

	public void setBody(String b) {
		m_sBody = b;
	}

	public String getHeading() {
		return m_sHeading;
	}

	public String getReportAsTxt() {
		String sRep = "";

		sRep = m_sHeading + "\n";

		for (int i = 0; i < m_sHeading.length(); i++)
			sRep += "=";

		sRep += "\n" + m_sBody + "\n";

		return sRep;

	}

}