/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.sql.*;
import java.io.*;

public class FmtResultSet {

	private ResultSet m_oRS = null;

	private int m_nColumns = -1;

	private String m_sDelimiter = " | ";

	public FmtResultSet(ResultSet oRS) {
		m_oRS = oRS;
	}

	public void setDelimiter(String sDelimiter) {

		if (sDelimiter != null && sDelimiter.length() > 0)
			m_sDelimiter = sDelimiter;

	}

	public void close() {

		try {
			if (m_oRS != null)
				m_oRS.close();

			m_oRS = null;
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void outputHeaders(PrintStream oPS) {

		String sHeader = "";

		if (m_oRS != null) {

			try {

				ResultSetMetaData oRSMD = m_oRS.getMetaData();
				m_nColumns = oRSMD.getColumnCount();

				for (int nColumn = 1; nColumn <= m_nColumns; nColumn++) {
					sHeader += oRSMD.getColumnName(nColumn);

					/* only add delimiter if it is not the last column */
					if (nColumn != m_nColumns)
						sHeader += m_sDelimiter;
				}

				oPS.println(sHeader);

			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}

	public void outputData(PrintStream oPS) {

		if (m_oRS == null)
			return;

		try {

			while (m_oRS.next()) {
				for (int i = 1; i <= m_nColumns; i++) {
					oPS.print(m_oRS.getString(i));

					if (i != m_nColumns)
						oPS.print(m_sDelimiter);

				}

				oPS.println();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}