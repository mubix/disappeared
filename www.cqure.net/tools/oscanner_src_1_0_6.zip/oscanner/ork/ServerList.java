/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the oscanner framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

package ork;

import java.io.*;
import java.util.Vector;

public class ServerList extends Vector {

	public static final int ERROR_FILE_NOT_FOUND = -1000;

	public static final int ERROR_READ_FAILURE = -1001;

	public static final int OK = 0;

	private int m_nPos = 0;

	public ServerList() {
		super();
	}

	public void addServer(String s) {
		add(s);
	}

	public int getServerCount() {
		return this.size();
	}

	public void reset() {
		m_nPos = 0;
	}

	public String getNextServer() {

		String sServer = null;

		if (m_nPos < this.size()) {
			sServer = (String) this.get(m_nPos);
			m_nPos++;
		}

		return sServer;

	}

	public int loadServerList(String sFilename) {

		String sServer;
		LineNumberReader oReader = null;

		try {
			oReader = new LineNumberReader(new FileReader(sFilename));

			while ((sServer = oReader.readLine()) != null) {
				add(sServer);
			}
		} catch (Exception e) {
			return ERROR_READ_FAILURE;
		}

		return OK;

	}

}