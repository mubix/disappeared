#!/bin/sh
java -cp .:lib/*:bin/* net.cqure.MSSQLScan $*
