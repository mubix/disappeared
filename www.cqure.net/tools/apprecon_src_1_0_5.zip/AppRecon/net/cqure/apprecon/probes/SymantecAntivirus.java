/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the AppRecon framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * Created on Oct 17, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.cqure.apprecon.probes;

import java.nio.ByteBuffer;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SymantecAntivirus extends BaseProbe {

	private final int PROBE_PORT = 38293;
	private final byte[] PROBE_BUFFER = new byte[] {0x02,0x0a,0x00,(byte)0xc0,0x48,0x69,0x43,0x4d,
            										0x48,0x69,0x43,0x4d,0x00,0x00,0x00,0x00};
	private final String APPLICATION_NAME = "Symantec Antivirus Corporate Edition"; 

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#getProbePort()
	 */
	public int getProbePort() {
		// TODO Auto-generated method stub
		return PROBE_PORT;
	}

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#getProbeBuffer()
	 */
	public byte[] getProbeBuffer() {
		// TODO Auto-generated method stub
		return PROBE_BUFFER;
	}

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#parseResponse(byte[])
	 */
	/*
	 * Hmm.. The Lic and Workgroup part does not seem to be correct ...
	 */
	
	public String parseResponse(byte[] b, int l) {
		
		int nOffset = 0, nWrkGrpOffset = 0, nNameOffset = 0;
		int nLicOffset = 0;
		String sWrkGroup = "", sComputerName = "", sLicense = "";
		ByteBuffer oBB = null;

		if ( b.length < 450 )
			return null;
		
		nOffset = b[18];
		nWrkGrpOffset = nOffset + 12;
		nNameOffset = nOffset + 108;
		nLicOffset = nOffset + 156;

		oBB = ByteBuffer.allocate(16);
		oBB.put(b, nWrkGrpOffset, 16);
		sWrkGroup = new String( oBB.array() );

		oBB = ByteBuffer.allocate(16);
		oBB.put(b, nNameOffset, 16);
		sComputerName = new String( oBB.array() );
		
		oBB = ByteBuffer.allocate(20);
		oBB.put(b, nLicOffset, 20 );
		sLicense = new String( oBB.array() );
		
		return new String("Computer: " + sComputerName ); //+ "; Workgroup: " + sWrkGroup + "; License:" + sLicense);
	}

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#getAppName()
	 */
	public String getAppName() {
		// TODO Auto-generated method stub
		return APPLICATION_NAME;
	}

}
