/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the AppRecon framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * Created on Sep 26, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.cqure.apprecon.probes;

import java.nio.ByteBuffer;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PCDuo extends BaseProbe {

	private int PROBE_PORT = 5405;
	private String APPLICATION_NAME = "PCDuo";
	private byte[] PROBE_BUFFER = new byte[] {0x01,0x00,0x00,0x00,0x00,0x00,0x00 +
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
			0x00,0x00,0x00,0x00,(byte)0x80,0x00,0x00,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00 };

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.Prober#getProbePort()
	 */
	public int getProbePort() {
		// TODO Auto-generated method stub
		return PROBE_PORT;
	}
	
	public String getAppName() { return APPLICATION_NAME; }

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.Prober#getProbeBuffer()
	 */
	public byte[] getProbeBuffer() {
		// TODO Auto-generated method stub
		return PROBE_BUFFER;
	}

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.Prober#parseResponse(byte[])
	 */
	public String parseResponse(byte[] b, int l) {
		
		ByteBuffer oBB = null;
		String sComputer = null, sUser = null;
		
		if ( b.length == 0 )
			return null;
		
		oBB = ByteBuffer.allocate( b.length );
		
		if ( b.length > 2 ) {
			oBB.put( b, 2, b.length - 3);
			sComputer = new String( oBB.array() );
			
			if ( sComputer.indexOf('\0') > 0 )
				sComputer = sComputer.substring(0, sComputer.indexOf('\0'));
		}
		
		if ( b.length > 26 ) {
			oBB = ByteBuffer.allocate( b.length );
			oBB.put( b, 26, b.length - 26);
			sUser = new String( oBB.array() );
			
			/* Do we have a username ??*/
			if ( sUser.indexOf( '\0' ) == 0 )
				sUser = "";
			else if ( sUser.indexOf( '\0' ) > 0 )
				sUser = sUser.substring(0, sUser.indexOf('\0'));
			
			sUser = sUser.replace('|','\\');
		}
		
		return "Computer: " + sComputer + " User: " + sUser;
	}

}
