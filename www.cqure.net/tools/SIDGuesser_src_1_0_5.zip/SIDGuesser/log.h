int openlogfile( char * );
int logprintf( const char *, ... );
void closelogfile();
