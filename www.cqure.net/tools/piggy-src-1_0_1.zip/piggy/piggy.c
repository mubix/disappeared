/*
   Piggy
   Copyright (c) 2006- Patrik Karlsson

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#include <stdlib.h>
#include <stdio.h>

#include <winsock2.h>
#include <windows.h>
#include <time.h>

#include <Sql.h>
#include <Sqlext.h>
#include <Sqltypes.h>

#include "getopt.h"
#include "piggy.h"

#pragma comment( lib, "ws2_32.lib" )

struct Dictionary_t *addDictionaryItem( struct Dictionary_t *pDIC, char *pItem ) {
	
	struct Dictionary_t *pNew;
	int nLen = (int)strlen( pItem ) + 1;

	pNew = ( struct Dictionary_t * ) malloc( sizeof( struct Dictionary_t ) );
	pNew->pItem = (char *)malloc( nLen );

	memset( pNew->pItem, 0, nLen );
	strcpy( pNew->pItem, chomp( pItem ) );

	pNew->next = pDIC;
	pDIC = pNew;

	return pDIC;

}

struct SQLInit_t *MSSQLInit( struct SQLInit_t *SQLInit ) {

	RETCODE ret;
	
	SQLInit->hdbc = SQL_NULL_HDBC;
	SQLInit->henv = SQL_NULL_HENV;

	// error checking?
	if ( SQL_ERROR == ( ret = SQLAllocHandle (SQL_HANDLE_ENV, NULL, &SQLInit->henv) ) ) {
		fprintf(stderr,"ERROR: SQLAllocHandle failed\n");
		return NULL;
	}
    
	if ( SQL_ERROR == ( ret = SQLSetEnvAttr(SQLInit->henv, SQL_ATTR_ODBC_VERSION, 
											(SQLPOINTER) SQL_OV_ODBC3, SQL_IS_INTEGER) ) ) {
		fprintf(stderr,"ERROR: SQLSetEnvAttr ODBC Version failed\n");
		return NULL;
	}
    
	if ( SQL_ERROR == ( ret = SQLAllocHandle(SQL_HANDLE_DBC, SQLInit->henv, &SQLInit->hdbc) ) ) {
		fprintf(stderr, "ERROR: SQLAllocHandle failed\n");
		return NULL;
	}

	if ( SQL_ERROR == ( ret = SQLSetConnectAttr(SQLInit->hdbc, SQL_LOGIN_TIMEOUT, (void *)5, 0) ) ) {
		fprintf(stderr,"ERROR: SQLSetConnectAttr Failed\n");
		return NULL;
	}

	return SQLInit;
}

int MSSQLLogin( struct SQLInit_t SQLInit, CHAR *pSRV, CHAR *pUID, CHAR *pPWD ) {

	SQLCHAR state[10], msg[1024], szOutConn[1024];
	SQLSMALLINT msgLen, szint;
	SQLINTEGER err;
	char constr[1024];
	RETCODE ret;

	// Build connection string to pass to ODBC driver
	_snprintf(constr,sizeof(constr),"DRIVER={SQL Server};SERVER=%s;Address=%s;UID=%s;PWD=%s", pSRV, pSRV, pUID, pPWD ); 

	if ( m_nVerbose )
		fprintf(stdout, "TRYING [SRV=%s;UID=%s;PWD=%s]\n", pSRV, pUID, pPWD );

	// Connect to server
	if ( SQL_ERROR == ( ret = SQLDriverConnect(SQLInit.hdbc, NULL, (SQLTCHAR*)constr, 
												SQL_NTS, szOutConn, 1024, &szint, 
												SQL_DRIVER_NOPROMPT) ) ) {	
	
		SQLGetDiagRec(SQL_HANDLE_DBC, SQLInit.hdbc, 1, state,  &err, msg, sizeof( msg ), &msgLen );
		
		/* Never show unsuccessfull login attempts */
		if ( err != 18456 ) 
			fprintf( stderr, "ERROR (%s): %s\n", pSRV, msg );
	}
	else {
		fprintf( stderr, "FOUND [SERVER=%s;UID=%s;PWD=%s]\n", pSRV, pUID, pPWD );
		SQLDisconnect( SQLInit.hdbc );
	}

	return 0;
}

void SQLFreeResources(struct SQLInit_t SQLInit ) {
	SQLFreeHandle( SQL_HANDLE_ENV, SQLInit.henv );
	SQLFreeHandle( SQL_HANDLE_DBC, SQLInit.hdbc );
}

struct Dictionary_t *ReverseDictionary( struct Dictionary_t *pDIC ) {
	
	struct Dictionary_t *prev, *cur, *next;

	prev = NULL;
	cur = pDIC;

	while ( cur ) {
		next = (struct Dictionary_t *)cur->next;
		cur->next = prev;
		prev = cur;
		cur = next;
	}

	pDIC = prev;

	return pDIC;

}

struct Dictionary_t *LoadDictionary( CHAR *pFName ) {
	
	FILE *pFD;
	char buf[1024];
	struct Dictionary_t *pDIC = NULL;

	if ( NULL == ( pFD = fopen( pFName, "r" ) ) )
		return NULL;

	ZeroMemory( buf, sizeof( buf ) );

	while ( fgets( buf, sizeof( buf ) - 1, pFD ) )
		pDIC = addDictionaryItem( pDIC, chomp(buf) );

	return ReverseDictionary(pDIC);
}

char *chomp( char *pStr ) {

	int nLen = (int)strlen( pStr );

	if ( nLen < 1 )
		return "";

	while ( nLen > 0 ) {
		nLen --;
		if ( '\r' == pStr[nLen] || '\n' == pStr[nLen] )
			pStr[nLen] = 0;
	}
	
	return pStr;
}

long CountDictionaryItems( struct Dictionary_t *p ) {

	long lCounter = 1;

	while ( p = (struct Dictionary_t *)p->next )
		lCounter ++;

	return lCounter;
}

BOOL TCPPing( char *pHost, short *nPort, int nCount ) {

	SOCKET *s;
	struct sockaddr_in sin;
	struct timeval tm;
	unsigned long l=1;
	int i = 0, n=0;
	fd_set	wfds;
	BOOL bRet = FALSE;
	
	s = (SOCKET *)malloc( nCount * sizeof( SOCKET ) );
	FD_ZERO(&wfds);
		
	for( i=0; i<nCount; i++ ) {

		s[i] = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
		
		sin.sin_family = AF_INET;
		sin.sin_port = htons( nPort[i] );
		sin.sin_addr.s_addr = inet_addr( pHost );
		
		l=1;
		if ( 0 != ioctlsocket(s[i], FIONBIO, &l) )
			return FALSE;
		
		connect( s[i], (struct sockaddr *)&sin, sizeof( sin ) );
		FD_SET( s[i], &wfds );	

	}

	tm.tv_sec  = m_nTimeout;
	tm.tv_usec = 0;

	if ( 0 < ( n = select( 0, NULL, &wfds, NULL, &tm ) ) ) {
		bRet = TRUE;
	}

	for( i=0; i<nCount; i++ )
		closesocket( s[i] );

	free( s );

	return bRet;
}

void FreeServerListItems( struct ServerList_t *pList ) {

	struct ServerList_t *rmv, *cur = pList;

	while ( cur ) {
		rmv = cur;
		cur = cur->next;
		free(rmv);
	}

}

struct ServerList_t *CheckServerAvailability( struct ServerList_t *pList ) {

	short ports[] = {1433, 139, 445};
	struct hostent *pHe;
	struct in_addr *pIP;
	struct ServerList_t *pNew = NULL, *pCur = pList;
	BOOL bActive = FALSE;

	fprintf( stdout, "[i] Checking server availability\n");

	while ( pCur ) {
	
		if ( m_nVerbose )
			fprintf( stderr, "INFO: TCP pinging host %s\n", pCur->pItem );

		pHe = gethostbyname( pCur->pItem );
		
		if ( pHe ) {
		
			bActive = FALSE;

			while( NULL != ( pIP=(struct in_addr *)*(pHe->h_addr_list) ++ ) ) {
		
				if ( !TCPPing( inet_ntoa(*pIP), ports, sizeof( ports ) / sizeof( short ) ) ) {
					fprintf( stderr, "Server '%s' is down\n", inet_ntoa(*pIP) );
				}
				else {
					bActive = TRUE;
					break;
				}
		
			}
		
		
			if ( bActive ) 
				pNew = (struct ServerList_t *)addServerListItem( pNew, pCur->pItem );
		
		}
		else
			printf( "[x] Failed to resolve %s\n", pCur->pItem );

		pCur = pCur->next;
	}

	FreeServerListItems( pList );

	return pNew;
}

DWORD WINAPI ShowStats( LPVOID lpParam ) {

	char ch;
	double nDeltaTM, nTPS;
	time_t nStartTM;
	struct Stats_t *pStats = (struct Stats_t *)lpParam;

	int nMinutes, nHours, nSeconds = 0;

	nStartTM = clock();

	while( 1 && !m_bQuit ) {

		ch = getch();

		if ( ' ' == ch ) {
			nDeltaTM = ( clock() - nStartTM ) / CLOCKS_PER_SEC;
			nTPS	 = pStats->lCurr/nDeltaTM;

			nHours   = (int) ( nDeltaTM / 3600 );
			nMinutes = (int) ((nDeltaTM - ( nHours * 3600 )) / 60);
			nSeconds = (int) nDeltaTM - ( nHours * 3600 ) - nMinutes * 60;

			fprintf(stderr, "TME: %.2d:%.2d:%.2d ", 
						nHours, nMinutes, nSeconds);
			fprintf(stderr, "TPS: %.0f DONE: %0.f (%0.f%%) CUR: %s\n", nTPS, pStats->lCurr, 
						( pStats->lCurr/pStats->lTotal * 100), pStats->pCurr );
		}
		else if ( 'q' == ch ) {
			fprintf( stdout, "\nAbort? (Y/N)");
			ch = getch();

			if ( 'y' == ch )
				m_bQuit = 1;
			else
				fprintf( stdout, "\ncontinuing ...\n");
		}
	}


	return 0;
}

void DoAccountTest( struct SQLInit_t SQLInit, struct ServerList_t *pSrv, struct AccountList_t *pAcc ) {
		
	char user[256], pass[256];
	struct AccountList_t *pA;
	struct Stats_t stats;
	char *p;
	DWORD dwTID;

	stats.lTotal = CountDictionaryItems( pAcc );
	stats.lCurr = 1;
	CreateThread( NULL, 0, ShowStats, &stats, 0, &dwTID );

	while ( pSrv ) {

		printf( "[i] Started scan against DB on '%s'\n", pSrv->pItem );
		pA = pAcc;

		while( !m_bQuit ) {

			if ( sizeof( user ) < strlen( pA->pItem ) ) {
				fprintf( stderr, "ERROR: Overflow when splitting\n" );
				continue;
			}
			
			ZeroMemory( user, sizeof( user ) );
			ZeroMemory( pass, sizeof( pass ) );
			
			if ( NULL != pA->pItem ) {
				stats.pCurr = pA->pItem;			
				p = strstr(	pA->pItem, ";" );
				strncpy( user, pA->pItem, p - pA->pItem );
				strncpy( pass, p+1, strlen( pA->pItem ) - ( p - pA->pItem ) );
			}

			MSSQLLogin( SQLInit, pSrv->pItem, user, pass );
				
			if ( NULL == (pA = (struct AccountList_t *)pA->next) )
				break;
		
			stats.lCurr ++;
		}

		pSrv = pSrv->next;
	}

}
	
void DoDictionary( struct SQLInit_t SQLInit, struct ServerList_t *pSrv, char *pUSR, struct Dictionary_t *pDic ) {

	struct Dictionary_t *pD;
	DWORD dwTID;
	struct Stats_t stats;

	if ( NULL == pDic || NULL == pSrv)
		return;

	stats.lTotal = CountDictionaryItems( pDic );
	stats.lCurr = 1;
	CreateThread( NULL, 0, ShowStats, &stats, 0, &dwTID );

	while ( pSrv ) {

		printf( "Started scan against DB on '%s'\n", pSrv->pItem );
		pD = pDic;

		while( !m_bQuit ) {
		
			if ( NULL != pD->pItem ) {
				stats.pCurr = pD->pItem;
				MSSQLLogin( SQLInit, pSrv->pItem, pUSR, pD->pItem );
			}
			
			if ( NULL == (pD = (struct Dictionary_t *)pD->next) )
				break;

			stats.lCurr ++;
		}

		pSrv = pSrv->next;
	}

}

void banner() {
	
	int i, nLen;
	
	printf("\n");
	nLen = printf("Piggy %s by %s\n", VERSION, AUTHOR );
	for( i=0; i<nLen-1; i++ )
		printf( "-" );
	printf("\n");
}

void usage(CHAR *pPRG) {
	
	banner();
	printf( "usage: %s [options]\n", pPRG);
	printf( "\n" );
	printf( "options:\n" );
	printf( "   -u <username> - Single username\n" );
	printf( "   -p <password> - Single password\n" );
	printf( "   -s <server>   - Single server\n" );
	printf( "   -S <srvfile>  - File containing ip/hostnames\n" );
	printf( "   -D <dicfile>  - File containing passwords\n" );
	printf( "   -A <accounts> - File containing username;password combinations\n");
	printf( "   -N            - Do not check availability before scan\n");
	printf( "   -v verbose    - Verbose logging\n" );

	printf( "\n" );
}


int main( int argc, char **argv ) {

	int i = 0, c = 0, bNoPing = FALSE;
	struct Dictionary_t *pDictionary = NULL;
	struct ServerList_t *pSrvList = NULL;
	struct AccountList_t *pAccounts = NULL;
	struct SQLInit_t SQLInit;
	char user[255];

	struct WSAData wsa;

	memset( user, 0, sizeof( user ) );

	while( TRUE ) {

		c = getopt( argc, argv, "s:u:p:D:vS:NA:" );

		if ( -1 == c ) {
			break;
		}
	
		switch(c) {	
			
			case 's':
				pSrvList = (struct ServerList_t *)addServerListItem( pSrvList, optarg );
				break;
			case 'S':
				pSrvList = (struct ServerList_t *)LoadServerList( optarg );
				if ( NULL == pSrvList ) {
					fprintf( stderr, "ERROR: Failed to load server list %s\n", optarg );
					return (-1);
				}
				break;
			case 'u':
				strncpy( user, optarg, sizeof( user ) - 1);
				break;
			case 'p':
				pDictionary = addDictionaryItem( pDictionary, optarg );
				break;
			case 'D':
				pDictionary = LoadDictionary( optarg );
				if ( NULL == pDictionary ) {
					fprintf( stderr, "ERROR: Failed to load dictionary %s\n", optarg );
					return -1;
				}
				break;
			case 'A':
				pAccounts = LoadAccountList( optarg );
				if ( NULL == pAccounts ) {
					fprintf( stderr, "ERROR: Failed to load accountlist %s\n", optarg );
					return -1;
				}
				break;
			case 'v':
				m_nVerbose ++;
				break;
			case 'N':
				bNoPing = TRUE;
				break;
			default:
				usage(argv[0]);
				exit(1);
				break;
		}
	}

	if ( NULL == pSrvList ) {
		usage( argv[0] );
		return -1;
	}

	if ( 0 == strlen( user ) && NULL == pAccounts ) {
		usage( argv[0] );
		return -1;
	}

	if ( NULL == pDictionary && NULL == pAccounts ) {
		usage( argv[0] );
		return -1;
	}

	if ( pDictionary && pAccounts ) {
		fprintf( stderr, "Conflicting modes selected (Account,Dictionary)\n");
		return -1;
	}

	if ( 0 < strlen( user ) && pAccounts ) {
		fprintf( stderr, "Conflicting arguments (User,Account)\n");
		return -1;
	}

	banner();

	if ( NULL != pDictionary )
		fprintf( stdout, "[i] Loaded %d dictionary items\n", CountDictionaryItems( pDictionary ) );

	if ( NULL == ( MSSQLInit( &SQLInit ) ) ) {
		fprintf( stderr, "ERROR: Failed to initialize ODBC connection\n");
	}

	WSAStartup( MAKEWORD( 2, 0 ), &wsa );

	if ( !bNoPing )
		pSrvList = CheckServerAvailability( pSrvList );
	
	if ( pDictionary ) {
		DoDictionary( SQLInit, pSrvList, user, pDictionary );
	}
	else {
		DoAccountTest( SQLInit, pSrvList, pAccounts );
	}

	SQLFreeResources( SQLInit );
	WSACleanup();

	FreeServerListItems( pSrvList );
	FreeDictionaryListItems( pDictionary );
	FreeAccountListItems( pAccounts );
}