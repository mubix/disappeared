/*
   Piggy
   Copyright (c) 2006- Patrik Karlsson

   http://www.cqure.net

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#define MAXBUFLEN   255
#define MAX_CONN_OUT 1024

struct Dictionary_t {
	char *pItem;
	void *next;
};

struct ServerList_t {
	char *pItem;
	void *next;
	void *prev;
};

struct AccountList_t {
	char *pItem;
	void *next;
};

struct SQLInit_t {
	SQLHENV henv;
	SQLHDBC hdbc;     
};

struct Stats_t {
	double lCurr;
	double lTotal;
	CHAR *pCurr;
};

int m_nVerbose = FALSE;
int m_nTimeout = 5;

int m_bQuit = FALSE;

#define LoadAccountList(a) (struct AccountList_t *)LoadDictionary(a);
#define LoadServerList(a) LoadDictionary(a);
#define addServerListItem(a, b) (struct Dictionary_t*)addDictionaryItem((struct Dictionary_t*)a,b);
#define addAccountListItem(a, b) addDictionaryItem(a,b);

#define FreeDictionaryListItems(a) FreeServerListItems((struct ServerList_t*)a)
#define FreeAccountListItems(a) FreeServerListItems((struct ServerList_t*)a)

#define CountAccountItems(a) CountDictionaryItems(a)

const CHAR *VERSION = "v1.0.1";
const CHAR *AUTHOR  = "patrik@cqure.net";

char *chomp( char * );
void banner();

