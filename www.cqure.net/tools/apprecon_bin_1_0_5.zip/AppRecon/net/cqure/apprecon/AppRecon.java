/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the AppRecon framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * Created on Sep 18, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.cqure.apprecon;

import gnu.getopt.Getopt;
import java.util.Vector;
import java.lang.reflect.Constructor;
import net.cqure.apprecon.utils.FileListLoader;
import net.cqure.apprecon.probes.*;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 * 2004.10.14 - Consider adding the possibility to target probes
 * 				against a supplied ip list !?
 * 
 * BUGS: When multiple devices are available broadcasts are sent to
 *       the wrong "device".
 * 
 */

public class AppRecon {

	public static Vector m_oPlugins = new Vector(); 
	public static int MAX_RUNNERS = 5;
	public static boolean bVerbose = false;
	
	private static String m_sVersion = "1.0.5";
	private static String m_sAuthor  = "patrik@cqure.net";
	
	private static String m_sIp = null;
	
	public static void loadPlugins( ) {

		FileListLoader oPlugins = new FileListLoader("pluginlist.txt");
		String sPlug = null;
		
		Class oCl = null;
		Constructor oCt = null;
		Object oProbe = null;

		if ( oPlugins.loadFromFile() != FileListLoader.OK ) {
			System.err.println("[e] Failed to read from pluginlist.txt");
			return;
		}
		
		while( ( sPlug = oPlugins.getNextItem() ) != null ) {

			try {
				oCl = Class.forName(sPlug);
			}
			catch( ClassNotFoundException e ) {
				System.err.println("[E] Failed to load plugin: " + sPlug );
			}
			
			try {
				oCt = oCl.getConstructor(new Class[] {} );
				oProbe = oCt.newInstance(new Object[] {});
			}
			catch(Exception e) {
				System.err.println("[E] Failed to instantiate plugin");
			}
		
			m_oPlugins.add(oProbe);
		}
	}
	
	public static void sleep(long nMillis) {
		try {
			Thread.sleep( nMillis );
		}
		catch( InterruptedException e ) {
			e.printStackTrace();
		}
	}
	
	public static void startPlugins( ) {

		BaseProbe oPlug;
		
		for ( int i=0; i<m_oPlugins.size(); i++ ) {
			
			while ( BaseProbe.running > MAX_RUNNERS )
				sleep(1000);
			
			if ( bVerbose )
				System.err.println("[i] Starting plugin " + ((BaseProbe)m_oPlugins.get(i)).getAppName() );
			
			oPlug = (BaseProbe)m_oPlugins.get(i);
			
			if ( m_sIp != null )
				oPlug.setProbeAddress( m_sIp );
			
			oPlug.start();
		}
		
		sleep(1000);
		
	}
	
	public static void showResults() {

		ReconResponse[] oResp;
		String sApp = null, sPlug = null;

		while ( BaseProbe.running > 0 )
			sleep(1000);
	
		for ( int i=0; i<m_oPlugins.size(); i++ ) {		
			oResp = ((BaseProbe)m_oPlugins.get(i)).getReconResponse();
			sApp = ((BaseProbe)m_oPlugins.get(i)).getAppName();

			if ( oResp.length > 0 ) {
				System.out.println("");
				System.out.println("Results for "+sApp);
				
				for( int j=0; j<sApp.length() + 12; j++ )
					System.out.print("=");
				
				System.out.println("");
			}
			else if ( bVerbose )
				System.out.println("[i] Got no results from " + sApp );
			
			for ( int k=0; k<oResp.length; k++ )
				System.out.println( oResp[k].getIP() + "=>" + oResp[k].getData() );

			
		}
	
		
	}
	
	public static void usage() {
		System.out.println("");
		System.out.println("AppRecon ver. " + m_sVersion + " by " + m_sAuthor ); 
		System.out.println("---------------------------------------");
		System.out.println("apprecon [options]");
		System.out.println("");
		System.out.println("    -h help");
		System.out.println("    -i <ipaddress>");
		//System.out.println("    -d send packets to dest. ip");
		System.out.println();
	}
	
	public static void main(String[] args) {

		int c = -1;
		Getopt oOpt = new Getopt("AppRecon", args, "vs:d:hi:");
		
		/* parse arguments */
		while ((c = oOpt.getopt()) != -1) {

			switch (c) {

			case 'v':
				bVerbose = true;
				break;
				
			case 'h':
				usage();
				System.exit(0);
				
			case 'i':
				m_sIp = oOpt.getOptarg();
				break;

			default:
				usage();
				System.exit(0);
			}

		}

		
		System.out.println("");
		System.out.println("AppRecon ver. " + m_sVersion + " by " + m_sAuthor ); 
		System.out.println("---------------------------------------");
		
		System.err.println("[i] Loading plugins ...");
		loadPlugins();

		System.err.println("[i] Starting plugins ...");		
		startPlugins();
		
		showResults();
	}

}
