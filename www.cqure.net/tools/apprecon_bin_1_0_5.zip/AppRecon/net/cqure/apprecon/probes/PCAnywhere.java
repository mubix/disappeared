/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the AppRecon framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * Created on Oct 17, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.cqure.apprecon.probes;

import java.nio.ByteBuffer;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PCAnywhere extends BaseProbe {

	private final int PROBE_PORT = 5632;
	private final byte[] PROBE_BUFFER = new byte[] {0x4E, 0x51};
	private final String APPLICATION_NAME = "PCAnywhere"; 
	
	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#getProbePort()
	 */
	public int getProbePort() {
		// TODO Auto-generated method stub
		return PROBE_PORT;
	}

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#getProbeBuffer()
	 */
	public byte[] getProbeBuffer() {
		// TODO Auto-generated method stub
		return PROBE_BUFFER;
	}

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#parseResponse(byte[])
	 */
	public String parseResponse(byte[] b, int l) {

		ByteBuffer oBB = null;
		String sComputer = null;
		
		if ( b.length == 0)
			return null;
		
		oBB = ByteBuffer.allocate( l );
		
		if ( b.length > 2 ) {
			oBB.put( b, 2, 24);
			sComputer = new String( oBB.array() );
		}
	
		return sComputer;
	
	}

	/* (non-Javadoc)
	 * @see net.cqure.apprecon.probes.BaseProbe#getAppName()
	 */
	public String getAppName() {
		// TODO Auto-generated method stub
		return APPLICATION_NAME;
	}

}
