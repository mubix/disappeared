/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the AppRecon framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * Created on Sep 26, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.cqure.apprecon.probes;

import java.nio.ByteBuffer;

/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SQLServer extends BaseProbe {
	
	private int PROBE_PORT = 1434;
	private String APPLICATION_NAME = "Microsoft SQL Server";
	private byte[] PROBE_BUFFER = new byte[] { 0x02 };
	
	public int getProbePort() { return PROBE_PORT; }
	public String getAppName() { return APPLICATION_NAME; }
	
	public byte[] getProbeBuffer() {
		return PROBE_BUFFER;
	}
	
	public String parseResponse(byte[] buf, int l) {

		ByteBuffer oBB;
		String s = null;
		int nLen = 1;
		
		if ( buf.length > 3 ) {
			// This aint beautiful.....
			nLen = (int)((( buf[2] & 0xFF ) << 8 ) + ( buf[1] & 0xFF )) - 2;
			oBB = ByteBuffer.allocate( nLen );
			oBB.put( buf, 3, nLen);
			
			s = new String( oBB.array() ) + '\0';
		}
		
		return s;
	}
	
	//public String getDataAsString() { return m_sData; }
	
}
