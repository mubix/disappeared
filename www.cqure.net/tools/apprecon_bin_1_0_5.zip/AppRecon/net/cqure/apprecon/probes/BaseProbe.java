/*
 * Copyright (C) 2004 Patrik Karlsson <patrik@cqure.net>
 * 
 * This file is part of the AppRecon framework
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 */

/*
 * Created on Sep 26, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.cqure.apprecon.probes;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import net.cqure.apprecon.*;
/**
 * @author patrik
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class BaseProbe extends Thread {
	
	public final int STATE_INITIALIZED = 0;
	public final int STATE_SENDING = 1;
	public final int STATE_RECIEVING = 2;
	public final int STATE_FINNISHED = 3;
	
	public static int running = 0; 
	
	protected InetAddress m_oProbeAddr = null;
	
	public ArrayList m_oList = new ArrayList();
	public int m_nState = STATE_INITIALIZED;
	
	public int getState() { return m_nState; }
	
	public BaseProbe() {

		try {
			m_oProbeAddr = InetAddress.getByName( "255.255.255.255" );
		}
		catch( UnknownHostException e ) {
			
		}		
	
		
	}
		
	public boolean setProbeAddress(String s) {

		try {
			m_oProbeAddr = InetAddress.getByName( s );
		}
		catch( UnknownHostException e ) {
			m_nState = STATE_FINNISHED;
			return false;
		}		
		
		m_nState = STATE_FINNISHED;
		return true;
	}
	
	public abstract int getProbePort(); 
	public abstract byte[] getProbeBuffer();
	public abstract String parseResponse( byte[] b, int l);
	public abstract String getAppName();
	
	public void run() {
		probe();
	}
	
	public boolean probe() {
		
		String sResponse = null;
		byte[] probe_buf = getProbeBuffer();
		byte[] recv_buf = new byte[65535];
		int nPos;
		
		DatagramSocket oSocket = null;
		DatagramPacket oProbePacket = null;
		DatagramPacket oResponsePacket = null;
		ReconResponse oRecResp;
		
		running ++;
		
		try {
			
			oSocket = new DatagramSocket();
			
			oSocket.setSoTimeout(5000);
		}
		catch(SocketException e) {
			System.err.println("[e] Failed to create UDP socket");
			m_nState = STATE_FINNISHED;
			running --;
			return false;
		}
		
		oProbePacket = new DatagramPacket( probe_buf, probe_buf.length, m_oProbeAddr, getProbePort() );

		try {
			m_nState = STATE_SENDING;
			oSocket.send( oProbePacket );
			oResponsePacket = new DatagramPacket( recv_buf, recv_buf.length); 
			
			while( true ) {
				m_nState = STATE_RECIEVING;
				oSocket.receive( oResponsePacket );
				
				if ( ( sResponse = parseResponse( oResponsePacket.getData(), oResponsePacket.getLength() ) ) != null ) {
					oRecResp = new ReconResponse();
					oRecResp.setIP( oResponsePacket.getAddress().toString().substring(1) );

					/* Do some hardcore null terminations */
					if ( ( nPos = sResponse.indexOf('\0') ) != -1 )
						if ( sResponse.indexOf(nPos, '\0') != -1 )
							sResponse = sResponse.substring( 0, nPos );
					
					oRecResp.setData( sResponse );
					m_oList.add( oRecResp );
				}
			}
			
		}
		catch( IOException e ) {
			if ( e instanceof SocketTimeoutException ) {
				m_nState = STATE_FINNISHED;
				running --;
				oSocket.close();
				return true;
			}
			else {
				m_nState = STATE_FINNISHED;
				running --;
				System.err.println("[e] An IOException occured");
				oSocket.close();
				return false;
			}
		}
		
	}
	
	public ReconResponse[] getReconResponse() {
		ReconResponse[] oResp = new ReconResponse[m_oList.size()];

		for ( int i=0; i<oResp.length; i++ )
			oResp[i] = (ReconResponse)m_oList.get(i);
		
		return oResp;
	}
}
