/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "debug.h"
#include "netbios.h"
#include "util.h"
#include "smb.h"
#include "smblib.h"
#include "smbgetserverinfo.h"
#include <stdio.h>
#include <stdlib.h>

void usage(char **argv) {

  printf("\n\tSMB - ServerInfo %s ",SMB_SUITE_VERSION);
  printf("by (%s)\n", SMB_SUITE_EMAIL);
  printf("\t-------------------------------------------------");
  printf("--------------------\n");
  printf("\tusage: %s -i [options]\n\n", argv[0]);
  printf("\t\t-i*\tIP address\n");
  printf("\t\t-s\tName of the server\n");
  printf("\t\t-t\ttimeout for connect (default 300ms)\n");
  printf("\t\t-v\tBe verbose\n");
  printf("\t\t-vv\tBe even more verbose\n");
  printf("\n");

}


int main(int argc, char **argv) {

  BRUTEINFO info;
  CMDARGS args;

  /* Temp variables */
  UCHAR tserv[16];  /* Temp storage for info.server */
  char twkgrp[16];  /* Temp storage for info.workgroup */

  int c;

  if ( argc < 3 ) {
    usage(argv);
    exit(1);
  }

  SMBInitialize(&info);

  while (1) {

    c = getopt(argc, argv, "s:i:vht:");

    if ( c == -1 ) 
      break;

    switch (c) {
      
    case 'i':
      if ( strlen(optarg) > 15 )
	exit(1);

      strncpy(info.ip, optarg, 15);
      break;

    case 's':
      if ( strlen(optarg) > 16 )
	exit(1);

      strncpy(info.server, optarg, 16);
      break;

    case 't':
      info.timeout = atoi(optarg) * 1000;
      break;

    case 'h':
      usage(argv);
      //freemem(&info);
      exit(1);

    case 'v':
      args.verbose = TRUE;
      info.loglevel = LOG_DEBUG;
      break;

    default:
      usage(argv);
      exit(1);

    }
  }      
  
  NBGetInfo(&info);
  /* Save server and workgroup since a null session may destroy them */
  memcpy(tserv, info.server, sizeof(info.server));
  memcpy(twkgrp, info.workgroup, sizeof(info.workgroup));

  if ( SMBConnect(&info) != TRUE ) {
    fprintf(stderr, "Error connecting to %s\n", info.ip);
    return FALSE;
  }

  NBSSessionRequest(&info);
  SMBNegProt(&info);
  SMBSessionSetupNullSession(&info);
  SMBShutdown(&info);

  /* Restore saved server and workgroup */
  memcpy(info.server, tserv, strlen(tserv));
  memcpy(info.workgroup, twkgrp, strlen(twkgrp));

  printf("\n");

  printf("Server Info for %s\n", info.ip);
  for ( c=0; c<strlen(info.ip)+16; c++ )
    printf("-");
  printf("\n");
  printf("Server Name      : %s\n", info.server);
  printf("Server OS        : %s\n", info.NativeOS);
  printf("Workgroup/Domain : %s\n", info.workgroup);
  printf("\n");

  return TRUE;

}





