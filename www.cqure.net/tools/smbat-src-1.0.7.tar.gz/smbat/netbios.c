/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "netbios.h"
#include <netinet/in.h>

void netbiosEncode(char **nb_name, char *name) {

}

void netbiosDecode(char **name, char *nb_name) {

  int i;
  char c;
  char str[24];

  i = 0;
  c = 0;

  memset(str, 0, 24);

  while ( nb_name[i] != 0 ) {

    if ( nb_name[i] == 'C' && nb_name[i+1] == 'A' )
      break;

    c = ( (nb_name[i] - 0x41 ) * 16 ) + ( nb_name[i+1] - 0x41);
    memset(*name+(i/2), c, 1);
    i+=2;

  }
  

}

/* Convert computer name to netbios name */
void getNetbiosName(char *nb_name, char *name) {

  int i;
  char s[2];
  char new_s[40];
   
  memset(new_s, 0, 40);

  for (i=0; i<16; i++) {
    if ( i >= strlen(name) ) {
      memcpy(s, "CA", 2);
    }
    else {
      s[0] = name[i]/16 + 0x41;
      s[1] = name[i]%16 + 0x41;
    }  
    
    strncat(new_s, s, 2);
  }

  memcpy(nb_name, new_s, 32);

}

int isWriteReady(int fd) {

  fd_set rfds;
  struct timeval tv;
  int retval;

  /* is DA socket ready ?! */
  FD_ZERO(&rfds);
  FD_SET(fd, &rfds);
  
  tv.tv_sec = 1;
  tv.tv_usec = 0;
  
  retval = select(fd+1, NULL, &rfds, NULL, &tv);
  
  if (retval)
    return TRUE;

  return FALSE;

}

int isReadReady(int fd) {

  fd_set rfds;
  struct timeval tv;
  int retval;

  /* is DA socket ready ?! */
  FD_ZERO(&rfds);
  FD_SET(fd, &rfds);
  
  tv.tv_sec = 1;
  tv.tv_usec = 0;
  
  retval = select(fd+1, &rfds, NULL, NULL, &tv);

  if (retval)
    return TRUE;

  return FALSE;

}

char *NBNameQuery(char *ip) {

  HEXPACKET *pHexData;
  int fd;
  struct in_addr target;
  struct sockaddr_in sock;
  unsigned char rbuf[1024];
  int nDataLength = -1, nNumNames = -1, nOffset = -1;
  int nLen = -1, i=-1;
  char *pNetBiosName;

  pNetBiosName = (char *) malloc(16);
  memset(pNetBiosName, 0, 16);

  pHexData = createHexPacket("80 70 00 10 00 01 00 00 00 00 00 00 20 43 "\
			     "4b 41 41 41 41 41 41 41 41 41 41 41 41 41 "\
			     "41 41 41 41 41 41 41 41 41 41 41 41 41 41 "\
			     "41 41 41 00 00 21 00 01");

  memset(rbuf, 0, sizeof(rbuf));

  if ( inet_aton(ip, (struct in_addr *) &target) == 0) {
    fprintf(stderr, "ERROR: Converting IP\n");
    return NULL;
  }

  fd = socket( AF_INET, SOCK_DGRAM, IPPROTO_UDP);

  sock.sin_addr.s_addr = target.s_addr;
  sock.sin_family = AF_INET;
  sock.sin_port = htons(137);

  fcntl(fd, F_SETFL, O_NONBLOCK);

  if ( connect(fd, (struct sockaddr *) &sock, sizeof(sock)) != 0 ) {
    fprintf(stderr, "ERROR: Creating socket\n");
    return NULL;
  }

  if ( isWriteReady(fd) == TRUE )
    send(fd, pHexData->data, pHexData->size, 0);
  else
    return NULL;

  freeHexPacket(pHexData);

  if ( isReadReady(fd) == TRUE )
    nLen = recv(fd, rbuf, sizeof(rbuf), 0);
  else
    return NULL;

  close(fd);
  
  if ( nLen < 56 ) {
    return NULL;
  }

  nNumNames = rbuf[56];
  nDataLength = rbuf[55];

  nOffset = 57;

  for ( i=0; i<nNumNames; i++ ) {
    if ( rbuf[nOffset+15] == 0 )
      break;

    nOffset += 18;
  }

  memcpy(pNetBiosName, rbuf+nOffset, 16);

  /* make sure it's null terminated */
  if ( pNetBiosName[15] != 0 ) {
    pNetBiosName[15] = 0;
  }

  return pNetBiosName;

}

/*
  later :)

  in progress....

*/
int NBGetInfo(BRUTEINFO *info) {

  int fd = -1;
  struct in_addr target;
  struct sockaddr_in sock;
  int nlen = -1;
  int i;
  int nhosts;
  int nhostcount;
  int noffset;
  char str[16];
  int ntype;
  int bhostfound = FALSE;
  fd_set rfds;
  struct timeval tv;
  int retval;

  UCHAR buf[50] = {0x01, 0xF8, 0x00, 0x10, 0x00,
		   0x01, 0x00, 0x00, 0x00, 0x00,
		   0x00, 0x00, 0x20, 0x43, 0x4B,
		   0x41, 0x41, 0x41, 0x41, 0x41,
		   0x41, 0x41, 0x41, 0x41, 0x41,
		   0x41, 0x41, 0x41, 0x41, 0x41,
		   0x41, 0x41, 0x41, 0x41, 0x41,
		   0x41, 0x41, 0x41, 0x41, 0x41,
		   0x41, 0x41, 0x41, 0x41, 0x41,
		   0x00, 0x00, 0x21, 0x00, 0x01};

  UCHAR rbuf[4096];

  memset(rbuf, 0, sizeof(rbuf));

  if ( inet_aton(info->ip, (struct in_addr *) &target) == 0) {
    fprintf(stderr, "couldn't convert address...\n");
    return -1;
  }

  fd = socket( AF_INET, SOCK_DGRAM, IPPROTO_UDP);

  sock.sin_addr.s_addr = target.s_addr;
  sock.sin_family = AF_INET;
  sock.sin_port = htons(137);

  if ( connect(fd, (struct sockaddr *) &sock, sizeof(sock)) != 0 ) {
    fprintf(stderr, "error creating socket...\n");
    return -1;
  }

  send(fd, buf, 50, 0);

  /* Watch stdin (fd 0) to see when it has input. */
  FD_ZERO(&rfds);
  FD_SET(fd, &rfds);
  /* Wait up to two seconds. */
  tv.tv_sec = 2;
  tv.tv_usec = 0;
  
  retval = select(fd+1, &rfds, NULL, NULL, &tv);
  /* Don't rely on the value of tv now! */
  
  if (!retval) {
    /* set the servername to SMBSERVER this should be changed to
       real name in SMBNegprot */
    memcpy(info->server, "*SMBSERVER", strlen("*SMBSERVER"));
    memcpy(info->workgroup, "MYGROUP", strlen("MYGROUP"));
    return FALSE;
  }

  nlen = recv(fd, rbuf, 4096, 0);

  /* did we recieve any data ? */
  if ( nlen > 0 ) {
    noffset = 56; /* move to the initial offset */
    nhosts = rbuf[noffset]; /* check how many host we've got... */
    noffset++; /* move along a byte */
  }
  else
    return FALSE;

  if ( nhosts < 1 )
    return FALSE;

  /* loop through all the hosts */
  for ( nhostcount = 0; nhostcount<nhosts; nhostcount++ ) {
    memset((char *)str, 0, sizeof(str));
    for ( i=0; i<18; i++) {
      str[i] = rbuf[nhostcount*18 + i + noffset];

      /* trim tailing spaces */
      if ( rbuf[nhostcount*18 + i + noffset] == 32 ) {
	str[i] = 0; /* clear the last space */
	break;
      }
    }

    /* determine the type of the name returned */
    ntype = rbuf[nhostcount*18+noffset+15];
    
    if ( ( ntype == 0 || ntype == 32 ) && ( bhostfound == FALSE ) ) {
      bhostfound = TRUE;
      memset(info->server, 0, sizeof(info->server));
      strncpy(info->server, str, strlen(str));
    }
    else if ( ntype == 0 ) {
      memset(info->workgroup, 0, sizeof(info->workgroup));
      strncpy(info->workgroup, str, strlen(str));
      break; /* exit the fine loop */
    }
    
  }
  
  close(fd);

  return TRUE;

}

/* ehh... well..  */
void getNetbiosRedirectorName(char *nb_local) {

  char *pHostName;
  char *pTmp;

  pHostName = (char *) malloc ( 100 );
  pTmp = (char *) malloc( 100 );

  memset(pHostName, 0, sizeof(pHostName));
  memset(pTmp, 0, sizeof(pTmp));

  if ( gethostname(pHostName, sizeof(pHostName)) == -1 ) {
    memcpy(pHostName, "foobar", strlen("foobar"));
  }
  
  getNetbiosName(pTmp, pHostName);
  memcpy(nb_local, pTmp, 32);

  free(pTmp);
  free(pHostName);
  
}
