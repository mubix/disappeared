#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "smb.h"
#include "smbserverscan.h"
#include "netbios.h"


struct my_target {
  int fd;
  char ip[16];
  int port;
  int alive;
};

struct my_target targets[512];
static int fdpos = 0;
static IPLIST *g_pIPList;


/*
  1. Connect to all ips.
  2. Try sending Netbios Session Request on every socket
  3. If error occurs the connect was unsuccesfull.
  4. If no error occurs the connect was successfull.
  5. See if we get a response from the server.
  6. If the server answers the server service is active.
*/

void usage(char **argv) {

  printf("\n\tSMB - ServerScan %s ",SMB_SUITE_VERSION);
  printf("by (%s)\n", SMB_SUITE_EMAIL);
  printf("\t-------------------------------------------------");
  printf("--------------------\n");
  printf("\tusage: %s -i|net.net.net.ip-ip [options]\n\n", argv[0]);
  printf("\t\t-i\t<ipfile>\n");
  printf("\t\t-o\toutput format:\n");
  printf("\t\t\t1 - <ip>:<port> (default)\n");
  printf("\t\t\t2 - <ip> (remove duplicates, if both 139,445 exist.)\n");
  printf("\t\t-n\tdo not resolve names.\n");
  printf("\t\t-p\tmax parallell connections (default 20)\n");
  printf("\t\t-t\ttimeout in ms (default 300ms)\n");
  printf("\t\t-v\tbe verbose\n");
  printf("\n");

}


int sendPacket() {
  
  int i=0;
  BRUTEINFO *pInfo;

  pInfo = (BRUTEINFO *) malloc ( sizeof(BRUTEINFO) );
  
  /* send a NetBios session request to all sockets */
  for ( i=0; i<fdpos; i++ ) {
    SMBInitialize(pInfo);
    pInfo->fd = targets[i].fd;

    /* socket seems to be @%/! */
    if ( targets[i].fd == -1 )
      break;

    if ( targets[i].port == 139 )
      NBSSendSessionRequest(pInfo);
    else
      SMBSendNegProt(pInfo);
  }

  free(pInfo);

  return TRUE;

}


int recvPacket() {
  
  int i=0;
  unsigned char rbuf[1024];
  int nRet = 0;

  /* recv NetBios session request to all sockets */
  for ( i=0; i<fdpos; i++ ) {
    memset(rbuf, 0, sizeof(rbuf));

    /* socket seems to be @%/! */
    if ( targets[i].fd == -1 )
      break;

    nRet = recv(targets[i].fd, rbuf, sizeof(rbuf), 0);

    /* If alive is 1 its a rescan */
    if ( targets[i].alive == 0 ) {
    
      if ( targets[i].port == 139 ) {
	if ( rbuf[0] == 130 )
	  targets[i].alive = 1;
	else
	  targets[i].alive = 0;
      }
      else {
	if ( nRet > 81 )
	  targets[i].alive = 1;
	else
	  targets[i].alive = 0;
      }
      
    }

  }

  return TRUE;

}


/*
  Set socket to nonblocking and fire away
*/
int doConnect(char *sIP, int nPort) {

  int fd = -1;
  struct in_addr target;
  struct sockaddr_in sock;

  if ( inet_aton((char *)sIP, (struct in_addr *) &target) == 0) {
    fprintf(stderr, "couldn't convert address...\n");
    return FALSE;
  }

  fd = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP);

  if ( fd == -1 ) {
    fprintf(stderr, "ERROR: max sockets reached");
    exit(1);
  }

  sock.sin_addr.s_addr = target.s_addr;
  sock.sin_family = AF_INET;
  sock.sin_port = htons(nPort);

  fcntl(fd, F_SETFL, O_NONBLOCK);

  connect(fd, (struct sockaddr *) &sock, sizeof(sock));
  targets[fdpos].fd = fd;
  targets[fdpos].port = nPort;
  strncpy(targets[fdpos].ip, sIP, sizeof(targets[fdpos].ip));
  fdpos ++;

  return TRUE;

}

/*
  Function : Reverses a list of IPS
  in : 
       IPLIST* : Linked List Of IPs
  out: 
       IPLIST* : Reversed List 
*/
IPLIST *reverseIP(IPLIST *pIPList) {

  IPLIST *prev, *cur, *next;
  
  prev = NULL;
  cur = pIPList;

  while ( cur ) {
    next = cur->next;
    cur->next = prev;
    prev = cur;
    cur = next;
  }

  pIPList = prev;

  return pIPList;

}

IPLIST *addIP(IPLIST *pIP, char *sIP) {

  IPLIST *pNewIP;
  pNewIP = (IPLIST *) malloc ( sizeof(IPLIST) );

  memset(pNewIP->ip, 0, sizeof(pNewIP->ip));
  strncpy((char *)pNewIP->ip, sIP, sizeof(pNewIP->ip));
  pNewIP->next = pIP;
  pIP = pNewIP;

  return pIP;

}

/*
  Function: If no ip file was specified, try parsing command line
            Very much *alfa*, only supports xxx.xxx.xxx.start-stop

  in : 
      char* : argument 1 of cmdline ( argv[1] )
  out: 
      int   : TRUE on success, else FALSE

 */
int parseIPRange(char **pCmdLine) {

  int nLen = 0;
  int i = 0, j=0;
  int nDivider = 0;
  int nFromOffset = 0;
  int nDots = 0;
  char from[3], to[3];
  int nFrom, nTo;
  char sNewIp[16] = "";
  char sBase[16] = "";
  char *pIPRange;

  /* search for what appears to be the IP */
  while ( pCmdLine[i] != NULL ) {
    for ( j=0; j<strlen(pCmdLine[i]); j++) {
      if ( pCmdLine[i][j] == '.' )
	nDots ++;
    }
    if ( nDots == 3 )
      break;

    i++;
    nDots = 0;

  }

  if ( nDots != 3 )
    return FALSE;

  pIPRange = (char *) malloc(strlen(pCmdLine[i]));
  strcpy(pIPRange, pCmdLine[i]);

  nDots = 0;
  nLen = strlen(pIPRange);

  /* find - */
  for ( i=0; i<nLen; i++ ) {
    if ( pIPRange[i] == '-' )
      nDivider = i;
    
    if ( pIPRange[i] == '.' )
      nDots ++;

  }

  /* seems to be a single ip */
  if ( nDivider == 0 ) {
    if ( nDots == 3 ) {
      g_pIPList = addIP(g_pIPList, pIPRange);
      return TRUE;
    }
    else {
      return FALSE;
    }
  }
  else {
    i = nDivider;

    while ( i>0 ) {
      i--;
      if ( pIPRange[i] == '.' ) {
	nFromOffset = i+1;
	break;
      }
    }

    if ( nDivider - nFromOffset <= 3 )
      strncpy(from, pIPRange+nFromOffset, (nDivider - nFromOffset) );
    else
      return FALSE;

    if ( nLen-(nDivider + 1) <= 3 )
      strncpy(to, pIPRange+nDivider+1, ( nLen-nDivider ) );
    else
      return FALSE;

    strncpy(sBase, pIPRange, nFromOffset-1);

    nTo = atoi(to);
    nFrom = atoi(from);

    for ( i=nFrom; i<=nTo; i++ ) {
      memset(sNewIp, 0, sizeof( sNewIp ));
      sprintf(sNewIp, "%s.%d", sBase, i);
      g_pIPList = addIP(g_pIPList, sNewIp);
    }
    
    g_pIPList = reverseIP(g_pIPList);
    
  }

  free(pIPRange);

  return TRUE;

}

char *getNextIP(char **ip) {

  if ( g_pIPList != NULL ) {
    strncpy( *ip, (char *)g_pIPList->ip, sizeof(g_pIPList->ip));
    g_pIPList = g_pIPList->next;

    return *ip;
  }

  return NULL;

}

int isNextIP() {

  if ( g_pIPList != NULL )
    return TRUE;

  return FALSE;
  
}

void freeIPList(IPLIST *pIPList) {

  IPLIST *rmv;
  IPLIST *curr;

  curr = pIPList;

  while ( curr ) {
    rmv = curr;
    curr = curr->next;
    free(rmv);
  }

}

/*
  Function: Load ipfile into linked list
  in : 
       FILE*    : filehandle to file containing ips
       IPLIST** : reference to pointer of linked ip list
  out:
  
*/
void preloadIPFile(FILE *pIPFile, IPLIST **pIPList) {

  char ip[16];

  while ( fgets(ip, sizeof(ip), pIPFile) != NULL ) {
    /* remove trailing <cr> */
    if ( ip[strlen(ip)-1] == '\n' )
      memset(ip+strlen(ip)-1, 0, 1);
    
    *pIPList = addIP(*pIPList, ip);
  }

  *pIPList = reverseIP(*pIPList);

}

void outputAliveHosts(FILE *nFD, int nFormat) {

  int i;
  char lastIP[16] = "";
  int nSize = sizeof(targets)/sizeof(struct my_target);
  char *cNetBiosName = NULL;

  for ( i=0; i<nSize; i++ ) {
    /* remove duplicates selected */
    if ( nFormat == 2 || nFormat == 4 ) {
      /* is target alive */
      if ( targets[i].alive == 1 ) {
	/* is it a duplicate ? */
	if ( strcmp(lastIP, targets[i].ip) != 0 ) {
	  /* should we try to resolve ? */
	  if ( nFormat == 4 ) {
	    fprintf(nFD, "%s\n", targets[i].ip);
	  }
	  /* do resolve */
	  else {
	    cNetBiosName = NBNameQuery(targets[i].ip);
	    if ( cNetBiosName != NULL )
	      fprintf(nFD, "%s\n", cNetBiosName);
	    else
	      fprintf(nFD, "%s\n", targets[i].ip);

	  }
	  memset(lastIP, 0, sizeof(lastIP));
	  strncpy(lastIP, targets[i].ip, sizeof(lastIP));
	}
      }
    }
    /* format is 1 or 3 */
    else {
      if ( targets[i].alive == 1 ) {
	cNetBiosName = NBNameQuery(targets[i].ip);
	if ( nFormat == 3 || cNetBiosName == NULL)
	  fprintf(nFD, "%-15s:%d\n", targets[i].ip, targets[i].port);
	else 
	  fprintf(nFD, "%s:%d\n", cNetBiosName, targets[i].port);
      }
    }
    
  }

}

void initTargets() {

  int i = 0;
  int nSize = sizeof(targets)/sizeof(struct my_target);
  
  for ( i=0; i<nSize; i++ ) {
    targets[i].alive = 0;
    targets[i].fd = -1;
    targets[i].port = -1;
    memset(targets[i].ip, 0, sizeof(targets[i].ip));
  }

}

int main(int argc, char **argv) {

  char *pIP;
  int i = 0, c = 0;
  FILE *pIPFile = NULL, *pRepFile = NULL;
  long nTimeout = 300 * 1000;
  int nMaxParallell = 20, nParallell = 0, nRescans = 2;
  int nVerbose = 0;
  IPLIST *pTopList = NULL;
  int nOutputFormat = 1;
   
  pIP = (char *) malloc(16);

  while (1) {

    c = getopt(argc, argv, "i:vht:p:r:o:n");

    if ( c == -1 ) 
      break;

    switch (c) {
      
    case 'i':
      pIPFile = fopen(optarg, "r");
      break;

    case 'r':
      pRepFile = fopen(optarg, "a");
      break;

    case 't':
      nTimeout = atoi(optarg) * 1000;
      break;

    case 'o':
      nOutputFormat = atoi(optarg);
      break;

    case 'n':
      nOutputFormat += 2;
      break;

    case 'p':
      nMaxParallell = atoi(optarg);
      break;

    case 'h':
      usage(argv);
      exit(1);

    case 'v':
      nVerbose = 1;
      break;

    default:
      usage(argv);
      exit(1);

    }
  }      

  if ( argc < 2 ) {
    usage(argv);
    exit(1);
  }

  if ( nMaxParallell > 256 ) {
    printf("Parallell can must be less than 256 !\n");
    exit(1);
  }

  // Do we have an IP file ?!
  if ( pIPFile == NULL ) {
    if ( parseIPRange(argv) == FALSE ) {
      usage(argv);
      exit(1);
    }
  }

  if ( pIPFile != NULL )
    preloadIPFile(pIPFile, &g_pIPList);

  printf("SMB - ServerScan by Patrik Karlsson " \
	 "<%s>\n", SMB_SUITE_EMAIL);
  printf("------------------------------------" \
	 "--------------------------------\n");


  if ( nVerbose )
    fprintf(stderr, "Connecting to all IPs...\n");

  initTargets();

  /* Always scan twice to be more reliable */
  for ( ; nRescans > 0; nRescans-- ) {

       pTopList = g_pIPList;
       
       while ( isNextIP() == TRUE ) {

	 while ( nParallell < nMaxParallell && getNextIP(&pIP) != NULL ) {
	   if ( nVerbose )
	     printf("Connecting to %s\n", pIP);
	   doConnect(pIP, 139);
	   doConnect(pIP, 445);
	   nParallell ++;
	 }
  
	 if ( nVerbose )
	   fprintf(stderr, "Waiting for %d ms...\n", (int)(nTimeout/1000));
	 usleep(nTimeout);
    
	 if ( nVerbose )
	   fprintf(stderr, "Sending Netbios Session Request to all "\
		   "connections...\n");
	 sendPacket();

	 if ( nVerbose )
	   fprintf(stderr, "Waiting for %d ms...\n", (int)(nTimeout/1000));
	 usleep(nTimeout);
    
	 if ( nVerbose )
	   fprintf(stderr, "Recieving Netbios Session Request answers...\n");
	 recvPacket();

	 if ( nVerbose )
	   fprintf(stderr, "Closing sockets...\n");
	 for ( i=0; i<fdpos; i++ ) {
	   close(targets[i].fd);
	 }

	 nParallell = 0;
	 fdpos = 0;

       }

       g_pIPList = pTopList;

  }

  if ( pRepFile == NULL )
    outputAliveHosts(stdout, nOutputFormat);
  else
    outputAliveHosts(pRepFile, nOutputFormat);

  free(pIP);
  freeIPList(pTopList);

  if ( pRepFile )
    fclose(pRepFile);

  if ( pIPFile )
    fclose(pIPFile);

  return TRUE;

}


