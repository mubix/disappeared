/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "smbbf.h"
#include "smblib.h"
#include "smb.h"
#include "util.h"
#include <stdio.h>

/*-------------------------------------------------

  function: SidToUser
            Used to enumerate usernames from SID.
	    Start from sid = nStart
	    Allow nError of errors
	    Return nAmount of SIDS


  returns: True on success.
           False on failure

-------------------------------------------------- */
int SidToUser(BRUTEINFO *info, int nStart, int nError, int nAmount) {

  int nSID, nBadSID;

  if ( SMBConnect(info) != TRUE ) {
    fprintf(stderr, "Error connecting to %s\n", info->ip);
    return FALSE;
  }

  if ( NBSSessionRequest(info) != TRUE ) {
    fprintf(stderr, "session setup failed ! ");
    fprintf(stderr, "(is ther server service running ?)\n");
    return FALSE;
  }

  SMBNegProt(info);
  SMBSessionSetupNullSession(info);
  SMBTConX(info);

  if ( SMBNTCreateAndX(info) != TRUE ) {
    fprintf(stderr, "ERROR: SMBNTCreateAndX()\n");
    fprintf(stderr, "ERROR: The server might have restrict anonymous set to 2\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetup(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicy()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetupPart2(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSADoSomeShit()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAAskForComputerName(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAAskForComputerName()\n");
    SMBShutdown(info);
    return FALSE;
  }
  
  if ( LSAQueryDomainSID(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAQueryDomainSID()\n");
    SMBShutdown(info);
    return FALSE;
  }

  SMBShutdown(info);

  if ( SMBConnect(info) != TRUE ) {
    fprintf(stderr, "Error connecting to %s\n", info->ip);
    return FALSE;
  }

  if ( NBSSessionRequest(info) != TRUE ) {
    fprintf(stderr, "session setup failed ! ");
    fprintf(stderr, "(is ther server service running ?)\n");
    return FALSE;
  }

  SMBNegProt(info);
  SMBSessionSetupNullSession(info);
  SMBTConX(info);

  if ( SMBNTCreateAndX(info) != TRUE ) {
    fprintf(stderr, "ERROR: SMBNTCreateAndX()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetup(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicy()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetupPart2(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicySetupPart2\n");
    SMBShutdown(info);
    return FALSE;
  }

  LSAOpenPolicySetupPart5(info);

  nSID = nStart;
  nBadSID = 0;

  /* OK Admin is at 500, users start at 1000 try nError more after "last" user
     since someone might have deleted a few users */
  while ( nBadSID < nError ) {
    if ( LSASidToUser(info,nSID) != TRUE )
      nBadSID ++;
    else
      nBadSID = 0;

    nSID ++;

    if ( ( nAmount != -1 ) && ( ( nSID-nStart ) == nAmount )  )
      break;

    /* something has obviously gone wrong here, lets break */
    if ( nSID == 60000 )
      return FALSE;

  }

  SMBShutdown(info);

  return TRUE;
  
}

/* ----------------------------------------------------

  function: LSADumpUsers
            Used to dump usernames from a Windows box.
	    
  comment:  Works only when restrictanonymous = 0

  returns:  True on success.
            False on failure

------------------------------------------------------ */
int LSADumpUsers(BRUTEINFO *info) {

  if ( SMBConnect(info) != TRUE ) {
    fprintf(stderr, "Error connecting to %s\n", info->ip);
    return FALSE;
  }

  if ( NBSSessionRequest(info) != TRUE ) {
    fprintf(stderr, "session setup failed ! ");
    fprintf(stderr, "(is ther server service running ?)\n");
    return FALSE;
  }

  SMBNegProt(info);
  SMBSessionSetupNullSession(info);
  SMBTConX(info);

  if ( SMBNTCreateAndX(info) != TRUE ) {
    fprintf(stderr, "ERROR: SMBNTCreateAndX()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetup(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicy()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetupPart2(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSADoSomeShit()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAAskForComputerName(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAAskForComputerName()\n");
    SMBShutdown(info);
    return FALSE;
  }
  
  if ( LSAQueryDomainSID(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAQueryDomainSID()\n");
    SMBShutdown(info);
    return FALSE;
  }

  SMBShutdown(info);

  if ( SMBConnect(info) != TRUE ) {
    fprintf(stderr, "Error connecting to %s\n", info->ip);
    return FALSE;
  }

  if ( NBSSessionRequest(info) != TRUE ) {
    fprintf(stderr, "session setup failed ! ");
    fprintf(stderr, "(is ther server service running ?)\n");
    return FALSE;
  }

  SMBNegProt(info);
  SMBSessionSetupNullSession(info);
  SMBTConX(info);

  if ( SMBNTCreateAndX(info) != TRUE ) {
    fprintf(stderr, "ERROR: SMBNTCreateAndX()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetup(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicy()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetupPart2(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicySetupPart2\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetupPart3(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicySetupPart3\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetupPart4(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicySetupPart4()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSARetrieveUserInfo(info) != TRUE ) {
    if ( info->loglevel == 3 ) 
      fprintf(stderr, "ERROR: LSARetrieveUserInfo()\n");

    SMBShutdown(info);
    return FALSE;
  }

  SMBShutdown(info);
  
  return TRUE;

}

/* Needed to retrieve computer name */

int RetrieveComputerName(BRUTEINFO *info) {

  if ( SMBConnect(info) != TRUE ) {
    fprintf(stderr, "Error connecting to %s\n", info->ip);
    return FALSE;
  }

  if ( NBSSessionRequest(info) != TRUE ) {
    fprintf(stderr, "session setup failed ! ");
    fprintf(stderr, "(is ther server service running ?)\n");
    return FALSE;
  }

  SMBNegProt(info);
  SMBSessionSetupNullSession(info);
  SMBTConX(info);

  if ( SMBNTCreateAndX(info) != TRUE ) {
    fprintf(stderr, "ERROR: SMBNTCreateAndX()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetup(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAOpenPolicy()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAOpenPolicySetupPart2(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSADoSomeShit()\n");
    SMBShutdown(info);
    return FALSE;
  }

  if ( LSAAskForComputerName(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAAskForComputerName()\n");
    SMBShutdown(info);
    return FALSE;
  }
  
  if ( LSAQueryDomainSID(info) != TRUE ) {
    fprintf(stderr, "ERROR: LSAQueryDomainSID()\n");
    SMBShutdown(info);
    return FALSE;
  }

  SMBShutdown(info);

  return TRUE;

}

/*

  Outputs the linked list of users to a report file or on the screen

 */
void OutputUsers(BRUTEINFO *info, int breport, int nFilter) {

  FILE *fd;
  char fname[20];

  /* should we report this stuff ? */
  if ( breport == TRUE ) {
    memset(fname, 0, sizeof(fname));
    memcpy(fname, info->ip, strlen(info->ip));
    memcpy(fname+strlen(info->ip), ".txt", strlen(".txt"));
    fd = fopen(fname, "w");
    ll_writeitems(fd, info->userlist, nFilter, info->loglevel);
    fclose(fd);
  }

  info->userlist = (SMBUSERS *)ll_reverseusers(info->userlist);
  ll_writeitems(stdout, info->userlist, nFilter, info->loglevel);
  ll_freeusers(info->userlist);

}

/*

  Wrap LSADumpUsers and SidToUser

*/

int RetrieveUsers(BRUTEINFO *info) {

  if ( LSADumpUsers(info) != TRUE )
    return SidToUser(info, 500, 500, -1);

  return TRUE;

}
