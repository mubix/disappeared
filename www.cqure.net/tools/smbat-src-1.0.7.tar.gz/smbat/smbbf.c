/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "smbbf.h"
#include "smb.h"
#include "util.h"
#include "netbios.h"
#include "smblib.h"
#include <stdlib.h>
#include <time.h>
#include <sys/times.h>
#include <getopt.h>

void usage(char **argv) {

  printf("\n\tSMB - Bruteforcer %s ", SMB_SUITE_VERSION);
  printf("by (%s)\n", SMB_SUITE_EMAIL);
  printf("\t--------------------------------------------------------------\n");
  printf("\tusage: %s -i [options]\n\n", argv[0]);
  printf("\t\t-i*\tIP address of server to bruteforce\n");
  printf("\t\t-p\tPath to file containing passwords\n");
  printf("\t\t-u\tPath to file containing users\n");
  printf("\t\t-s\tServer to bruteforce\n");
  printf("\t\t-r\tPath to report file\n");
  printf("\t\t-t\ttimeout for connect (default 300ms)\n");
  printf("\t\t-w\tWorkgroup/Domain\n");
  printf("\t\t-g\tBe nice, automaticaly detect account lockouts\n");
  printf("\t\t-v\tBe verbose\n");
  printf("\t\t-P\tProtocol version\n");
  printf("\t\t\t    0 - Netbios Mode\n");
  printf("\t\t\t    1 - Windows 2000 Native Mode\n");
  printf("\n");

} 

/* Initialize arguments */
void InitArgs(CMDARGS *args) {

  memset(args->user_file, 0, sizeof(args->user_file));
  memset(args->passwd_file, 0, sizeof(args->passwd_file));
  memset(args->report_file, 0, sizeof(args->report_file));
  args->force   = 1;
  args->verbose = FALSE;
}

/* Free allocated memory */
void CleanupArgs(BRUTEINFO *info, CMDARGS *args) {

  /* free the linked list */
  ll_freeusers(info->userlist);
  ll_freepwds(info->pwdlist);

}

void doBruteForce(BRUTEINFO info, CMDARGS args) {

  FILE *uFile = NULL; /* user file */
  FILE *pFile = NULL; /* passwd file */
  FILE *rFile = NULL; /* reportfile */

  SMBUSERS *pUserlist;
  SMBPWDS *pPwdlist;

  /* Some Statistics */
  float fStartTicks, fEndTicks, fTotalTime;
  struct tms t_tms;

  UCHAR nErr;
  char error[100];

  unsigned int nTries      = 0;
  unsigned int nTotalTries = 0;
  unsigned int nSuccess    = 0;
  unsigned int nDisabled   = 0;
  unsigned int nAccounts   = 0;
  unsigned int nChangePw   = 0;
  int nLockOutAttempts     = 0;

  if ( !strlen(args.user_file) )
    RetrieveUsers(&info);

  if ( SMBConnect(&info) != TRUE ) {
    fprintf(stderr, "Error connecting to %s\n", info.ip);
    CleanupArgs(&info, &args);
    exit(1);
  }

  if ( NBSSessionRequest(&info) != TRUE ) {
    fprintf(stderr, "session setup failed ! ");
    fprintf(stderr, "(is ther server service running ?)\n");
    CleanupArgs(&info, &args);
    exit(1);
  }

  NBGetInfo(&info);

  memset(info.user, 0, sizeof(info.user));
  memset(info.pass, 0, sizeof(info.pass));
  
  SMBNegProt(&info);

  /* do we have a user file or should we get it */
  if ( strlen(args.user_file) ) {

    if ( ( uFile = (FILE *)OpenUserFile(args.user_file) ) == NULL ) {
      fprintf(stderr, "error opening user file !\n");
      CleanupArgs(&info, &args);
      exit(1);
    }

    PreLoadUsers(&info, uFile);
  }

  info.userlist = (SMBUSERS *)ll_reverseusers(info.userlist);
  pUserlist = info.userlist;

  if ( strlen(args.passwd_file) ) {

    if ( ( pFile = (FILE *)OpenPassFile(args.passwd_file) ) == NULL ) {
      fprintf(stderr, "error opening passw file !\n");
      CleanupArgs(&info, &args);
      exit(1);
    }
    
    PreLoadPassWords(&info, pFile);
  }
  else {
    info.pwdlist = (SMBPWDS *)ll_addpw(info.pwdlist, "");
    info.pwdlist = (SMBPWDS *)ll_addpw(info.pwdlist, "lc %username%");
    info.pwdlist = (SMBPWDS *)ll_addpw(info.pwdlist, "password");
  }

  info.pwdlist = (SMBPWDS *)ll_reversepwds(info.pwdlist);
  pPwdlist = info.pwdlist;

  if ( strlen(args.report_file) ) {
    if (( rFile = (FILE *)OpenReportFile(args.report_file) ) == NULL ) {
      fprintf(stderr, "error creating report file !\n");
      CleanupArgs(&info, &args);
      exit(1);
    }
    fprintf(rFile, "-- Report for password analysis on %s, %s --\n\n", 
	    info.server, info.ip);
  }

  fprintf(stdout, "\n-- Starting password analysis on %s --\n\n", info.ip);
  fStartTicks = times(&t_tms);

  while ( pUserlist ) {

    /* get the current item from the linked list of users */
    memset(info.user, 0, sizeof( info.user ) );
    strncpy(info.user, pUserlist->item, sizeof( info.user ) - 1 );
    info.user[strlen(pUserlist->item)] = 0;

    while ( info.fd == -1 ) {
      SMBConnect(&info);
      NBSSessionRequest(&info);
      SMBNegProt(&info);
    }

    while ( pPwdlist ) {

      memset(info.pass, 0, sizeof( info.pass ) );
      strncpy(info.pass, pPwdlist->item, sizeof(info.pass) - 1);
      strcpy(info.pass, ProcessPwd(&info));

      if ( args.verbose == TRUE ) {
	fprintf(stdout, "Logging in as %s with %s on %s\n",  
		info.user, info.pass, info.server);
      }
      
      if ( ( nErr = SMBSessionSetup(&info) ) != 0 ) {
	if ( args.verbose == TRUE ) {
	  SMBGetLoginLongError((BRUTEINFO *)&info, (char *)&error); 
	  printf("%s\n", error);
	} /* end verbose */

	/* account disabled */
	if ( 0x72 == info.error[0] ) {
	  nDisabled ++;
	  break;
	}

	/* account locked out */
	if ( 0x34 == info.error[0] && nLockOutAttempts == 0 ) {
	  nLockOutAttempts = nTries;
	  
	  /* someone really wants to lock out the accounts */
	  if ( !args.force )
	    break;
	}
	
	/* change password on next login */
	if ( 0x24 == info.error[0] ) {

	  nChangePw ++;
	  printf("User: %-16s  Password: %-16s\n", info.user, info.pass);
	  printf("User needs to change password next login.\n");

	  /* log to report file */
	  if ( rFile != NULL ) {
	    fprintf(rFile, "User: %-16s  Password: %-16s\n", 
		    info.user, info.pass);
	    fprintf(rFile, "User needs to change password next login.\n");
	  }

	  nSuccess ++;
	  break;
	}


      } /* end error occured */
      else {
	printf("User: %-16s  Password: %-16s\n", info.user, info.pass);
	SMBShutdown(&info);
	info.fd = -1;
	
	/* Log succesfull logins to report file */
	if ( rFile != NULL ) {
	  fprintf(rFile, "User: %-16s  Password: %-16s\n", 
		  info.user, info.pass);
	} 

	nSuccess ++;

	break;

      } /* end of password found */
      
      pPwdlist = pPwdlist->next;
      nTries++;

      /* check if we have one more try before lockout and 
	 the force flag is not set */
      if ( nTries == nLockOutAttempts-1 && !args.force )
	break;

    } /* end of pw loop */

    nTotalTries += nTries;
    nTries = 0;

    pUserlist = pUserlist->next;
    pPwdlist = info.pwdlist;
    nAccounts ++;

  } /* end of user loop */

  fEndTicks = times(&t_tms);
  CleanupArgs(&info, &args);
  SMBShutdown(&info);

  if ( pFile != NULL )
    fclose(pFile);

  if ( uFile != NULL )
    fclose(uFile);

  fTotalTime = (fEndTicks - fStartTicks) / CLK_TCK;

  fprintf(stdout, "\n-- Password Statistics --\n\n");
  fprintf(stdout, "Total tries %d in %.2f seconds\n", nTotalTries, fTotalTime);
  fprintf(stdout, "Tries per second = %.2f\n\n", ( nTotalTries/fTotalTime ) );
  fprintf(stdout, "Total accounts %d, compromised %d, disabled %d\n", 
	  nAccounts, nSuccess, nDisabled);
  fprintf(stdout, "Penetration ratio = %.2f %%\n\n", 
	  ((float)nSuccess/(float)nAccounts) * 100 );
  if ( nLockOutAttempts>1 )
    fprintf(stdout, "Lockout seems to be set at %d tries\n", 
	    nLockOutAttempts);


  if ( rFile != NULL ) {
    fprintf(rFile, "\n-- Password Statistics --\n\n");
    fprintf(rFile, "Total tries %d in %.2f seconds\n", 
	    nTotalTries, fTotalTime);
    fprintf(rFile, "Tries per second = %.2f\n\n", ( nTotalTries/fTotalTime ) );
    fprintf(rFile, "Total accounts %d, compromised %d, disabled %d\n", 
	    nAccounts, nSuccess, nDisabled);
    fprintf(rFile, "Penetration ratio = %.2f %%\n\n", 
	    ((float)nSuccess/(float)nAccounts) * 100 );

    if ( nLockOutAttempts>1 )
      fprintf(rFile, "Lockout seems to be set at %d tries\n", 
	      nLockOutAttempts);

    fprintf(rFile, "======= %s =======\n\n\n", SMB_SUITE_EMAIL);
    fclose(rFile);
  }

}

/*
  == MAIN PROGRAM ==
*/
int main(int argc, char *argv[]) {
  
  int c = -1;
  
  BRUTEINFO info; 
  CMDARGS args; /* command line arguments */

  SMBInitialize(&info);
  InitArgs(&args);

  while (1) {

    c = getopt (argc, argv, "i:p:u:s:r:w:vhgP:t:");

    if ( c == -1 )
      break;

    switch (c) {
      
    case 'i':
      if ( strlen(optarg) < 16 ) 
	memcpy(info.ip, optarg, strlen(optarg));
      break;

    case 'u':
      memcpy(args.user_file, optarg, strlen(optarg));
      break;

    case 'r':
      memcpy(args.report_file, optarg, strlen(optarg));
      break;

    case 't':
      info.timeout = atoi(optarg) * 1000;
      break;

    case 'p':
      memcpy(args.passwd_file, optarg, strlen(optarg));
      break;

    case 'w':
      memcpy(info.workgroup, optarg, strlen(optarg));
      break;

    case 's':
      memcpy(info.server, ucase(optarg), strlen(optarg));

      break;

    case 'v':
      args.verbose = TRUE;
      break;

    case 'g':
      /* be nice >:) */
      args.force = 0;
      break;

    case 'P':
      info.protocol = atoi(optarg);
      
      if ( info.protocol != 0 && info.protocol != 1 ) {
	fprintf(stderr, "Unsupported protocol !\n");
	exit(1);
      }

      break;

    default:
      usage(argv);
      exit(1);

    }

  }

  /* did we atleast get an ip !? */
  if ( !strlen(info.ip) ) {
    usage(argv);
    exit(1);
  }

  /* ok no server supplied, lets se if we can get it anyway
     obsolete, seems to do more damage than good ! :)
  */
  /*
  if ( !strlen(info.server) ) {
    NBGetInfo(&info);
  }
  */ 

  /* set workgroup if non specified to FOO */
  if ( !strlen(info.workgroup) ) {
    strncpy(info.workgroup, "foo", 3);
  }

  /* check all required args */
  if ( !strlen(info.server) ) {
    fprintf(stderr, "INFO: Could not determine server name ...\n");
  }

  doBruteForce(info, args);

  return TRUE;

}





