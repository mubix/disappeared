/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "smblib.h"
#include "util.h"
#include <stdlib.h>

/* show groups and machine accounts */
const int DUMP_FILTER_NONE = 0;

char *inflate(char *str, int len) {

  char *tmp;
  int i;

  tmp = (char *) malloc( strlen(str) * 2 );
  memset(tmp, 0, ( strlen(str) * 2 ) );
  
  for ( i=0; i<strlen(str); i++ ) {
    tmp[i*2] = str[i];
  }

  memcpy(str, tmp, len*2);
  free(tmp);

  return str;
}

/*
  
  Deflate: Remove every other char in string
  
 */
char *deflate(char *str, int len) {

  char *tmp;
  int i;

  tmp = (char *) malloc ( len );
  memset(tmp, 0, len);

  for ( i=0; i<len/2; i++ )
    tmp[i] = str[i*2];

  memset(str, 0, len);
  memcpy(str, tmp, len);
  free(tmp);
  
  return str;

}
/*

  Reverse a linked list. Usefull for users and pwd, since
  everything will be poped in reverse order.

 */
SMBUSERS *ll_reverseusers(SMBUSERS *ll_users) {

  SMBUSERS *prev, *cur, *next;
  
  prev = NULL;
  cur = ll_users;

  while ( cur ) {
    next = cur->next;
    cur->next = prev;
    prev = cur;
    cur = next;
  }

  ll_users = prev;

  return ll_users;

}

SMBPWDS *ll_reversepwds(SMBPWDS *ll_pwds) {

  SMBPWDS *prev, *cur, *next;
  
  prev = NULL;
  cur = ll_pwds;

  while ( cur ) {
    next = cur->next;
    cur->next = prev;
    prev = cur;
    cur = next;
  }

  ll_pwds = prev;

  return ll_pwds;

}

/*

  Process "special" strings in passwords.
  Like :last_word etc.

 */
char *ProcessPwd(BRUTEINFO *info) {

  if ( strcmp(info->pass, "uc %username%") == 0 ) {
    memcpy(info->pass, ucase(info->user), strlen(info->user));
    memset(info->pass+strlen(info->user), 0, 1);
  }
  else if ( strcmp(info->pass, "lc %username%") == 0 ) {
    strncpy(info->pass, lcase(info->user), strlen(info->user));
    memset(info->pass+strlen(info->user), 0, 1);
  }
  else if ( strcmp(info->pass, "%username%") == 0 ) {
    strncpy(info->pass, info->user, strlen(info->user));
    memset(info->pass+strlen(info->user), 0, 1);
  }
  else if ( strcmp(info->pass, "lc %hostname%") == 0 ) {
    strncpy(info->pass, lcase(info->server), strlen(info->server));
    memset(info->pass+strlen(info->server), 0, 1);
  }
  else if ( strcmp(info->pass, "uc %hostname%") == 0 ) {
    strncpy(info->pass, ucase(info->server), strlen(info->server));
    memset(info->pass+strlen(info->server), 0, 1);
  }


  return info->pass;
}

/*
  
  Free all items in list given the top one

 */
void ll_freeusers(SMBUSERS *ll_users) {
  
  SMBUSERS *rmv;
  SMBUSERS *curr;

  curr = ll_users;

  while ( curr ) {
    rmv = curr;
    curr = curr->next;
    free(rmv);
  }

}

void ll_freepwds(SMBPWDS *ll_pwds) {
  
  SMBPWDS *rmv;
  SMBPWDS *curr;

  curr = ll_pwds;

  while ( curr ) {
    rmv = curr;
    curr = curr->next;
    free(rmv);
  }

}

/*

  Add item to linked list

 */
SMBUSERS *ll_adduser(SMBUSERS *userlist, int nRID, char *user) {

  SMBUSERS *smbusers;

  smbusers = (SMBUSERS *) malloc(sizeof(SMBUSERS));
  memset(smbusers->item, 0, sizeof(smbusers->item));
  strncpy(smbusers->item, user, sizeof(smbusers->item) - 1);

  smbusers->nRID = nRID;

  smbusers->next = userlist;
  userlist = smbusers;

  return userlist;
}

SMBPWDS *ll_addpw(SMBPWDS *pwdlist, char *pwd) {

  SMBPWDS *smbpwds;

  smbpwds = (SMBPWDS *) malloc(sizeof(SMBPWDS));
  memset(smbpwds->item, 0, sizeof(smbpwds->item));
  memcpy(smbpwds->item, pwd, strlen(pwd));
  
  smbpwds->next = pwdlist;
  pwdlist = smbpwds;

  return pwdlist;
}

/*
  
  Output smbusers to FD use stdout for screen output

 */
void ll_writeitems(FILE *fd, SMBUSERS *ll_users, int nDumpFilter,int nLogLvl) {

  while ( ll_users ) {

    if ( ll_users->item[strlen(ll_users->item)-1] == '$' ) {
      if ( nDumpFilter != DUMP_FILTER_NONE ) {
	if ( nLogLvl > 0 && ll_users->nRID > 0)
	  printf("%d-", ll_users->nRID);
	fprintf(fd, "%s\n", ll_users->item);
      }
    }
    else {
	if ( nLogLvl > 0 && ll_users->nRID > 0)
	printf("%d-", ll_users->nRID);

      fprintf(fd, "%s\n", ll_users->item);

    }

    ll_users = ll_users->next;
  }

}


/* uppercase */
char *ucase(UCHAR *src) {
  int i;
  UCHAR dest[strlen(src)];
  
  memset(dest, 0, strlen(src));

  for ( i=0; i<strlen(src); i++ ) {
    if ( src[i]>=97 && src[i] <= 122 ) {
      dest[i] = src[i]-32;
    }
    else if ( src[i] == 148 )
      dest[i] = 153;
    else if ( src[i] == 134 )
      dest[i] = 143;
    else if ( src[i] == 132 )
      dest[i] = 142;
    else {
      dest[i] = src[i];
    }
  }

  memcpy(src, dest, strlen(src));

  return src;
}

/* lowercase */
char *lcase(UCHAR *src) {
  int i;
  UCHAR dest[strlen(src)];
  
  memset(dest, 0, strlen(src));

  for ( i=0; i<strlen(src); i++ ) {
    if ( src[i]>=65 && src[i] <= 90 ) {
      dest[i] = src[i]+32;
    }
    else {
      dest[i] = src[i];
    }
  }

  memcpy(src, dest, strlen(src));

  return src;
}

FILE *OpenUserFile(char *filename) {
  return fopen(filename, "r");
}

FILE *OpenPassFile(char *filename) {
  return fopen(filename, "r");
}

FILE *OpenReportFile(char *filename) {
  return fopen(filename, "a");
}

/*
 * char *chomp(char *tmpLine)
 *
 * Returns *tmpLine without trailing \r or \n 's
 *
 */
char *chomp(char *tmpLine) {

  int nLen = strlen( tmpLine );

  while ( tmpLine[nLen-1] == '\n' || tmpLine[nLen-1] == '\r' ) {
    memset(tmpLine+nLen-1, 0, 2);
    nLen --;
    }

  tmpLine[nLen] = '\0';

  return tmpLine;

}


/*

  Preload all users into a linked list.

 */
int PreLoadUsers(BRUTEINFO *info, FILE *fd) {

  char cUser[32];
  
  memset(cUser, 0, sizeof(cUser));
  info->userlist = NULL;

  while( fgets(cUser, sizeof(cUser) - 1, fd) != NULL ) {

    strcpy( cUser, chomp(cUser) );
    info->userlist = (SMBUSERS *) ll_adduser(info->userlist, -1, cUser);

  } /* end while */
    
  return TRUE;

}

/*

  Preload all users into a linked list.

 */
int PreLoadPassWords(BRUTEINFO *info, FILE *fd) {

  char cPass[32];
  
  memset(cPass, 0, sizeof(cPass));
  info->pwdlist = NULL;

  while( fgets(cPass, sizeof(cPass), fd) != NULL ) {
    
    strcpy( cPass, chomp( cPass ) );
    info->pwdlist = (SMBPWDS *) ll_addpw(info->pwdlist, cPass);

  } /* end while */
    
  return TRUE;

}

/* Get the next user from the userfile */
int GetNextUser(FILE *file, BRUTEINFO *info) {
  if ( fgets(info->user, 100, file) != NULL ) {

    /* trim the zero and cr from the pass */
    if ( info->user[strlen(info->user)-1] == '\n' ) {
      memset(info->user+strlen(info->user)-1, 0, 2);
    }

    if ( info->user[strlen(info->user)-1] == '\r' ) {
      memset(info->user+strlen(info->user)-1, 0, 2);
    }


    return TRUE;
  }

  return FALSE;
}

/* Get the next available password from passwdfile */
int GetNextPass(FILE *file, BRUTEINFO *info) {

  memset(info->pass, 0, 100);

  if ( fgets(info->pass, 100, file) != NULL ) {

    /* trim the zero and cr from the pass */
    if ( info->pass[strlen(info->pass)-1] == '\n' )
      memset(info->pass+strlen(info->pass)-1, 0, 2);
    
    /* do we have special password :last_word */
    if ( strcmp(info->pass, ":last_word") == 0 ) {
      strncpy(info->pass, info->user, strlen(info->user));
      memset(info->pass+strlen(info->user), 0, 1);
    }
    else if ( strcmp(info->pass, "lc :last_word") == 0 ) {
      strncpy(info->pass, lcase(info->user), strlen(info->user));
      memset(info->pass+strlen(info->user), 0, 1);
    }

    return TRUE;
  }

  return FALSE;
}
