/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "debug.h"
#include "smb.h"
#include "smbbf.h"
#include "smblib.h"
#include <stdio.h>
#include <stdlib.h>

void usage(char **argv) {

  printf("\n\tSMB - DumpUsers %s ", SMB_SUITE_VERSION);
  printf("by (%s)\n", SMB_SUITE_EMAIL);
  printf("\t-------------------------------------------------");
  printf("--------------------\n");
  printf("\tusage: smbdumpusers -i <ipaddress|ipfile> [options]\n\n");
  printf("\t\t-i*\tIP or <filename> of server[s] to bruteforce\n");
  printf("\t\t-m\tSpecify which mode\n");
  printf("\t\t\t    1 Dumpusers (Works with restrictanonymous=0)\n");
  printf("\t\t\t    2 SidToUser (Works with restrictanonymous=0|1)\n");
  printf("\t\t-f\tFilter output\n");
  printf("\t\t\t    0 Default (Filter Machine Accounts)\n");
  printf("\t\t\t    1 Show All\n");
  printf("\t\t-e\tAmount of sids to enumerate.\n");
  printf("\t\t-E\tAmount of sid mismatches before aborting mode 2\n");
  printf("\t\t-n\tStart at SID\n");
  printf("\t\t-s\tName of the server to bruteforce\n");
  printf("\t\t-r\tReport to <ip>.txt\n");
  printf("\t\t-t\ttimeout for connect (default 300ms)\n");
  printf("\t\t-v\tBe verbose\n");
  printf("\t\t-P\tProtocol version\n");
  printf("\t\t\t    0 - Netbios Mode\n");
  printf("\t\t\t    1 - Windows 2000 Native Mode\n");
  printf("\n");

}

int main(int argc, char **argv) {

  BRUTEINFO *pInfo = NULL;
  CMDARGS args;
  
  int c = 0, nMode = 0;
  FILE *ipfd = NULL; // ipfiledescriptor
  int breport = FALSE;
  int nFilter = 0;
  int nStart = 500, nError = 500, nAmount = -1;
   
  pInfo = ( BRUTEINFO * ) malloc ( sizeof( BRUTEINFO ) );

  if ( argc < 3 ) {
    usage(argv);
    exit(1);
  }

  pInfo->loglevel = 0;

  SMBInitialize(pInfo);
  memset(pInfo->server, 0, sizeof(pInfo->server));

  while (1) {

    c = getopt (argc, argv, "s:i:m:vhrf:n:e:P:E:t:");

    if ( c == -1 ) 
      break;

    switch (c) {
      
    case 'i':

      memset(pInfo->ip, 0, sizeof(pInfo->ip));
      // if we fail to open the i param as file, asume its a valid ip
      if ( ( ipfd = fopen(optarg, "r" ) ) == NULL ) {
	if ( strlen(optarg) > 15 ) {
	  exit(1);
	}
	strncpy(pInfo->ip, optarg, 15);
      }
      
      break;
	
    case 'm':
      nMode = atoi(optarg);
      if ( nMode != 1 && nMode != 2 ) {
	usage(argv);
	exit(1);
      }
      break;

    case 's':
      if ( strlen(optarg) > 16 )
	exit(1);

      strncpy(pInfo->server, optarg, 16);
      break;

    case 'h':
      usage(argv);
      exit(1);

    case 'n':
      nStart = atoi(optarg);
      nMode = 2;
      break;

    case 'E':
      nError = atoi(optarg);
      nMode = 2;
      break;

    case 'e':
      nAmount = atoi(optarg);
      nMode = 2;
      break;

    case 'v':
      args.verbose = TRUE;
      pInfo->loglevel = 3;
      break;

    case 'r':
      breport = TRUE;
      break;

    case 't':
      pInfo->timeout = atoi(optarg) * 1000;
      break;

    case 'f':
      nFilter = atoi(optarg);
      break;

    case 'P':
      pInfo->protocol = atoi(optarg);
      
      if ( pInfo->protocol != 0 && pInfo->protocol != 1 ) {
	fprintf(stderr, "Unsupported protocol !\n");
	exit(1);
      }

      break;

    default:
      usage(argv);
      exit(1);
    }
        
  }

  // did we have an ip file ?
  if ( ipfd != NULL ) {
    while ( fgets(pInfo->ip, sizeof(pInfo->ip), ipfd) != NULL ) {
      if ( pInfo->ip[strlen(pInfo->ip)-1] == '\n' )
	pInfo->ip[strlen(pInfo->ip)-1] = 0;

      if ( nMode == 1 )
	LSADumpUsers(pInfo);
      else if ( nMode == 2 )
	SidToUser(pInfo, nStart, nError, nAmount);
      else if ( LSADumpUsers(pInfo) != TRUE )
	SidToUser(pInfo, nStart, nError, nAmount);

      OutputUsers(pInfo, breport, nFilter);

      SMBInitialize(pInfo);
    }
  }
  else {
    if ( nMode == 1 )
      LSADumpUsers(pInfo);
    else if ( nMode == 2 )
      SidToUser(pInfo, nStart, nError, nAmount);
    else if ( LSADumpUsers(pInfo) != TRUE )
      SidToUser(pInfo, nStart, nError, nAmount);

    OutputUsers(pInfo, breport, nFilter);
  }

  free( pInfo );

  return TRUE;
}




