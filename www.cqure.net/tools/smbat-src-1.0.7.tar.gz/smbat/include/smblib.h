/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef SMBLIB_H
#define SMBLIB_H

#include <stdio.h>

typedef unsigned char UCHAR;

#ifndef SMB_SUITE_VERSION
#define SMB_SUITE_VERSION "V1.0.6"
#endif

#ifndef SMB_SUITE_EMAIL
#define SMB_SUITE_EMAIL "patrik@cqure.net"
#endif

#define BZERO(s, n)            memset(s, 0, n)
#define TRUE 0
#define FALSE 1
#define SMB_COM_NEGOTIATE  0x72

typedef struct item_ll {
  char item[32];
  struct item_ll *next;
} SMBPWDS;

typedef struct user_ll {
  char item[32];
  int nRID;
  struct user_ll *next;
} SMBUSERS;


typedef struct bruteinfo {
  int fd;
  char ip[20];
  UCHAR cmd;
  UCHAR sess_key[2];
  UCHAR lsaid[2]; 
  UCHAR tid[2];
  UCHAR fid;
  UCHAR pipe[2];
  UCHAR userid[2];
  UCHAR server[16];
  UCHAR myskoid[16];
  UCHAR rbuf[2048];
  UCHAR *header;
  UCHAR *data;
  UCHAR tmp[128];
  int tmplen;
  int protocol;
  int timeout;
  UCHAR domainsid[12];
  char workgroup[16];
  char challenge[8];
  char user[100];
  char pass[100];
  FILE *pwfile;
  int length;
  int rcvlen;
  int loglevel;
  char NativeOS[32];
  SMBUSERS *userlist;
  SMBPWDS *pwdlist;
  UCHAR error[4];
  int nMaxlogins;
}BRUTEINFO;

int SidToUser(BRUTEINFO *, int, int, int);
int LSADumpUsers(BRUTEINFO *);
void OutputUsers(BRUTEINFO *, int, int);
int RetrieveUsers(BRUTEINFO *);
int RetrieveComputerName(BRUTEINFO *);

#endif
