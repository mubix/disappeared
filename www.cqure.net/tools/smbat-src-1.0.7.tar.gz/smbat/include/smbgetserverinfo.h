
#ifndef _SMBGETSERVERINFO_H
#define _SMBGETSERVERINFO_H

typedef struct cmdargs {
  char user_file[255];
  char passwd_file[255];
  char report_file[255];
  int verbose;
  int force;
}CMDARGS;

#endif

