/* 
   SMB Auditing Tool
   Copyright (C) Patrik Karlsson 2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef SMB_H
#define SMB_H

#include "smblib.h"

void SMBInitialize(BRUTEINFO *);
int LSARetrieveUserInfo(BRUTEINFO *);
int LSAOpenPolicySetupPart4(BRUTEINFO *);
int LSAOpenPolicySetupPart3(BRUTEINFO *);
int LSAOpenPolicySetupPart5(BRUTEINFO *);
int LSAOpenPolicySetupPart2(BRUTEINFO *);
int LSAQueryDomainSID(BRUTEINFO *);
int LSAAskForComputerName(BRUTEINFO *);
int LSAOpenPolicySetup(BRUTEINFO *);
int LSASidToUser(BRUTEINFO *, int);
void SMBRequestBrowseList(BRUTEINFO *);
void SMBGetLoginLongError(BRUTEINFO *, char *);
int SMBNTCreateAndX(BRUTEINFO *);
void SMBNegProt(BRUTEINFO *);
int SMBConnect(BRUTEINFO *);
int SMBSend(BRUTEINFO *);
int SMBRecv(BRUTEINFO *);
int NBSSessionRequest(BRUTEINFO *);
int SMBTConX(BRUTEINFO *);
int SMBSessionSetupNullSession(BRUTEINFO *);
int SMBSessionSetup(BRUTEINFO *);
void SMBShutdown(const BRUTEINFO *);
int NBSSendSessionRequest(BRUTEINFO *);
int SMBSendNegProt(BRUTEINFO *);

#endif
