#ifndef _PACKET_H
#define _PACKET_H

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct hexPacket {
  unsigned int size;
  unsigned char *data;
} HEXPACKET;

HEXPACKET *createHexPacket(char *);
void freeHexPacket(HEXPACKET *);

#endif
