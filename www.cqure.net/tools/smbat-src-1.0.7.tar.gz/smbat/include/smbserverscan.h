
#ifndef _SMBSERVERSCAN_H
#define _SMBSERVERSCAN_H

#include <stdio.h>

typedef struct cmdargs {
  FILE *pIPFile;
  int verbose;
}CMDARGS;

typedef struct iplist {
  char ip[16];
  struct iplist *next;
} IPLIST;

typedef struct probe {
  BRUTEINFO info;
  CMDARGS args;
  struct probe *next;
} PROBE;

IPLIST *reverseIP(IPLIST *);

#endif
