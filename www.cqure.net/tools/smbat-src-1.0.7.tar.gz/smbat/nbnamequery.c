#include "netbios.h"

int main(int argc, char **argv) {

  char *pNetBiosName;

  pNetBiosName = NBNameQuery(argv[1]);
  printf("%s\n", pNetBiosName);

  free(pNetBiosName);

  return 0;

}
