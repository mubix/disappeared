/*
    Lodowep, A Lotus Domino online password auditing tool
    Copyright (C) 2002 Patrik Karlsson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    The author can be reached by email: patrik@cqure.net
*/

import java.util.*;

public class DominoOnlineBFThreadPool {


    private Vector m_oThreadVector = null;
    private int m_nThreads = -1;

    DominoOnlineBFThreadPool( int nSize ) {

	m_oThreadVector = new Vector();
	m_nThreads = nSize;

	for ( int i=0; i<nSize; i ++ )
	    m_oThreadVector.add( new DominoOnlineBFThread() );

    }
    

    public int activeCount() {

	int nCount = 0;

	for ( int i=0; i<m_nThreads; i++ ) {
	    
	    if ( ((Thread )m_oThreadVector.elementAt( i )).isAlive() ) {
		nCount ++;
	    }

	}

	return nCount;

    }

    public DominoOnlineBFThread getNextThread() {

	for ( int i=0; i<m_nThreads; i++ ) {
	    
	    if ( !((Thread )m_oThreadVector.elementAt( i )).isAlive() ) {
		return (DominoOnlineBFThread )m_oThreadVector.elementAt( i );
	    }

	}

	return null;

    }



}
