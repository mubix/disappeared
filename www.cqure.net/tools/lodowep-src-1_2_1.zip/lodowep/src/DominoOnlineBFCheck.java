/*
    Lodowep, A Lotus Domino online password auditing tool
    Copyright (C) 2002 Patrik Karlsson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    The author can be reached by email: patrik@cqure.net
*/

import java.io.*;
import java.net.*;
import gnu.getopt.*;

public class DominoOnlineBFCheck {


    public static boolean isValidBasicAuthenticationURL(String sURL) {

	URL oURL = null;
	HttpURLConnection oHttpConnection;

	try {
	    oURL = new URL( sURL );
	}
	catch ( MalformedURLException e ) {
	    System.err.println("ERROR: Failed to create URL ...\n");
	    e.printStackTrace();
	    return false;
	}

	try {
	    oHttpConnection = (HttpURLConnection) oURL.openConnection();
	    oHttpConnection.setInstanceFollowRedirects( false );
	    oHttpConnection.connect();

	    if ( oHttpConnection.getResponseCode() == HttpURLConnection.HTTP_UNAUTHORIZED )
		return true;
	}
	catch( IOException e ) {
	    return false;
	}

	return true;
    }

    public static boolean isValidFormBasedURL(String sURL) {
	
	URL oURL = null;
	HttpURLConnection oHttpConnection;
	Object oContent;
	LineNumberReader oIn;
	String sLine;
	String sContent = "";

	try {
	    oURL = new URL( sURL );
	}
	catch ( MalformedURLException e ) {
	    System.err.println("ERROR: Failed to create URL ...\n");
	    e.printStackTrace();
	    return false;
	}
	
	try {
	    oHttpConnection = (HttpURLConnection) oURL.openConnection();
	    oHttpConnection.setInstanceFollowRedirects( false );
	    oHttpConnection.connect();

	    oContent = oHttpConnection.getContent();

	    if ( oContent instanceof String ) {
		System.out.println("String: " + (String) oContent );
	    }
	    else if ( oContent instanceof InputStream ) {
		
		oIn = new LineNumberReader( new InputStreamReader( (InputStream)oContent ) );

		while ( ( sLine = oIn.readLine() ) != null ) 
		    sContent += sLine + "\n";

		/* 
		   If username and password is present within result
		   and form method action contains Login assume this
		   is a valid page
		*/

		if ( sContent.toLowerCase().indexOf("login") > -1 && 
		     sContent.toLowerCase().indexOf("name=\"username\"") > -1 &&
		     sContent.toLowerCase().indexOf("name=\"password\"") > -1 )
		    return true;

	    }
	    
	    
	}
	catch ( IOException e ) {
	    return false;
	}


	return false;

    }


}
