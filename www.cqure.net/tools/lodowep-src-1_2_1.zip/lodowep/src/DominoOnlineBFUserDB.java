/*
    Lodowep, A Lotus Domino online password auditing tool
    Copyright (C) 2002 Patrik Karlsson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    The author can be reached by email: patrik@cqure.net
*/

import java.io.*;
import java.util.Vector;
import java.lang.*;

public class DominoOnlineBFUserDB {

  
    private Vector m_oUservector  = new Vector();
    private Vector m_oPassvector  = new Vector();
    private PrintStream m_oOut = null;

    private boolean bFound = false;
    private boolean bWait  = false;

    private int m_nUserpos = 0;
    private int m_nPasspos = 0;

    private Integer nLock = new Integer(0);

    DominoOnlineBFUserDB () {

    }

    private void printReportHeader( ) {

	int nDashes = DominoOnlineBFVersion.getVersion().length();
	nDashes += DominoOnlineBFVersion.getAuthor().length();
	nDashes += 8; /* "Lodowep " */
	nDashes += 4; /* " by " */;
	
	String sHeader = "Lodowep " + DominoOnlineBFVersion.getVersion();
	sHeader += " by " + DominoOnlineBFVersion.getAuthor();

	m_oOut.println(sHeader);

	for ( int i=0; i<nDashes; i++ )
	    m_oOut.print("-");

	m_oOut.println();

    }

    public void closeReportFile() {

	if ( m_oOut != null ) {
	    m_oOut.close();
	    m_oOut = null;
	}

    }

    public boolean setReportFile( String sFilename ) {

	try {
	    m_oOut = new PrintStream( new FileOutputStream( sFilename ) );
	    printReportHeader();
	}
	catch( IOException e ) {
	    return false;
	}

	return true;

    }

    public String getPassword() {

	while ( bWait )
	    Thread.currentThread().yield();
	
	if ( bFound ) {
	    resetPassword();
	    m_nUserpos ++;
	}

	if ( m_oPassvector.size() - 1 > m_nPasspos ) {
	    String sPassword = (String) m_oPassvector.elementAt( m_nPasspos );
	    m_nPasspos ++;

	    return sPassword;
	}
	else {
	    resetPassword();
	    m_nUserpos ++;

	    return getPassword();
	}

    }

    public String getUsername() {

	while ( bWait )
	    Thread.currentThread().yield();

	if ( bFound ) {
	    resetPassword();
	    m_nUserpos ++;
	}
	
	if ( m_oUservector.size() - 1 > m_nUserpos ) {
	    String sUsername = (String) m_oUservector.elementAt( m_nUserpos );

	    return sUsername;
	}
	else {
	    return null;
	}

    }

    private void resetPassword() {
	m_nPasspos = 0;
	
	/* reset found flag */
	bFound = false;
    }

    public boolean loadUsers( String sFilename ) {

	String sLine = null;

	try {
	    LineNumberReader oIn = new LineNumberReader( new FileReader( sFilename ) );

	    do {
		sLine = oIn.readLine();
		m_oUservector.add( sLine );
	    } while ( sLine != null );
	}
	catch( IOException e ) {
	    return false;
	}

	return true;

    }

    public boolean loadPasswords( String sFilename ) {

	String sLine = null;

	try {
	    LineNumberReader oIn = new LineNumberReader( new FileReader( sFilename ) );

	    do {
		sLine = oIn.readLine();
		m_oPassvector.add( sLine );
	    } while ( sLine != null );
	}
	catch( IOException e ) {
	    return false;
	}

	return true;

    }


    public void addFoundAccount( String sUsername, String sPassword ) {

	if ( m_oOut != null ) {
	    m_oOut.println( sUsername + "\t\t" + sPassword );
	    m_oOut.flush();
	}

	System.out.println("INFO: Successfully compromised account " + sUsername + " with " + sPassword + ".");

	/* In cases where a larger dictionary is run against a
	   number of accounts, it make a great difference if
	   the attack would move to the next account as soon
	   as a valid password is found. This instead of testing
	   the rest of the supplied dictionary. Due to this fact
	   the thread getting here would simply tell the main thread
	   to wait retrieving the next username/password using the
	   bWait flag until it gets the chance to check if the username
	   is still the same as the one the thread has found a valid
	   password for. If this is the case the bFound flag is set.
	   Once this is done the bWait flag is set to false making it
	   possible for the "main" thread to continue retrieving
	   username and passwords. If the bFound flag is set the
	   "main" thread would reset the password vector and retrieve
	   the firsta password again and move the username vector ahead
	   one position.

	   I wonder if this is the stable way to do things :)
	   anyhow... it sure seems to work... so why bother !? :)

	   Please send me comments if you have a more beautiful
	   solution for this: patrik@cqure.net

	   Oh, and yes, isn't it fantastic that I put more effort into
	   this comment than to the whole block of code in this class,
	   since nobody will probably care to read it anyway :)
	*/

	synchronized ( nLock ) {

	    /* inform the other thread to wait retrieving username/password */
	    bWait = true;

	    /* are we still at the same position in the user vector */
	    if ( m_oUservector.indexOf( sUsername ) == m_nUserpos )
		bFound = true;

	    bWait = false;
	}

    }


}
