/*
    Lodowep, A Lotus Domino online password auditing tool
    Copyright (C) 2002 Patrik Karlsson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    The author can be reached by email: patrik@cqure.net
*/

import java.io.*;
import java.net.*;


public class DominoOnlineBFThread extends Thread {

    private static int FORMBASED_AUTHENTICATION = 0;
    private static int BASIC_AUTHENTICATION = 1;

    /* Where to report found passwords */
    DominoOnlineBFUserDB m_oUserDB = null;
    String m_sURL = null;
    String m_sUsername = null;
    String m_sPassword = null;
    int m_nMode = -1;

    DominoOnlineBFThread( int nMode, DominoOnlineBFUserDB oUserDB, String sURL, String sUsername, String sPassword ) {
	m_oUserDB = oUserDB;
	m_sURL = sURL;
	m_sUsername = sUsername;
	m_sPassword = sPassword;
	m_nMode = nMode;
    }

    DominoOnlineBFThread( ) {

    }

    public void setMode( int nMode ) {	m_nMode = nMode; }
    public void setUserDB( DominoOnlineBFUserDB oUserDB ) { m_oUserDB = oUserDB; }
    public void setURL( String sURL ) { m_sURL = sURL; }
    public void setUsername( String sUsername ) { m_sUsername = sUsername; }
    public void setPassword( String sPassword ) { m_sPassword = sPassword; }


    public void run() {

	HttpURLConnection oHttpConnection = null;
	URL oURL = null;
	LineNumberReader oReader = null;
	String sCookie = null;
	DataOutputStream oOut = null;
	String sContent = null;
	boolean bSuccess = false;
	String sAuth = null;

	/* if something fails loop forever :] */
	while ( !bSuccess ) {
	    	    
	    try {
		oURL = new URL(m_sURL);
	    }
	    catch ( MalformedURLException e ) {
		System.err.println("ERROR: Failed to create URL ...\n");
		e.printStackTrace();
	    }
	
	    try {
		oHttpConnection = (HttpURLConnection) oURL.openConnection();
		oHttpConnection.setInstanceFollowRedirects( false );

		if ( m_nMode == FORMBASED_AUTHENTICATION ) {

		    oHttpConnection.setRequestMethod("POST");
		    
		    oHttpConnection.setDoOutput( true );
		    oOut = new DataOutputStream( oHttpConnection.getOutputStream() );
		
		    sContent = "username=" + URLEncoder.encode(m_sUsername, "UTF-8") + "&";
		    sContent += "password=" + URLEncoder.encode(m_sPassword, "UTF-8");

		    oOut.writeBytes( sContent );
		    oOut.flush();
		    oOut.close();
		    oOut = null;

		    oHttpConnection.connect();

		    if ( oHttpConnection.getHeaderField("set-cookie") != null ) {
			m_oUserDB.addFoundAccount(m_sUsername, m_sPassword);
		    }

		    bSuccess = true;

		}
		else if ( m_nMode == BASIC_AUTHENTICATION ) {
		    
		    sAuth = Base64Converter.encode(m_sUsername + ":" + m_sPassword );
		    oHttpConnection.setRequestProperty ("Authorization", "Basic " + sAuth);
		    oHttpConnection.connect();
		    
		    if ( oHttpConnection.getResponseCode() == 200 ) {
			m_oUserDB.addFoundAccount(m_sUsername, m_sPassword);
		    }

		    bSuccess = true;

		}


	    }
	    catch ( IOException e ) {
		bSuccess = false;
		System.out.println("WARNING: Something failed ...\n");
		//e.printStackTrace();
	    }
	    
	}

	oURL = null;
	oHttpConnection.disconnect();
	oHttpConnection = null;

    }

}
