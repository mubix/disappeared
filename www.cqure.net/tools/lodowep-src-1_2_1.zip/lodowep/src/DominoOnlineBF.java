/*
    Lodowep, A Lotus Domino online password auditing tool
    Copyright (C) 2002 Patrik Karlsson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    The author can be reached by email: patrik@cqure.net
*/

import java.io.*;
import java.net.*;
import gnu.getopt.*;

public class DominoOnlineBF {

    private static int FORMBASED_AUTHENTICATION = 0;
    private static int BASIC_AUTHENTICATION = 1;

    private static void usage() {
	
	System.out.println("");
	System.out.println("\tLodowep " + DominoOnlineBFVersion.getVersion() + " by patrik@cqure.net");
	System.out.println("\t---------------------------------");
	System.out.println("\t -u - <userfile>");
	System.out.println("\t -p - <passwordfile>");
	System.out.println("\t -t - <targeturl>");
	System.out.println("\t -n - <threads>");
	System.out.println("\t -r - <reportfile>");
	System.out.println("\t -v - verbose (twice for debug)");
	System.out.println("\n");

    }

    public static void main(String args[]) {

	String sURL = null;
	String sPassword = "";
	String sUsername = "";
	String sUserfile = null;
	String sPassfile = null;
	int nThreads = 20;

	String sArg;
	int nMode;

	Getopt oOpt = new Getopt("Lodowep", args, "n:u:p:t:vr:h");

	DominoOnlineBFThread oThread = null;
	DominoOnlineBFThreadPool oThreadPool = null;
	DominoOnlineBFUserDB oUserDB = new DominoOnlineBFUserDB();

	boolean bDebug = false, bVerbose = false;
	int c;
	int nPos;

	/* parse arguments */
	while ( ( c = oOpt.getopt() ) != -1 ) {
	
	    switch( c ) {

	    case 'n':
		sArg = oOpt.getOptarg();
		nThreads = Integer.parseInt( sArg );
		break;

	    case 'u':
		sUserfile = oOpt.getOptarg();
		break;

	    case 'p':
		sPassfile = oOpt.getOptarg();
		break;

	    case 't':
		//sURL = "http://" + oOpt.getOptarg() + "/names.nsf?Login";
		sURL = oOpt.getOptarg().trim();
		break;

	    case 'r':
		oUserDB.setReportFile( oOpt.getOptarg() );
		break;

	    case 'v':
		if ( bVerbose == true )
		    bDebug = true;
		else
		    bVerbose = true;

		break;

	    case 'h':
		usage();
		System.exit(1);
		break;

	    default:
		usage();
		System.exit(0);
	    }

	}

	if ( ( sUserfile == null ) || ( sPassfile == null ) ||
	     ( sURL == null ) ) {
	    usage();
	    System.exit(1);
	}

	if ( !oUserDB.loadUsers( sUserfile ) ) {
	    System.err.println("ERROR: Failed loading user file");
	    System.exit(1);
	}

	if ( !oUserDB.loadPasswords( sPassfile ) ) {
	    System.err.println("ERROR: Failed loading dic file");
	    System.exit(1);
	}

	if ( sURL.substring(sURL.length()-6).equalsIgnoreCase("?login") ) {
	    System.err.println("ERROR: Invalid URL, skip the ?login ...");
	    System.exit(1);
	}

	if ( !sURL.substring(sURL.length()-4).equalsIgnoreCase(".nsf") ) {
	    System.err.println("ERROR: No database supplied");
	    System.exit(1);
	}

	if ( !DominoOnlineBFCheck.isValidFormBasedURL(sURL) ) {

	    if ( !DominoOnlineBFCheck.isValidBasicAuthenticationURL(sURL) ) {
		System.out.println("ERROR: Could not determine authentication method");
		System.exit(1);
	    }

	    nMode = BASIC_AUTHENTICATION;

	}
	else {
	    nMode = FORMBASED_AUTHENTICATION;
	    /* make sure we have ?login at the end of the URL */
	    if ( !sURL.substring(sURL.length()-6).equalsIgnoreCase("?login") )
		sURL += "?login";
	}

	oThreadPool = new DominoOnlineBFThreadPool( nThreads );

	while ( ( sPassword != null ) && ( sUsername != null ) ) {

	    if ( ( oThread = oThreadPool.getNextThread() ) != null ) {

		sPassword = oUserDB.getPassword();
		sUsername = oUserDB.getUsername();
		
		if ( sUsername != null )
		    sUsername.trim();

		if ( sPassword != null )
		    sPassword.trim();

		if ( sPassword != null && sPassword.equalsIgnoreCase("%username%") ) {

		    if ( sUsername != null ) {

			nPos = sUsername.indexOf("/");
		    
			if ( nPos > -1 )
			    sPassword = sUsername.substring(0, nPos);
			else
			    sPassword = sUsername;

		    }

		}

		if ( sPassword != null && sPassword.equalsIgnoreCase("lc %username%") ) {

		    if ( sUsername != null ) {

			nPos = sUsername.indexOf("/");
			
			if ( nPos > -1 )
			    sPassword = sUsername.substring(0, nPos).toLowerCase();
			else
			    sPassword = sUsername.toLowerCase();

		    }

		}

		if ( ( sPassword != null ) && ( sUsername != null ) ) {
		    
		    oThread.setMode( nMode );
		    oThread.setUserDB( oUserDB );
		    oThread.setURL( sURL );
		    oThread.setUsername( sUsername );
		    oThread.setPassword( sPassword );

		    oThread.run();

		    if ( bVerbose ) {
			System.out.println("INFO: Trying Username: " +sUsername+ " Password: " + sPassword);
		    }

		}

	    }
	    else {
		if ( bDebug )
		    System.out.println("DEBUG: All threads active, waiting for one to finnish");

		try {
		    Thread.currentThread().sleep(100);
		}
		catch ( InterruptedException e ) {
		    System.err.println("ERROR: The main thread failed to sleep for 200 ms");
		}
	    } /* end else */

	    Thread.currentThread().yield();

	}/* end while */

	/* Wait for all threads to finnish before closing report file */
	while ( oThreadPool.activeCount() > 0 ) {
	    try {
		Thread.currentThread().sleep(100);
	    }
	    catch( InterruptedException e ) {
		System.err.println("ERROR:");
	    }
	}

	oUserDB.closeReportFile();

    }



}
