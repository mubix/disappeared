#!/bin/sh
#
# Wrapper for Cifs Password Scanner by patrik@cqure.net
#

CP=.:cifspwscan.jar:java-getopt-1.0.9.jar:jcifs-0.9.7.jar
java -cp $CP cqure.CifsPwScanner $*