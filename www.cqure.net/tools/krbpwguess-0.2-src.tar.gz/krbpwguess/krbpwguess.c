/*
Copyright (c) 2009 Patrik Karlsson, cqure.net. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <krb5.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <err.h>
#include <sys/errno.h>
#include <sys/time.h>
#include <fcntl.h>
#include <termios.h>

#include "krbpwguess.h"

int verbose = FALSE;
FILE *pLogFile = NULL;

struct timeval start;
int guesses = 0;

static int tty_fd = 0;
static struct termios saved_ti;

/* tty-code shamelessly stolen from NMAP-5 --- START --- */
static int tty_getchar()
{
	int c, numChars;
#ifdef __CYGWIN32__
	fd_set set;
	struct timeval tv;
#endif
        
	if (tty_fd && tcgetpgrp(tty_fd) == getpid()) {
           
           // This is so that when the terminal has been disconnected, it will be reconnected when possible. If it slows things down, just remove it
           // tty_init();
           
#ifdef __CYGWIN32__
		FD_ZERO(&set); FD_SET(tty_fd, &set);
		tv.tv_sec = 0; tv.tv_usec = 0;
		if (select(tty_fd + 1, &set, NULL, NULL, &tv) <= 0)
			return -1;
#endif
		c = 0;
                numChars = read(tty_fd, &c, 1);
		if (numChars > 0) return c;
	}

	return -1;
}

static void tty_done()
{
	if (!tty_fd) return;

	tcsetattr(tty_fd, TCSANOW, &saved_ti);

	close(tty_fd);
	tty_fd = 0;
}

static void tty_flush(void)
{
	/* we don't need to test for tty_fd==0 here because
	 * this isn't called unless we succeeded
	 */

	tcflush(tty_fd, TCIFLUSH);
}

/*
 * Initializes the terminal for unbuffered non-blocking input. Also
 * registers tty_done() via atexit().  You need to call this before
 * you ever call keyWasPressed().
 */
void tty_init()
{
	struct termios ti;

	if (tty_fd)
		return;

	if ((tty_fd = open("/dev/tty", O_RDONLY | O_NONBLOCK)) < 0) return;

#ifndef __CYGWIN32__
	if (tcgetpgrp(tty_fd) != getpid()) {
		close(tty_fd); return;
	}
#endif

	tcgetattr(tty_fd, &ti);
	saved_ti = ti;
	ti.c_lflag &= ~(ICANON | ECHO);
	ti.c_cc[VMIN] = 1;
	ti.c_cc[VTIME] = 0;
	tcsetattr(tty_fd, TCSANOW, &ti);

	atexit(tty_done);
}

/* tty-code shamelessly stolen from NMAP-5 --- END --- */

void logEntry(FILE *pFD, const char *prefix, const char *fmt, va_list args)
{
	va_list args2;
	
	va_copy(args2, args);
	fprintf(pFD, "%s ", prefix);
	vfprintf(pFD, fmt, args2);
	fprintf(pFD, "\n");
	va_end(args2);
	
	if ( NULL != pLogFile )
	{
		va_copy(args2, args);
		fprintf(pLogFile, "%s ", prefix);
		vfprintf(pLogFile, fmt, args2);
		fprintf(pLogFile, "\n");		
		fflush(pLogFile);
		va_end(args2);
	}
}

void logError(const char *fmt, ...)
{
	va_list args;
	
	va_start(args,fmt);
	logEntry(stderr, "[ERROR]", fmt, args );
	va_end(args);
}

void logInfo(const char *fmt, ...)
{
	va_list args;
	
	va_start(args,fmt);
	logEntry(stdout, "[INFO]", fmt, args );
	va_end(args);
}

void logDebug(const char *fmt, ...)
{
	va_list args;
	
	va_start(args,fmt);
	logEntry(stdout, "[DEBUG]", fmt, args);
	va_end(args);
}

void logTrace(const char *fmt, ...)
{
	va_list args;
	
	va_start(args,fmt);
	logEntry(stdout, "[TRACE]", fmt, args);
	va_end(args);
}

void printKDCList(krb5_context context, const char *realm)
{
  krb5_krbhst_handle handle;
  char host[255];
  krb5_krbhst_init(context, realm, KRB5_KRBHST_KDC, &handle);
  while(krb5_krbhst_next_as_string(context, handle,
				   host, sizeof(host)) == 0)
  printf("%s\n", host);
  krb5_krbhst_free(context, handle);
}

int countKDCs(krb5_context context, const char *realm)
{
  krb5_krbhst_handle handle;
  char host[255];
  int hosts;

  krb5_krbhst_init(context, realm, KRB5_KRBHST_KDC, &handle);

  while(krb5_krbhst_next_as_string(context, handle,
				   host, sizeof(host)) == 0)
    hosts++;

  krb5_krbhst_free(context, handle);

  return hosts;
}

int guessPassword(const char *realm, const char *user, const char *pass)
{
	krb5_error_code error;
	krb5_principal princ;
	krb5_context context;
	
	struct timeval curr;

	char principal[1024];
	char *errorTxt;
	
	int c = 0;
	
	if ( strlen( realm ) + strlen(user) + 2 > sizeof( principal ) )
	{
		logError("Username or realm/domain name too long");
		exit(-1);
	}
		
	if ( 0 == strcmp("\%username\%", pass ) )
	{
		pass = user;
	}
	
	memset(principal, 0, sizeof principal);
	snprintf(principal, sizeof(principal), "%s@%s", user, realm);

	if (krb5_init_context(&context) < 0)
		errx(1, "krb5_init_context");

	if ( verbose )
		logTrace("Guessing %s/%s", user, pass );


	if ((error = krb5_parse_name(context, principal, &princ)) != 0)
	{
		errorTxt = (char *)krb5_get_err_text(context, error);
		fprintf(stderr, "ERROR: %s\n", errorTxt);
		return ERROR_UNKNOWN;
	}
	
	guesses ++;
	
	if ((c = tty_getchar()) >= 0) {
    	tty_flush(); /* flush input queue */

		gettimeofday(&curr, NULL);
	
		/* we don't want any division by zero */
		if ( 1 < (int)(curr.tv_sec-start.tv_sec) )
			printf("[STAT] current: %s/%s\telapsed: %d seconds\ttps: %.0f\n", user, pass, (int)(curr.tv_sec-start.tv_sec), (float)(guesses/(int)(curr.tv_sec-start.tv_sec)) );
	}
	
			
	if ( (error = krb5_verify_user(context, princ, NULL, pass, TRUE, NULL)) )
	{
		errorTxt = (char *)krb5_get_err_text(context, error);
	
		if ( NULL != strstr( errorTxt, "Client not found in Kerberos database" ) )
			return ERROR_CLIENT_NOT_FOUND;
		else if ( NULL != strstr(errorTxt, "Clients credentials have been revoked") )
		{
			return ERROR_ACCOUNT_LOCKED_OUT;
		}
		else if ( NULL != strstr(errorTxt, "Preauthentication failed"))
		{
			return ERROR_PREAUTH_FAILED;
		}
		else if ( NULL != strstr(errorTxt, "Decrypt integrity check failed"))
		{
			return ERROR_NO_PREAUTH_REQUIRED;
		}
		else if ( NULL != strstr(errorTxt, "Server not found in Kerberos database") )
		{
			// Authentication was succesful but server principal could not be retrieved from DB (host/`hostname`)
			return ERROR_NO_ERROR;
		}
		else if ( NULL != strstr(errorTxt, "Clock skew too great") )
		{
			return ERROR_NO_ERROR;
		}
		else
		{
			logError("%s", errorTxt);
			return ERROR_UNKNOWN;			
		}
		
	}

	return ERROR_NO_ERROR;

}

void header(FILE *pFD)
{
	int i;
	int c = fprintf(pFD, "%s v%s by %s\n", APPNAME, VERSION, AUTHOR);
	for( i=0; i<c-1; i++ )
		fprintf(pFD, "-");

	fprintf(pFD, "\n");
	
}

void usage(char *prg)
{
	header(stdout);
	
	printf("%s [options]\n", prg);
	printf("\t-d\t- amount of ms to wait between requests (default 50 ms)\n");
	printf("\t-u\t- location of file containing usernames\n");
	printf("\t-p\t- location of file containing passwords\n");
	printf("\t-r\t- name of realm/domain\n");
	printf("\t-o\t- write output to filename\n");
	printf("\t-v\t- verbose mode\n");

	printf("\n");
	
	
}

void trim( char *line )
{
	while( 0 < strlen(line) && ('\r' == line[strlen(line)-1] || '\n' == line[strlen(line)-1] ) )
		line[strlen(line)-1] = 0;
	
}

int main(int argc, char **argv)
{
	int c, error, delay = 50;
	
	char *realm = NULL, *users = NULL, *passwords = NULL, *outfile = NULL, *pEnd;
	char username[255], password[255];
	
	FILE *userFD, *passFD;

    while ((c = getopt(argc, argv, "d:u:p:r:vo:")) != -1) {
		switch (c) 
		{
			case 'd':
				delay = strtol(optarg, &pEnd, 10);
				if (*pEnd != '\n' && *pEnd != '\0')
				{
					header(stdout);
					logError("%s","Incorrect delay supplied.\n");
					exit(1);
				}
				break;
			case 'r':
				realm = strdup(optarg);
				break;
			case 'u':
				users = strdup(optarg);
				break;
			case 'p':
				passwords = strdup(optarg);
				break;
			case 'v':
				verbose = TRUE;
				break;
			case 'o':
				outfile = strdup(optarg);
				break;
			default:
				usage(argv[0]);
				exit(1);
		}
	}

	if ( NULL == realm || NULL == users || NULL == passwords )
	{
		usage(argv[0]);
		exit(1);
	}

	if ( NULL != outfile )
	{
		if ( NULL == ( pLogFile = fopen(outfile, "w") ) )
		{
			logError("Failed to create output file: %s", outfile);
			exit(1);
		}
		header(pLogFile);
	}


	userFD = fopen(users, "r");
	passFD = fopen(passwords, "r");

	header(stdout);
	gettimeofday(&start, NULL);
	
	tty_init();
	
	while( NULL != fgets( username, sizeof username, userFD ) )
	{
		while ( NULL != fgets( password, sizeof password, passFD) )
		{
			trim(username);
			trim(password);
						
			error = guessPassword( realm, username, password );
			
			if (ERROR_CLIENT_NOT_FOUND == error)
			{
				break;
			}
			else if ( ERROR_ACCOUNT_LOCKED_OUT == error )
			{
				logError("Account %s@%s locked out", username, realm);
				break;
			}
			else if( ERROR_NO_PREAUTH_REQUIRED == error )
			{
				logInfo("Got TGT for account %s@%s", username, realm);
				break;
			}
			else if( ERROR_NO_ERROR == error )
			{
				logInfo("Found %s@%s/%s", username, realm, password);
				break;
			}
			
			usleep( delay * 1000 );
		}
				
		if (ERROR_CLIENT_NOT_FOUND == error)
		{
			error = 0;
			rewind(passFD);
			continue;
		}
		
	}

	if ( NULL != pLogFile )
		fclose(pLogFile);

	tty_done();

	return 0;

}
