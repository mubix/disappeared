const char *VERSION = "0.2";
const char *AUTHOR  = "Patrik Karlsson <patrik@cqure.net>";
const char *APPNAME = "krbpwguess";

const int ERROR_NO_ERROR	    = 0;
const int ERROR_CLIENT_NOT_FOUND    = 1;
const int ERROR_ACCOUNT_LOCKED_OUT  = 2;
const int ERROR_PREAUTH_FAILED      = 3;
const int ERROR_NO_PREAUTH_REQUIRED = 4;
const int ERROR_UNKNOWN		    = -1;
