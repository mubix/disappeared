/* 
   SQL Password Auditing Tool
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <time.h>
#ifdef WIN32
#include <windows.h>
#include <conio.h>
#include "getopt.h"
#else
#include <pthread.h>
#include <sys/times.h>
#include <termio.h>
#include <getopt.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "crypto.h"
#include "sqlbf.h"
#include "bf.h"


/*
 * Global variables
 */ 
struct  passwordlist *pwlist;
struct  hashlist	 *hlist;
char    bQuit;
double  startTime = 0;
char	nMode;
double  nTotTries;
FILE	*fdReportFile = NULL;

#ifdef WIN32
const   int nTimeDiv = 1000;
#else
const   int nTimeDiv = 100;
#endif

#ifndef WIN32
struct termios stored_settings;

void set_keypress(void) {

     struct termios new_settings;
     tcgetattr(0,&stored_settings);
     new_settings = stored_settings;
     new_settings.c_lflag &= (~ICANON);
     new_settings.c_lflag &= (~ECHO);
     new_settings.c_cc[VTIME] = 0;
     tcgetattr(0,&stored_settings);
     new_settings.c_cc[VMIN] = 1;
     tcsetattr(0,TCSANOW,&new_settings);

}



void reset_keypress(void) {
     tcsetattr(0,TCSANOW,&stored_settings);
}

#endif

struct passwordlist *addpw(struct passwordlist *pwlist, char *pw, char *pwuc, int nLen) {

	struct passwordlist *tmplist;
	
	tmplist = (struct passwordlist *) malloc( sizeof( struct passwordlist ) );
	tmplist->pwuc = malloc ( strlen(pw) * 2 + 4 );
	memset( tmplist->pw, 0, sizeof( tmplist->pw ) );
	memset( tmplist->pwuc, 0, strlen(pw) * 2 + 4 );
	memcpy( tmplist->pw, pw, sizeof( tmplist->pw) );
	memcpy( tmplist->pwuc, pwuc, strlen(pw) * 2 + 4 );

	tmplist->pwlen = nLen;

	tmplist->next = pwlist;
	pwlist = tmplist;

	return pwlist;

}

struct hashlist *addhash( struct hashlist *hlist, struct hashlist *hash2add) {

	struct hashlist *newhash;

	newhash = ( struct hashlist *) malloc ( sizeof( struct hashlist ) );
	memcpy( newhash, hash2add, sizeof(struct hashlist ) );
	newhash->found = 0;

	newhash->next = hlist;
	hlist = newhash;

	return hlist;
}


void freepw(struct passwordlist *pwlist) {

	struct passwordlist *rmv;
	struct passwordlist *curr;

	curr = pwlist;

	while ( curr ) {
		rmv = curr;
		curr = curr->next;
		free(rmv->pwuc);
		free(rmv);
	}

}

void parseCommaSeparated( char *line, char *username, char *password ) {

	/* Assume format of username, password */
	int nPos = 0;

	while ( nPos < (int) strlen(line) ) {
		if ( line[nPos] == ',' )
			break;
		nPos ++;
	}

	if ( nPos > 1 ) {
		memcpy( username, line, nPos );
		nPos ++; /* get rid of the comma */
		memcpy( password, line+nPos, strlen(line) - nPos );
	}

}

void processHash( char *hash, struct hashlist *hashes ) {
	
	char salt[8];
	unsigned char hex[2];
	unsigned char hex2[2];
	int i;
	unsigned int hex3;

	memcpy( salt, hash+6, sizeof(salt));

	for ( i=0; i<sizeof( hashes->salt ); i ++ ) {
		memcpy( hex, salt + i * 2, 2 );
		sscanf(hex, "%2x", &hex3);
		hashes->salt[i]=hex3;
	}
	
	for ( i=0; i<MD_SIZE*2; i++ ) {
		memcpy( hex, hash + 6 + 8 + i*2, 2 );
		sscanf(hex, "%2x", &hex3);
		hashes->mchash[i] = hex3;
	}

	for ( i=0; i<MD_SIZE*2; i++ ) {
		memcpy( hex, hash + 6 + 8 + i*2 + MD_SIZE*2, 2 );
		sscanf(hex, "%2x", &hex3);
		hashes->uchash[i], hex3;
	}

}

int preloadCharacterMap( char *pFileName, char *pCharSet ) {

	FILE *fd;
	int nSize = 0;

	if ( ( fd = fopen( pFileName, "r" ) ) == NULL )
		return -1;

	memset( pCharSet, 0, CHARSET_MAXSIZE );
	fgets( pCharSet+1, CHARSET_MAXSIZE, fd ); /* the first byte should be a 0 */

	nSize = strlen( pCharSet+1 );
	
	return nSize;

}

int preloadHashFile( char *pFileName, int nFormat ) {

	FILE *fd;
	int nLen;
	char line[256];
	char hash[100];
	struct hashlist hashes;
	int hashCount = 0;

	hlist  = NULL;

	if ( ( fd = fopen( pFileName, "r" ) ) == NULL )
		return -1;

	memset( line, 0, sizeof(line));
	
	while ( fgets( line, sizeof( line ), fd ) != NULL ) {

		nLen = strlen(line);

		while (  ( line[nLen-1] == '\n' ) || ( line[nLen-1] == '\r' ) ) {
		  memset(line+nLen-1, 0, 2);
		  nLen --;
		} /* end if */

		memset( hashes.username, 0, sizeof(hashes.username) );
		memset( hash, 0, sizeof(hash) );
		parseCommaSeparated( line, (char *)&hashes.username, (char *)&hash );
		processHash( hash, &hashes );
		hlist = addhash( hlist, &hashes );

		hashCount ++;
	}
		
	return hashCount;

}


double preloadPasswords( char *pFileName ) {

	FILE *fd;
	char tmppw[40];
	char pwUnicoded[80];
	int i, nLen, nPasswords = 1;

	pwlist = NULL;

	if ( ( fd = fopen( pFileName, "r" ) ) == NULL )
		return -1;

	memset( tmppw, 0, sizeof(tmppw) );

	while ( fgets( tmppw, sizeof( tmppw ), fd ) != NULL ) {
	
		memset( pwUnicoded, 0, sizeof(pwUnicoded) );
		nLen = strlen(tmppw);
		
		while ( tmppw[nLen-1] == '\n' || tmppw[nLen-1] == '\r' ) {
		  memset(tmppw+nLen-1, 0, 2);
		  nLen --;
		} /* end if */

		/* convert all to uppercase */
		for ( i=0; i<nLen; i++ )
			tmppw[i] = toupper( tmppw[i] );

		doUnicode( tmppw, pwUnicoded, nLen);
		pwlist = addpw( pwlist, tmppw, pwUnicoded, nLen );
		memset( tmppw, 0, sizeof(tmppw) );
		nPasswords ++;
	}

	return nPasswords;

}

void dicAttack() {

	unsigned char *md;
	struct hashlist *topoflist = hlist;

	md = (unsigned char *) malloc( MD_SIZE );

	while ( pwlist ) {

		while ( hlist ) {
		
			if ( !hlist->found ) {

				mssqlHash(md, pwlist, hlist->salt);
				nTotTries ++;
		
				if ( compareHashes( md, hlist->uchash ) ) {

					nTotTries += getMixedCasePwFromUCPw( hlist, pwlist );
					
					if ( fdReportFile != NULL )
						fprintf(fdReportFile, "User: %-20s Pw: %-20s\n", hlist->username, pwlist->pw);

					fprintf(stderr, "User: %-20s Pw: %-20s\n", hlist->username, pwlist->pw);

					hlist->found = 1;
				}
		
			} /* end if */

			hlist = hlist->next;

		} /* end while ( hlist ) */
	
		hlist = topoflist;
		pwlist = pwlist->next;
	
	} /* end while pwlist */

	free(md);

}


void bfAttack(char *pCharSet, int nNumOfChars) {

	char pwd[20];
	char mask[20] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

	CHARSET cs;
	MASK msk;
	PASS pw;
	
	unsigned char *md;	
	struct hashlist *topoflist = hlist;

	pwlist = (struct passwordlist *) malloc ( sizeof( struct passwordlist ) );

	memset( pwd, 0, 20 );

	cs.pCharset = (char *)pCharSet;
	cs.nLength = nNumOfChars;

	msk.pMask = (char *)&mask;
	msk.nLength = sizeof(mask)-1;

	pw.pPass = (char *) malloc ( 20 );
	pw.nLength = 1;
	memset( pw.pPass, 0, 20);

	md = (unsigned char *) malloc( MD_SIZE );
	pwlist->pwuc = ( char * ) malloc ( 100 ); /* should be enough */

	while ( !bQuit ) {

		pwBruteForce((PASS *)&pw, (CHARSET *)&cs, (MASK *)&msk);

		doUnicode( pw.pPass, pwlist->pwuc, pw.nLength);
		
		pwlist->pwlen = pw.nLength;
		memcpy( pwlist->pw, pw.pPass, pw.nLength );
		pwlist->pw[pw.nLength] = '\0';

		pwlist->next = NULL;

		while ( hlist ) {

			if ( !hlist->found ) {

				mssqlHash(md, pwlist, hlist->salt);
				nTotTries ++;

				if ( compareHashes( md, hlist->uchash ) ) {

				  nTotTries += getMixedCasePwFromUCPw( hlist, pwlist );

					if ( fdReportFile != NULL )
						fprintf(fdReportFile, "User: %-20s Pw: %20s\n", hlist->username, pw.pPass);

					fprintf(stderr, "User: %-20s Pw: %20s\n", hlist->username, pw.pPass);
					hlist->found = 1;
				}

		
			} /* end if */
			
			hlist = hlist->next;
		
		}

		hlist = topoflist;

	}

	free( pwlist->pwuc );
	free( md );

}

#ifdef WIN32
DWORD WINAPI getStats( LPVOID lpParam ) {
#else
void *getStats(void *arg) {	
#endif

	char ch;
	double nTimeDelta;

#ifndef WIN32	
	struct tms t;
#endif

	while ( 1 ) {
#ifdef WIN32
	        ch = getch();
#else
		ch = getchar();
#endif
		if ( ch == ' ' ) {
			nTimeDelta = clock() - startTime;
#ifndef WIN32
			nTimeDelta = times(&t) - startTime;
#endif
			fprintf(stderr, "Time elapsed : %f seconds.\n", nTimeDelta/nTimeDiv);
			fprintf(stderr, "Approx tries/sec: %f.\n", nTotTries/(nTimeDelta/nTimeDiv));
			fprintf(stderr, "Current guess: %s\n\n", pwlist->pw );

		}
		else if ( ch == 'q' ) {
		        fprintf(stderr, "Really Quit (Y/N) ?\n");
#ifdef WIN32
			ch = getch();
#else 
			ch = getchar();
#endif
			if ( ch == 'y' )
				bQuit = 1;
		}
	}

#ifdef WIN32
	pthread_exit(1);
	return 0;
#endif

}

FILE *createReportFile( char *pFileName ) {

	FILE *fd;

	if ( ( fd = fopen( pFileName, "w" ) ) == NULL )
		return NULL;
	
	fprintf(fd, "MS SQL Server Password Auditing Report\n");
	fprintf(fd, "----------------------------------------------------------------\n");
	fprintf(fd, "\n");

	return fd;

}

void closeReportFile( FILE *fd ) {

	fprintf(fd, "\n----------------------------------------------------------------\n");
	fprintf(fd, "MSSQL Password Auditing Tool by patrik.karlsson@se.pwcglobal.com\n");
	fprintf(fd, "----------------------------------------------------------------\n");
	fclose( fd );

}

void usage(char **argv) {

	fprintf(stderr, "\n");
	fprintf(stderr, "MS SQL Server Password Auditing Tool Version %s\n", SQLPAT_VERSION);
	fprintf(stderr, "----patrik.karlsson@se.pwcglobal.com--------------\n\n");
	fprintf(stderr, "usage: %s -u [options]\n", argv[0] );
	fprintf(stderr, "\n");
	fprintf(stderr, "Options:\n");
	fprintf(stderr, "\t-c <csfile>\t- the character set\n");
	fprintf(stderr, "\t-d <dictionary>\t- the dictionary file\n");
	fprintf(stderr, "\t-u <userfile>\t- the user & hash file\n");
	fprintf(stderr, "\t-r <reportfile>\t- the report file\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "If no dic. file is supplied BF mode is asumed\n");
	fprintf(stderr, "\n");

}

int main( int argc, char **argv) {

	double elapsedtime, nPasswords, nHashes;
	char *pCharSet = NULL;
	int nNumOfChars = 0;
	int c;
	char CharSetFile[256], HashesFile[256], DicFile[256], ReportFile[256];

#ifdef WIN32
	/* Windows goes here */
	DWORD dwThreadId, dwThrdParam = 1; 
	HANDLE hThread; 
#else
	/* Unix goes here */
	pthread_attr_t attr;
	pthread_t th1;
	struct tms t;
#endif

	nPasswords = 0;
	nHashes = 0;
	nMode = MODE_DIC;
	nTotTries = 0;

	memset( CharSetFile, 0, sizeof( CharSetFile ) );
	memset( HashesFile, 0, sizeof( HashesFile ) );
	memset( DicFile, 0, sizeof( DicFile ) );
	memset( ReportFile, 0, sizeof( ReportFile ) );
	strcpy( CharSetFile, "default.cs");

	while (1) {

		c = getopt (argc, argv, "c:d:u:hr:");

	    if ( c == -1 )
			break;

		switch (c) {
      
		    case 'c':
				strncpy( CharSetFile, optarg, sizeof ( CharSetFile ) );
				break;

			case 'd':
				strncpy( DicFile, optarg, sizeof( DicFile ) );
				break;

			case 'u':
				strncpy( HashesFile, optarg, sizeof( HashesFile ) );
				break;

			case 'r':
				strncpy( ReportFile, optarg, sizeof( ReportFile ) );
				break;
			
			default:
				usage(argv);
				exit(1);

		}

	}

	if ( strlen( HashesFile ) == 0 ) {
		usage(argv);
		exit(1);
	}
	
	if ( strlen( DicFile ) == 0 ) {
		nMode = MODE_BF;
	}

	nHashes = preloadHashFile( HashesFile, -1 );

	if ( nHashes == -1 ) {
	  fprintf(stderr, "ERROR: No hashes where found\n");
	  exit(1);
	}
	
	if ( nMode != MODE_BF )
		nPasswords = preloadPasswords( DicFile );
	else {
	
		pCharSet = ( char * ) malloc ( CHARSET_MAXSIZE );
		nNumOfChars = preloadCharacterMap( CharSetFile, pCharSet );		

		if ( nNumOfChars == -1 ) {
			fprintf(stderr, "ERROR: Loading charactermap\r\n");
			exit(1);
		}

	}

	if ( nPasswords == -1 ) {
		fprintf(stderr, "ERROR: Opening pwfile\r\n");
		exit(1);
	}

	/*
	if ( nMode != MODE_BF )
		fprintf(stderr, "INFO: Preloaded %f passwords\n", nPasswords);
	*/

/* create a stat thread */
#ifdef WIN32
    hThread = CreateThread( NULL, 0, getStats, NULL, 0, &dwThreadId);
#else
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    set_keypress();
#endif

	if ( strlen( ReportFile ) > 0 )
		fdReportFile = createReportFile( ReportFile );

#ifdef WIN32
	startTime = clock();
#else
	startTime = times(&t);
#endif

	if ( nMode == MODE_BF ) {
		fprintf(stdout, "Starting BruteForce attack on hashes ...\n" );
		fprintf(stdout, "Press <space> for statistics <q> to Quit\n\n\n" );
#ifndef WIN32
		pthread_create(&th1, &attr, getStats, NULL);
#endif
		bfAttack( pCharSet, nNumOfChars );
	}
	else {
		fprintf(stdout, "Starting Dictionary attack on hashes ...\n" );
		fprintf(stdout, "Press <space> for statistics <q> to Quit\n\n\n" );
#ifndef WIN32
		pthread_create(&th1, &attr, getStats, NULL);
#endif
		dicAttack();
	}

#ifndef WIN32
	elapsedtime = times(&t) - startTime;
#else
	elapsedtime = clock()-startTime;
#endif
	fprintf(stderr, "\n");
	fprintf(stderr, "Time elapsed : %f seconds.\n", elapsedtime/nTimeDiv);
	fprintf(stderr, "Approx. guesses per second : %f\n", nTotTries/elapsedtime*nTimeDiv);


	if ( fdReportFile )
		closeReportFile( fdReportFile );

	if ( pCharSet ) 
		free( pCharSet );

	if ( nMode != MODE_BF )
	  freepw( pwlist );	

#ifndef WIN32
	reset_keypress();
#endif

	return 0;
}
