/* 
   SQL Password Auditing Tool
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <string.h>

#ifndef _bf_h
#define _bf_h

static const char MODE_BF = 1;
static const char MODE_DIC = 2;

static const int CHARSET_MAXSIZE = 1024;

typedef struct charset {
	char *pCharset;
	int nLength;
} CHARSET;

typedef struct mask {
	char *pMask;
	int nLength;
} MASK;

typedef struct pw {
	char *pPass;
	int nLength;
} PASS;

void pwBruteForce(PASS *, const CHARSET *, MASK *);

#endif
