/* 
   SQL Password Auditing Tool
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef _SQLBF_H
#define _SQLBF_H
#define MD_SIZE 20

#include "bf.h"
#include "crypto.h"


static struct hashlist {
	char username[20]; /* a username will never be longer than this :) */
	unsigned char mchash[MD_SIZE];
	unsigned char uchash[MD_SIZE];
	char password[40]; /* a password will never be longer than this :) */
	unsigned char salt[4];
	struct hashlist *next;
	char found;
};

static struct passwordlist {
	char pw[40];
	char *pwuc;
	int pwlen;
	struct passwordlist *next;
};

static const char *SQLPAT_VERSION = "1.0.1";
#endif
