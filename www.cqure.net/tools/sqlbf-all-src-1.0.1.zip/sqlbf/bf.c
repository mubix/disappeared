/* 
   SQL Password Auditing Tool
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bf.h"

/*
	Some debbuging
*/
void printMask(char *mask) {

	int i = 0;
	
	for ( i=0; i<=20; i++ )
		fprintf(stderr, "%d,", mask[i]);


	fprintf(stderr, "\n");
}

/*
	General BF engine
*/
void pwBruteForce(PASS *pw, const CHARSET *charset, MASK *mask) {

	int i = mask->nLength;
	int pwpos = 0;

	/* Increase last position of mask by 1 */
	mask->pMask[mask->nLength] ++;

	/* Should we wrap any part of the mask */
	while ( mask->pMask[i] == charset->nLength ) {
		mask->pMask[i-1] ++;
		mask->pMask[i] = 1;
		i--;
	}

	/* Ok new mask is calculated, lets come up with a suitable pw */
	for ( i=0; i<=mask->nLength; i++ ) {
		if ( mask->pMask[i] != 0 ) {
			pw->pPass[pwpos] = charset->pCharset[mask->pMask[i]];
			pwpos++;
		}
	}

	/* save time by not doing strlens */
	pw->nLength = pwpos;

}

/*
	Set appropriate mask for supplied password
*/
void setMaskForPw(PASS *pw, char *pwd, const CHARSET* cs, MASK* mask) {

	int i, j;
	int nPwLen = strlen(pwd);

	pw->nLength = nPwLen;
	strncpy((char *)pw->pPass, pwd, nPwLen);

	for ( i = 0; i<=nPwLen; i++ ) {
		j = 0;
		while ( cs->pCharset[j] != pw->pPass[nPwLen-i-1] ) {
			j++;
		}

		/* if last char decrease by one, since its increased in bf function */
		if ( i == 0 )
			mask->pMask[mask->nLength-i] = j - 1;
		else
			mask->pMask[mask->nLength-i] = j;
	}

}
