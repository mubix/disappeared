/* 
   SQL Password Auditing Tool
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "crypto.h"
#include "sqlbf.h"
#include <math.h>

int compareHashes(unsigned char *pHash1, unsigned char *pHash2) {

	int i;

	for ( i=0; i<MD_SIZE; i++ ) {
		if ( pHash1[i] != pHash2[i] ) {
			return 0; /* hashes don't match */
		}
	}

	/* hashes match */
	return 1;


}

void doUnicode(const char *pStr, char *pUnicoded, const int nLen) {

  int j = 0, i=0;

  for ( i=0; i<nLen; i ++ ) {
    pUnicoded[j] = pStr[i];
    pUnicoded[j+1] = 0x00;
    j+=2;
  }

}

int getMixedCasePwFromUCPw(struct hashlist *hlist, struct passwordlist *pwlist) {

	int	nLen   = pwlist->pwlen;
	int nTries = (int)pow( 2, nLen );
	int i, j;
	unsigned char *md;
	int nTotTries = nTries;

	md = (unsigned char *) malloc ( MD_SIZE );

	while ( nTries > 0 ) {
		
		for ( i = 0; i < nLen; i ++ ) {
			
			j = (int)pow(2, i);
			if ( nTries & j )
				pwlist->pw[i] = tolower( pwlist->pw[i] );
			else
				pwlist->pw[i] = toupper( pwlist->pw[i] );

		}

		nTries--;
		doUnicode( pwlist->pw, pwlist->pwuc, nLen );
		mssqlHash( md, pwlist, hlist->salt );
	
		if ( compareHashes( md, hlist->mchash ) )
			break;

	}

	free( md );
	return nTotTries-nTries;

}

void mssqlHash(unsigned char *md, struct passwordlist *pwlist, const unsigned char salt[4]) {

	int i;
	SHA_CTX c;

	i = pwlist->pwlen * 2; /* unicode remember */
	memcpy( pwlist->pwuc + i, salt, 4);

	SHA1_Init(&c);
	SHA1_Update(&c, pwlist->pwuc, pwlist->pwlen*2+4); 
	SHA1_Final(md, &c);

}
