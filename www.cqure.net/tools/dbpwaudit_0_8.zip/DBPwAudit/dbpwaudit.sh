#!/bin/sh
java -cp jdbc/*:lib/*:bin/* net.cqure.DBPwAudit $*
